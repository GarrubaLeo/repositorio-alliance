/*
================================================================================
  app.js — ORGANIZADO (somente comentários e estrutura visual)
  IMPORTANTE: Nenhuma regra/linha de lógica foi alterada. Apenas:
    - Adicionados comentários explicando cada parte.
    - Mantida a ordem original do código para evitar efeitos colaterais.
    - Criado um índice (TOC) para facilitar navegação.

  ÍNDICE RÁPIDO (TOC):
    [1] Constantes de CLI e detecção de ambiente (XS/CF)
    [2] Helpers utilitários (datas, quoting de argumentos, paths, exec)
    [3] CSS base e estilos de UI
    [4] Dependências de terceiros (dotenv, express, session, sqlite3, axios, bcrypt, uuid, path, fs, child_process, nodemailer, pdfkit)
    [5] Infra de Banco (classe Database) e Migrations (SchemaManager)
    [6] Serviços de Domínio:
        6.1 UserService (CRUD de usuários e senha)
        6.2 PasswordResetService (tokens e validação)
        6.3 AppsService (catálogo/versões, MTAR URL, dependências)
    [7] Views (HTML):
        7.1 LoginView (tela de autenticação + scripts auxiliares)
        7.2 Outras views (quando presentes)
    [8] Rotas HTTP (API e páginas), autenticação e sessões
    [9] Fluxos de Deploy/Rollback com SSE (streaming em tempo real)
   [10] Auditorias (object_version_audit, deploy_audit) e relatórios
   [11] Inicialização do servidor (express listen)

  COMO LER:
    - Procure blocos "// === ..." existentes e os comentários abaixo explicam
      o propósito de cada função/classe/rota.
    - Palavras-chave: "o que faz", "quando é chamado", "parâmetros" e "retorno".

  OBSERVAÇÃO:
    - Caso queira remover os comentários, basta apagar este cabeçalho.
================================================================================
*/

/* [1] Constantes de CLI e detecção de ambiente (XS/CF)
   - CLI_NAME / CLI_BIN: nomes/atalhos do CLI padrão.
   - isCFEnv(env): inspeciona env.env_type e URL para deduzir se é Cloud Foundry (CF).
   - getCliPair(env): retorna { CLI_NAME, CLI_BIN } coerente com XS ou CF.
   * Usado para padronizar comandos de login/push nas operações de deploy. */

CLI_NAME =  'XS';
CLI_BIN =  'xs';
// === CLI selector (CF vs XS) ===
/** 
 * Função (arrow) isCFEnv
 * - O que faz: Procedimento/serviço utilizado no fluxo atual.
 * - Retorno: Conforme uso do chamador.
 * @param {{any}} env 
 */
const isCFEnv = (env) => {
  try {
    if (!env) return false;
    const t = (env.env_type || env.type || '').toString().toLowerCase();
const byType = t.includes('cf') || t.includes('cloud foundry');
    const byUrl = (env.org_url || '').includes('api.cf.');
    return byType || byUrl;
  } catch(e) { return false; }
};

/** 
 * Função (arrow) getCliPair
 * - O que faz: Procedimento/serviço utilizado no fluxo atual.
 * - Retorno: Conforme uso do chamador.
 * @param {{any}} env 
 */
const getCliPair = (env) => {
  const isCF = isCFEnv(env);
  return {
    CLI_NAME: isCF ? 'CF' : 'XS',
    CLI_BIN:  isCF ? 'cf' : 'xs', CLI_NAME: (isCF ? 'CF' : 'XS')
  };
};

// Safely quote CLI arg if it contains spaces or special chars
/** 
 * Função ensureCliArgQuoted
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem ensureCliArgQuoted.
 * - Retorno: Valor compatível com o uso corrente.
 * @param {{any}} val 
 */
function ensureCliArgQuoted(val) {
  if (val == null) return '';
  const s = String(val);
  if (/^[A-Za-z0-9._@!:\-]+$/.test(s)) return s; // no spaces/specials
  // escape double quotes inside
  const esc = s.replace(/"/g, '\"');
  return `"${esc}"`;
}

// === MTA deploy tweaks for large MTAR uploads (CF MultiApps plugin) ===
// If MTAR is large, we can reduce upload chunk size to avoid gorouter timeouts and
// optionally increase the upload/deploy timeouts.
// References:
// - MULTIAPPS_UPLOAD_CHUNK_SIZE: splits large MTAR uploads into chunks (default 45MB). 
//   Useful to prevent failed uploads due to request timeout.
// - cf deploy supports --apps-upload-timeout and -t (operation timeout) in the SAP MultiApps/MTA plugin.
function withMtaUploadTweaks(mtarPath, baseArgs, baseEnv) {
  try {
    if (!mtarPath) return { args: baseArgs, env: baseEnv || process.env };

    const envIn = baseEnv || process.env;
    const isCF = isCFEnv(envIn);

    const st = fs.statSync(String(mtarPath).replace(/^"|"$/g, ''));
    const sizeMB = st.size / (1024 * 1024);
    const thresholdMB = Number(process.env.MTAR_LARGE_THRESHOLD_MB || 200);

    if (!Number.isFinite(sizeMB) || sizeMB < thresholdMB) {
      return { args: baseArgs, env: envIn };
    }

    const env = { ...envIn };
    let args = Array.isArray(baseArgs) ? [...baseArgs] : [];

    // XS deploy does NOT support --apps-upload-timeout nor MULTIAPPS_UPLOAD_CHUNK_SIZE.
    // CF MultiApps plugin supports both.
    if (isCF) {
      // Smaller upload chunks help avoid gorouter request timeout on big MTARs.
      if (!env.MULTIAPPS_UPLOAD_CHUNK_SIZE) {
        env.MULTIAPPS_UPLOAD_CHUNK_SIZE = String(process.env.MULTIAPPS_UPLOAD_CHUNK_SIZE_LARGE || 20);
      }

      // Increase upload timeout (seconds) for app binaries inside the MTAR.
      if (!args.includes('--apps-upload-timeout')) {
        const uploadTimeout = String(process.env.MTA_APPS_UPLOAD_TIMEOUT || 3600);
        args.push('--apps-upload-timeout', uploadTimeout);
      }
    }

    // Increase overall deploy operation timeout (seconds) for BOTH CF and XS.
    // CF plugin: -t ; XS CLI: -t
    if (!args.includes('-t')) {
      const deployTimeout = String(process.env.MTA_DEPLOY_TIMEOUT || 3600);
      args.push('-t', deployTimeout);
    }

    return { args, env };
  } catch (_e) {
    return { args: baseArgs, env: baseEnv || process.env };
  }
}

// === Date helper: local time to SQLite 'YYYY-MM-DD HH:mm:ss' ===
/** 
 * Função toLocalSql
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem toLocalSql.
 * - Retorno: Valor compatível com o uso corrente.
 * @param {{any}} date = new Date( 
 */
function toLocalSql(date = new Date()) {
  /** 
   * Função (arrow) pad
   * - O que faz: Procedimento/serviço utilizado no fluxo atual.
   * - Retorno: Conforme uso do chamador.
   * @param {{any}} n 
   */
  const pad = (n) => String(n).padStart(2, '0');
  const y = date.getFullYear();
  const m = pad(date.getMonth() + 1);
  const d = pad(date.getDate());
  const hh = pad(date.getHours());
  const mm = pad(date.getMinutes());
  const ss = pad(date.getSeconds());
  return `${y}-${m}-${d} ${hh}:${mm}:${ss}`;
}

const baseCss = `
#deployWrap{max-height:360px;overflow:auto}
#deployBox.pre{max-height:360px;overflow:auto}

#ovFilter.btn {
  margin:4px;
  padding:6px 12px;
  border-radius:12px;
}

:root[data-theme="dark"] .theme-toggle{background:#0f172a;color:#9ca3af;border-color:#334155}

:root{--font:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;--bg:linear-gradient(135deg, #E8E8E8, #F5F5F5);--text:#0f172a;--muted:#4b5563;--line:#9ca3af;--soft:#f1f5f9}
*{box-sizing:border-box}
html,body{padding:0;margin:0 display:flex; justify-content:center;}
body{font-family:var(--font);background:#F0F8FF;color:var(--text);line-height:1.45}
a{color:#6366f1;text-decoration:none}
.container{margin:24px auto;}
.header{display:flex;align-items:center;gap:12px;margin-bottom:16px; background: #ffffff; padding:10px 14px; border-radius:12px; margin-bottom: 20px; border-style: solid; border-width: 1px; border-color: #9ca3af}
.header img{height:50px;width:auto}
.header .right{margin-left:auto;display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.btn,button{display:inline-flex;align-items:center;gap:8px;border:1px solid var(--line);background:#fff;border-radius:10px;padding:8px 10px;font-size:14px;cursor:pointer}
.btn:hover,button:hover{background:var(--soft)}
input,select{padding:8px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;background:#fff;color:var(--text)}
small,.muted{color:var(--muted)}
.card{background:#fff;border:1px solid var(--line);border-radius:12px;padding:18px;box-shadow:0 2px 10px rgba(2,6,23,.04)}
.table{width:100%;border-collapse:collapse}
.table th,.table td{padding:8px 10px;border-bottom:1px solid var(--line);text-align:left}
.chips{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px}
.chip{border:1px solid var(--line);border-radius:999px;padding:4px 10px;font-size:12px;background:#fff}
.badge{display:inline-block;border:1px solid var(--line);background:#fff;border-radius:999px;padding:2px 8px;font-size:12px}
.pre{white-space:pre-wrap;background:#18181b;color:#9ca3af;border:1px solid #0f172a;border-radius:10px;padding:10px;font-size:12px}
.value{display:inline-block;border:1px dashed var(--line);border-radius:10px;padding:6px 10px;font-size:14px;background:#fff}
.sticky{position:sticky;top:16px}

/* === Light blue header buttons (pedido do Leonardo) === */
.header .right a.btn[href="/environments"] { color: #000; }
.header .right a.btn[href="/environments"],
.header .right #btnOpenCreateUser,
.header .right #btnLogout,
.header .right #btnReport {
  background-color: #eef2ff;
  border-color: #a5b4fc;
}
.header .right a.btn[href="/environments"]:hover,
.header .right #btnOpenCreateUser:hover,
.header .right #btnLogout:hover,
.header .right #btnReport:hover {
  background-color: #c7d2fe;
}
/* === fim: light blue header buttons === */
/* === Forçar estilo do botão Relatório igual aos demais === */
.header .right #btnReport {
  background-color: #eef2ff !important;
  border-color: #a5b4fc !important;
  color: #000 !important;
}
.header .right #btnReport:hover {
  background-color: #c7d2fe !important;
}

/* === Estilo especial para botão Sair em vermelho claro === */
.header .right #btnLogout {
  background-color: #fff1f2 !important;
  border-color: #fda4af !important;
  color: #000 !important;
}
.header .right #btnLogout:hover {
  background-color: #fecdd3 !important;
}
/* === fim estilo vermelho claro === */

/* === Ajuste de tamanho da fonte para unificar botões === */
.header .right a.btn[href="/environments"],
.header .right #btnOpenCreateUser,
.header .right #btnLogout,
.header .right #btnReport {
  font-size: 14px !important;
}
/* === fim ajuste de tamanho da fonte === */

/* === Destaque visual quando houver dependências pendentes === */
.btn.warn {
  background-color: #fef3c7 !important; /* laranja claro */
  border-color: #fcd34d !important;
}
.btn.warn::after {
  content: " ⚠";
  font-size: 12px;
}
/* === fim destaque dependências === */
`;
/**
 * app.js — Deploy streaming, Ambientes, Auditorias
 * Fix: URL MTAR robusta (repoName + variações) e correção de sintaxe.
 */

require('dotenv').config();

const express = require('express');
const session = require('express-session');
const sqlite3 = require('sqlite3').verbose();
const axios = require('axios');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
// Banco de dados: use caminho absoluto no diretório do projeto para não “perder” cadastros ao iniciar de outra pasta
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'apps.db');

const fs = require('fs');
const crypto = require('crypto');
const { spawn } = require('child_process');
const nodemailer = require('nodemailer');

const PDFDocument = require('pdfkit');
// =============== Helpers ===============

// === Date helper: local time to SQLite 'YYYY-MM-DD HH:mm:ss' ===
/** 
 * Função toLocalSql
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem toLocalSql.
 * - Retorno: Valor compatível com o uso corrente.
 * @param {{any}} date = new Date( 
 */
function toLocalSql(date = new Date()) {
  /** 
   * Função (arrow) pad
   * - O que faz: Procedimento/serviço utilizado no fluxo atual.
   * - Retorno: Conforme uso do chamador.
   * @param {{any}} n 
   */
  const pad = (n) => String(n).padStart(2, '0');
  const y = date.getFullYear();
  const m = pad(date.getMonth() + 1);
  const d = pad(date.getDate());
  const hh = pad(date.getHours());
  const mm = pad(date.getMinutes());
  const ss = pad(date.getSeconds());
  return `${y}-${m}-${d} ${hh}:${mm}:${ss}`;
}

/** 
 * Função nowSqlite
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem nowSqlite.
 * - Retorno: Valor compatível com o uso corrente.

 */
function nowSqlite(){ return toLocalSql(new Date()); }
/** 
 * Função ensureDirSync
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem ensureDirSync.
 * - Retorno: Valor compatível com o uso corrente.
 * @param {{any}} p 
 */
function ensureDirSync(p){ if(!fs.existsSync(p)) fs.mkdirSync(p, {recursive:true}); }

/** 
 * Função runCmd
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem runCmd.
 * - Retorno: Valor compatível com o uso corrente.
 * @param {{any}} cmd 
 * @param {{any}} args = [] 
 * @param {{any}} opts = {} 
 */
function runCmd(cmd, args = [], opts = {}) {
  /** 
   * Função splitArgs
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem splitArgs.
   * - Retorno: Valor compatível com o uso corrente.
   * @param {{any}} str 
   */
  function splitArgs(str){
    if(!str) return [];
    const out = [];
    const rx = /"([^"]*)"|'([^']*)'|(\S+)/g;
    let m;
    while((m = rx.exec(str))){ out.push(m[1] ?? m[2] ?? m[3]); }
    return out;
  }
  // Allow overriding binaries via env vars and auto-map for XS/CF
  const BIN_OVERRIDE = (process.env.CLI_BIN || '').trim();
  if (BIN_OVERRIDE) { cmd = BIN_OVERRIDE; }
  if ((cmd === 'xs' || cmd === 'cf')) {
    const envBin = (cmd === 'xs' ? process.env.XS_BIN : process.env.CF_BIN) || '';
    if (envBin && envBin.trim()) cmd = envBin.trim();
  }

  // Extra args from env
  const extra = splitArgs(process.env.XS_ARGS || '');

  return new Promise((resolve) => {
    // Use shell:true so Windows can resolve .cmd/.exe and PATH entries
    const child = require('child_process').spawn(cmd, [...extra, ...args], {
      shell: true,
      ...opts });
    let out = '', err = '';
    child.stdout.on('data', d => out += d.toString());
    child.stderr.on('data', d => err += d.toString());
    child.on('error', (e) => {
      // Do not crash the process; surface the error in a controlled way
      const msg = (e && e.message) || String(e);
      resolve({ code: -1, stdout: out, stderr: (err ? err + '\n' : '') + msg });
    });
    child.on('close', code => resolve({ code, stdout: out, stderr: err }));
  });
}
async function getLockInfo(db, userId){
  return db.get(`SELECT failures, locked_until FROM auth_lock WHERE user_id=?`, [userId]);
}
async function bumpFailure(db, userId){
  const rec = await getLockInfo(db, userId);
  const now = new Date();
  if(!rec){
    await db.run(`INSERT INTO auth_lock(user_id,failures) VALUES (?,1)`, [userId]);
    return;
  }
  const failures = (rec.failures||0)+1;
  let locked_until = null;
  if (failures >= 5) { // 15 minutes
  locked_until = toLocalSql(new Date(now.getTime()+15*60*1000));
}
  await db.run(`UPDATE auth_lock SET failures=?, locked_until=? WHERE user_id=?`, [failures, locked_until, userId]);
}
async function clearFailures(db, userId){
  await db.run(`DELETE FROM auth_lock WHERE user_id=?`, [userId]);
}

// ===== Email helpers for forgot password =====
/** 
 * Função createMailerTransport
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem createMailerTransport.
 * - Retorno: Valor compatível com o uso corrente.

 */
function createMailerTransport(){
  const host = process.env.SMTP_HOST || process.env.SMTP_HOSTNAME || null;
  if(!host) return null;
  const port = Number(process.env.SMTP_PORT || 587);
  const secure = String(process.env.SMTP_SECURE || 'false').toLowerCase() === 'true';
  const user = process.env.SMTP_USER || process.env.SMTP_USERNAME || null;
  const pass = process.env.SMTP_PASS || process.env.SMTP_PASSWORD || null;
  const auth = user && pass ? { user, pass } : undefined;
  return nodemailer.createTransport(Object.assign({
    host, port, secure, tls: { rejectUnauthorized: false }
  }, auth ? { auth } : {}));
}

/** 
 * Função renderResetEmail
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem renderResetEmail.
 * - Retorno: Valor compatível com o uso corrente.
 * @param {{any}} toEmail 
 * @param {{any}} resetUrl 
 */
function renderResetEmail(toEmail, resetUrl){
  const company = process.env.MAIL_FROM_NAME || 'Alliance Consultoria';
  const subject = process.env.RESET_EMAIL_SUBJECT || 'Redefinição de senha - Atualizador de Componentes';
  const intro = process.env.RESET_EMAIL_INTRO || 'Olá! Você solicitou a redefinição da sua senha do Atualizador de Componentes.';
  const cta = process.env.RESET_EMAIL_BUTTON_TEXT || 'Redefinir senha';
  const validity = process.env.RESET_EMAIL_VALIDITY || 'válido por 30 minutos';
  const footer = process.env.RESET_EMAIL_FOOTER || 'Se você não solicitou esta ação, ignore este e-mail.';
  const primary = process.env.BRAND_PRIMARY_COLOR || '#0d6efd';
  const logo = process.env.BRAND_LOGO_URL || '';

  const text = `${intro} Acesse o link: ${resetUrl} (${validity}).`;
  const html = `
  <div style="font-family:Arial,Helvetica,sans-serif;background:#f6f9fc;padding:24px;color:#111;">
    <table role="presentation" cellspacing="0" cellpadding="0" style="max-width:540px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;border:1px solid #eaecef">
      <tr>
        <td style="padding:24px 24px 0 24px;text-align:center">
          ${logo ? `<img src="${logo}" alt="${company}" style="max-height:42px;margin-bottom:4px" />` : ``}
          <div style="font-size:18px;font-weight:700;margin:8px 0 16px">${company}</div>
        </td>
      </tr>
      <tr>
        <td style="padding:0 24px 24px 24px">
          <div style="font-size:16px;line-height:1.5;margin:8px 0 16px">${intro}</div>
          <div style="text-align:center;margin:24px 0">
            <a href="${resetUrl}" style="display:inline-block;padding:12px 20px;border-radius:8px;text-decoration:none;background:${primary};color:#fff;font-weight:700">${cta}</a>
          </div>
          <div style="font-size:13px;color:#555;margin-top:8px">Link ${validity}.</div>
          <div style="font-size:12px;color:#777;margin-top:16px">${footer}</div>
        </td>
      </tr>
      <tr>
        <td style="padding:16px 24px;background:#fafafa;border-top:1px solid #eee;text-align:center;font-size:12px;color:#888">
          © ${new Date().getFullYear()} ${company}
        </td>
      </tr>
    </table>
  </div>`;
  return { subject, text, html };
}

async function sendResetEmail(toEmail, resetUrl){
  try{
    const tx = createMailerTransport();
    if(!tx){
      console.log('> sendResetEmail: SMTP not configured, will only log link.');
      return { ok: true, info: 'skipped-no-smtp' };
    }
    const from = `${process.env.MAIL_FROM_NAME || 'Alliance Consultoria'} <${process.env.SMTP_USER}>`;
    const { subject, text, html } = renderResetEmail(toEmail, resetUrl);
    const info = await tx.sendMail({
      from,
      to: toEmail,
      replyTo: process.env.REPLY_TO || undefined,
      subject,
      text,
      html
    });
    console.log('> sendResetEmail: sent', info && (info.messageId || info.response || info));
    return { ok: true, info };
  }catch(e){
    console.error('> sendResetEmail error', (e && e.message) || e);
    return { ok: false, error: (e && e.message) || String(e) };
  }
}

// =============== Infra DB ===============
/** 
 * Classe Database
 * - O que faz: Representa uma entidade/serviço com estado e comportamentos.
 * - Observação: Métodos internos seguem as regras originais do código.
 */
class Database {
  constructor(filename = './apps.db') { this.db = new sqlite3.Database(filename); }
  run(sql, p=[]) { return new Promise((ok, bad)=> this.db.run(sql, p, function(e){ if(e) bad(e); else ok(this); })); }
  get(sql, p=[]) { return new Promise((ok, bad)=> this.db.get(sql, p, function(e,r){ if(e) bad(e); else ok(r); })); }
  all(sql, p=[]) { return new Promise((ok, bad)=> this.db.all(sql, p, function(e,rs){ if(e) bad(e); else ok(rs); })); }
  async hasColumn(table, col){
    const rows = await this.all(`PRAGMA table_info(${table})`);
    return rows.some(r => String(r.name).toLowerCase() === String(col).toLowerCase());
  }
}

// =============== Schema/Migrations ===============
/** 
 * Classe SchemaManager
 * - O que faz: Representa uma entidade/serviço com estado e comportamentos.
 * - Observação: Métodos internos seguem as regras originais do código.
 */
class SchemaManager {
  constructor(db){ this.db=db; }
  async ensure(){
    try { await this.db.run(`DROP INDEX IF EXISTS ux_installed_source_component`); } catch(_){ }
try { await this.db.run(`DROP INDEX IF EXISTS idx_installed_source_component`); } catch(_){ }
    await this.db.run(`CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT DEFAULT 'admin',
      created_at TEXT DEFAULT (datetime('now','localtime'))
    )`);

    await this.db.run(`CREATE TABLE IF NOT EXISTS password_resets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      token TEXT UNIQUE NOT NULL,
      expires_at TEXT NOT NULL,
      used_at TEXT,
      created_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY(user_id) REFERENCES users(id)
    )`);

    await this.db.run(`CREATE TABLE IF NOT EXISTS available_apps (
      app_name TEXT PRIMARY KEY, repoName TEXT, version TEXT, description TEXT, gitUrl TEXT
    )`);
    await this.db.run(`CREATE TABLE IF NOT EXISTS available_apps_dependency (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      component_id TEXT, parent_id TEXT, version TEXT, type TEXT, resourceName TEXT
    )`);
    await this.db.run(`CREATE INDEX IF NOT EXISTS idx_dep_component ON available_apps_dependency(component_id)`);
    await this.db.run(`CREATE INDEX IF NOT EXISTS idx_dep_parent ON available_apps_dependency(parent_id)`);
    await this.db.run(`CREATE TABLE IF NOT EXISTS installed_apps (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      component TEXT NOT NULL,
      version TEXT NOT NULL,
      source TEXT,           -- pode ser 'name' do ambiente ou id, conforme sua origem
      installed_at TEXT DEFAULT (datetime('now','localtime'))
    )`)
try { await this.db.run(`ALTER TABLE installed_apps ADD COLUMN empresa TEXT`); } catch(_){}
try { await this.db.run(`ALTER TABLE installed_apps ADD COLUMN ambiente TEXT`); } catch(_){}
;
    await this.db.run(`DROP INDEX IF EXISTS idx_installed_source_component; CREATE INDEX IF NOT EXISTS idx_installed_source_component_env ON installed_apps(source, component, empresa, ambiente)`);
await this.db.run(`DROP INDEX IF EXISTS ux_installed_source_component; CREATE UNIQUE INDEX IF NOT EXISTS ux_installed_source_component_env ON installed_apps(source, component, empresa, ambiente)`);
    

    await this.db.run(`
  CREATE TABLE IF NOT EXISTS environments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    origem TEXT NOT NULL CHECK(origem IN ('TR','QAS')),
    org_url TEXT,
    org TEXT,
    space TEXT,
    username TEXT,
    env_type TEXT CHECK(env_type IN ('XS','CF')) DEFAULT 'CF',
    stage TEXT CHECK(stage IN ('HML','PRD')) DEFAULT 'HML',
    created_at TEXT DEFAULT (datetime('now','localtime')),
    updated_at TEXT DEFAULT (datetime('now','localtime'))
  )
`);
    await this.db.run(`CREATE INDEX IF NOT EXISTS idx_env_name ON environments(name)`);
try { await this.db.run(`ALTER TABLE environments ADD COLUMN stage TEXT`); } catch(_){ }

    // Auditoria de consulta de versão
    await this.db.run(`CREATE TABLE IF NOT EXISTS object_version_audit (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ts TEXT DEFAULT (datetime('now','localtime')),
      env_id INTEGER,
      company_name TEXT,
      origem TEXT,
      org_url TEXT,
      org TEXT,
      space TEXT,
      username TEXT,
      object_id TEXT,
      repo_version TEXT,
      client_version TEXT,
      xs_cli_version TEXT,
      raw_mtas TEXT,
      executor_user TEXT,
      FOREIGN KEY(env_id) REFERENCES environments(id)
    )`);
    await this.db.run(`CREATE INDEX IF NOT EXISTS idx_obj_audit_objid ON object_version_audit(object_id)`);
    await this.db.run(`CREATE INDEX IF NOT EXISTS idx_obj_audit_env ON object_version_audit(env_id)`);

    // Auditoria de deploy
    await this.db.run(`CREATE TABLE IF NOT EXISTS deploy_audit (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ts TEXT DEFAULT (datetime('now','localtime')),
      env_id INTEGER,
      company_name TEXT,
      org TEXT,
      space TEXT,
      object_id TEXT,
      prev_version TEXT,
      new_version TEXT,
      executor_user TEXT,
      status TEXT,
      log_text TEXT,
      FOREIGN KEY(env_id) REFERENCES environments(id)
    )`);

    /* === Security & Branding schema extensions === */
await this.db.run(`CREATE TABLE IF NOT EXISTS auth_lock (
  user_id INTEGER PRIMARY KEY,
  failures INTEGER DEFAULT 0,
  locked_until TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id)
)`);
try { await this.db.run(`ALTER TABLE users ADD COLUMN twofa_email_enabled INTEGER DEFAULT 0`); } catch(_){}
try { await this.db.run(`ALTER TABLE users ADD COLUMN twofa_enabled INTEGER DEFAULT 0`); } catch(_){}
try { await this.db.run(`ALTER TABLE environments ADD COLUMN brand_logo_url TEXT`); } catch(_){}
try { await this.db.run(`ALTER TABLE environments ADD COLUMN brand_primary_color TEXT`); } catch(_){}
try { await this.db.run(`ALTER TABLE environments ADD COLUMN env_type TEXT CHECK(env_type IN ('XS','CF')) DEFAULT 'CF'`); } catch(_){}
try { await this.db.run(`ALTER TABLE environments ADD COLUMN env_type TEXT CHECK(env_type IN ('XS','CF')) DEFAULT 'CF'`); } catch(_){}
try { await this.db.run(`ALTER TABLE deploy_audit ADD COLUMN ip TEXT`); } catch(_){}
try { await this.db.run(`ALTER TABLE deploy_audit ADD COLUMN user_agent TEXT`); } catch(_){}
try { await this.db.run(`ALTER TABLE deploy_audit ADD COLUMN host TEXT`); } catch(_){}
try { await this.db.run(`ALTER TABLE deploy_audit ADD COLUMN ticket TEXT`); } catch(_){ }
    await this.maybeAddUsuárioUser();
  }

  async maybeAddUsuárioUser(){
    const has = await this.db.hasColumn('object_version_audit','executor_user');
    if(!has){ await this.db.run(`ALTER TABLE object_version_audit ADD COLUMN executor_user TEXT`); }
  }
}

// =============== Serviços ===============
/** 
 * Classe UserService
 * - O que faz: Representa uma entidade/serviço com estado e comportamentos.
 * - Observação: Métodos internos seguem as regras originais do código.
 */
class UserService {
  constructor(db){ this.db=db; }
  async seedAdmin(){
    const c = await this.db.get(`SELECT COUNT(*) n FROM users`);
    if ((c?.n||0)===0){
      const u=process.env.ADMIN_USER||'admin', p=process.env.ADMIN_PASS||'admin123', e=process.env.ADMIN_EMAIL||'admin@example.com';
      const h = await bcrypt.hash(p,10);
      await this.db.run(`INSERT INTO users (username,email,password_hash,role) VALUES (?,?,?,?)`,[u,e,h,'admin']);
      console.log(`> Admin criado: ${u}/${p} (${e}) — altere em produção.`);
    }
  }
  findByUsername(u){ return this.db.get(`SELECT * FROM users WHERE username = ?`,[u]); }
  findByEmail(e){ return this.db.get(`SELECT * FROM users WHERE email = ?`,[e]); }
  verifyPassword(user,plain){ return bcrypt.compare(plain, user.password_hash); }
  async setPassword(id,newP){ const h=await bcrypt.hash(newP,10); await this.db.run(`UPDATE users SET password_hash=? WHERE id=?`,[h,id]); }
}

/** 
 * Classe PasswordResetService
 * - O que faz: Representa uma entidade/serviço com estado e comportamentos.
 * - Observação: Métodos internos seguem as regras originais do código.
 */
class PasswordResetService {
  constructor(db){ this.db=db; }
  async createTokenForUser(userId, minutes=30){
    const token = uuidv4();
const exp = toLocalSql(new Date(Date.now()+minutes*60*1000));
    await this.db.run(`INSERT INTO password_resets (user_id,token,expires_at) VALUES (?,?,?)`,[userId,token,exp]);
    return token;
  }
  getValidToken(tok){
    return this.db.get(
      `SELECT pr.*, u.username, u.email
       FROM password_resets pr JOIN users u ON u.id=pr.user_id
       WHERE pr.token=? AND pr.used_at IS NULL AND pr.expires_at > datetime('now','localtime')`,
      [tok]
    );
  }
  markUsed(tok){ return this.db.run(`UPDATE password_resets SET used_at=datetime('now','localtime') WHERE token=?`,[tok]); }
}

/** 
 * Classe AppsService
 * - O que faz: Representa uma entidade/serviço com estado e comportamentos.
 * - Observação: Métodos internos seguem as regras originais do código.
 */
class AppsService {
  async upsertInstalled(env, component, version){
    try{
      const comp = String(component||'').trim().toLowerCase();
      const ver  = String(version||'0.0.0').trim().replace(/^v/i,'');
      const src  = env && (env.name ? String(env.name) : (env.id!=null ? String(env.id) : ''));
      
      // Derivar empresa e ambiente
      let empresa = (env && (env.name || env.company_name || env.org)) ? String(env.name || env.company_name || env.org).trim() : '';
      let ambiente = (env && (env.space || env.environment || env.env || env.ambiente)) ? String(env.space || env.environment || env.env || env.ambiente).trim() : '';
      if(!ambiente && empresa){
        const _m = empresa.match(/\s+(DEV|QAS|PRD|HML|PROD|PRODUCAO|HOMOLOG|PPRD|QA|TEST|STG)$/i);
        if(_m){
          ambiente = _m[1].toUpperCase();
          empresa = empresa.replace(new RegExp("\\s+"+_m[1]+"$","i"), "").trim();
        }
      }
if(!comp || !ver || !src) return;

      // Checagem: ler a versão atual para este source/componente
      const row = await this.db.get(
        `SELECT version FROM installed_apps WHERE source=? AND component=? AND empresa=? AND ambiente=?`,
        [src, comp, empresa || null, ambiente || null]
      );

      if (!row){
        // Inserir apenas se não existir
        await this.db.run(
          `INSERT INTO installed_apps(component,version,source,empresa,ambiente) VALUES (?,?,?,?,?)`,
          [comp, ver, src, empresa || null, ambiente || null]
        );
        try{ console.log('[installed_apps] insert', {source:src, component:comp, version:ver}); }catch(_){}
        return;
      }

      const cur = String(row.version||'').trim();
      if (cur === ver){
        // Sem mudança: não atualizar
        try{ console.log('[installed_apps] noop (unchanged)', {source:src, component:comp, version:ver}); }catch(_){}
        return;
      }

      // Houve mudança: atualizar
      await this.db.run(
        `UPDATE installed_apps SET version=?, installed_at=datetime('now','localtime') WHERE source=? AND component=? AND empresa=? AND ambiente=?`,
        [ver, src, comp, empresa || null, ambiente || null]
      );
      try{ console.log('[installed_apps] update', {source:src, component:comp, from:cur, to:ver}); }catch(_){}
    }catch(_e){ /* noop */ }
  
  }

  __normComp(s){ try{ return String(s||'').trim().toLowerCase(); }catch(_){ return String(s||''); } }
  __normVer(v){ try{ return String(v||'0.0.0').trim().replace(/^v/i,''); }catch(_){ return String(v||'0.0.0'); } }

  constructor(db){
    this.db=db;
    this.remote='https://onesource4sap-repository.thomsonreuters.com/content/raw/release/Dependency.json';
    this.repoRefreshCache = {
      hash: null,
      at: 0,
      count: 0
    };
  }
  async updateFromRemote(){
    const timeout = Number(process.env.REPO_UPDATE_TIMEOUT_MS || 30000);
    const cacheTtlMs = Number(process.env.REPO_REFRESH_TTL_MS || 180000);
    const {data}=await axios.get(this.remote,{timeout});
    const list = Array.isArray(data?.components)?data.components:[];
    const payloadHash = crypto.createHash('sha1').update(JSON.stringify(list)).digest('hex');
    const now = Date.now();

    if (
      this.repoRefreshCache.hash === payloadHash &&
      this.repoRefreshCache.at &&
      (now - this.repoRefreshCache.at) < cacheTtlMs
    ) {
      return this.repoRefreshCache.count || list.length;
    }

    const apps = [];
    const deps = [];
    for(const app of list){
      if(!app || !app.id) continue;
      apps.push([
        app.id,
        app.repoName || null,
        app.version || null,
        app.description || null,
        app.gitUrl || null
      ]);
      const reqs = Array.isArray(app.requires)?app.requires:[];
      for(const dep of reqs){
        if(!dep?.id?.startsWith('tax4b.')) continue;
        deps.push([
          dep.id,
          app.id,
          dep.version || null,
          dep.type || null,
          dep.resourceName || null
        ]);
      }
    }

    const runStmt = (stmt, params) => new Promise((resolve, reject) => {
      stmt.run(params, function(err){
        if(err) reject(err);
        else resolve(this);
      });
    });
    const finalizeStmt = (stmt) => new Promise((resolve, reject) => {
      stmt.finalize((err) => err ? reject(err) : resolve());
    });

    await this.db.run('BEGIN IMMEDIATE TRANSACTION');
    let appStmt = null;
    let depStmt = null;
    try{
      await this.db.run('DELETE FROM available_apps_dependency');
      await this.db.run('DELETE FROM available_apps');

      appStmt = this.db.db.prepare(`INSERT INTO available_apps (app_name,repoName,version,description,gitUrl) VALUES (?,?,?,?,?)`);
      for (const row of apps) {
        await runStmt(appStmt, row);
      }
      await finalizeStmt(appStmt);
      appStmt = null;

      depStmt = this.db.db.prepare(`INSERT INTO available_apps_dependency (component_id,parent_id,version,type,resourceName) VALUES (?,?,?,?,?)`);
      for (const row of deps) {
        await runStmt(depStmt, row);
      }
      await finalizeStmt(depStmt);
      depStmt = null;

      await this.db.run('COMMIT');
      this.repoRefreshCache = { hash: payloadHash, at: now, count: apps.length };
      return apps.length;
    }catch(e){
      try{ if(appStmt) await finalizeStmt(appStmt); }catch(_){ }
      try{ if(depStmt) await finalizeStmt(depStmt); }catch(_){ }
      try{ await this.db.run('ROLLBACK'); }catch(_){ }
      throw e;
    }
  }
  async listAppIds(){
    const top=await this.db.all(`SELECT app_name AS id FROM available_apps`);
    const deps=await this.db.all(`SELECT DISTINCT component_id AS id FROM available_apps_dependency`);
    const set=new Set(); top.forEach(r=>r.id&&set.add(r.id)); deps.forEach(r=>r.id&&set.add(r.id));
    return Array.from(set).sort((a,b)=>a.localeCompare(b));
  }
  async versionsFor(id){
    const top=await this.db.all(`SELECT version FROM available_apps WHERE app_name=? AND version IS NOT NULL`,[id]);
    const deps=await this.db.all(`SELECT DISTINCT version FROM available_apps_dependency WHERE component_id=? AND version IS NOT NULL`,[id]);
    const S=new Set(); top.forEach(r=>S.add(r.version)); deps.forEach(r=>S.add(r.version));
    return Array.from(S).filter(Boolean).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}));
  }
  async latestRepoVersionMap(){
    // Mapa id -> versão do repositório (tabela available_apps)
    const rows = await this.db.all(`SELECT app_name AS id, version FROM available_apps WHERE version IS NOT NULL`);
    const map = {};
    for (const r of rows) { map[r.id] = r.version; }
    return map;
  }
  async latestVersionFor(id){
    const normalizedId = String(id || '').trim();
    const repoBrowseMap = {
      'tax4b.automacao': {
        browseUrl: 'https://onesource4sap-repository.thomsonreuters.com/content/browse/release/mtar_18/automacao-backend_tax4b',
        patterns: [/tax4b\.automacao-backend_(\d+\.\d+\.\d+)\.mtar/gi]
      },
      'shadow_tab-ui': {
        browseUrl: 'https://onesource4sap-repository.thomsonreuters.com/content/browse/release/mtar_18/load_shadow_tab-ui_tax4b',
        patterns: [
          /tax4b\.load_shadow_tab-ui_(\d+\.\d+\.\d+)\.mtar/gi,
          /load_shadow_tab-ui_(\d+\.\d+\.\d+)\.mtar/gi,
          /tax4b\.shadow_tab-ui_(\d+\.\d+\.\d+)\.mtar/gi,
          /shadow_tab-ui_(\d+\.\d+\.\d+)\.mtar/gi
        ]
      },
      'tax4b.shadow_tab-ui': {
        browseUrl: 'https://onesource4sap-repository.thomsonreuters.com/content/browse/release/mtar_18/load_shadow_tab-ui_tax4b',
        patterns: [
          /tax4b\.load_shadow_tab-ui_(\d+\.\d+\.\d+)\.mtar/gi,
          /load_shadow_tab-ui_(\d+\.\d+\.\d+)\.mtar/gi,
          /tax4b\.shadow_tab-ui_(\d+\.\d+\.\d+)\.mtar/gi,
          /shadow_tab-ui_(\d+\.\d+\.\d+)\.mtar/gi
        ]
      }
    };
    const repoBrowse = repoBrowseMap[normalizedId];
    if (repoBrowse) {
      try {
        const { data } = await axios.get(repoBrowse.browseUrl, { timeout: 30000 });
        const html = String(data || '');
        const versions = Array.from(new Set(
          repoBrowse.patterns.flatMap(rx => [...html.matchAll(rx)].map(m => m[1]).filter(Boolean))
        )).sort((a,b)=>a.localeCompare(b, undefined, { numeric:true }));
        if (versions.length) return versions[versions.length - 1];
      } catch(_e) { /* fallback para a lógica atual */ }
    }
    const vs = await this.versionsFor(id);
    return vs.length ? vs[vs.length-1] : null;
  }
  async getRepoNameFor(id){
    const row = await this.db.get(`SELECT repoName FROM available_apps WHERE app_name = ? LIMIT 1`, [id]);
    return (row && row.repoName) ? row.repoName : null;
  }
  deriveRepoNameFromId(id){
    if (!id) return '';
    const parts = id.split('.');
    if (parts.length >= 2) {
      const vendor = parts[0]; // ex: tax4b
      const rest = parts.slice(1).join('.'); // ex: app_versoes-db
      return `${rest}_${vendor}`;
    }
    return id.replace(/\./g,'_');
  }
  async buildCandidates(id, version, opts = {}){
    const normalizedId = String(id || '').trim();
    const isApuracaoSpecial = ['tax4b.apuracao_tax4b', 'apuracao_tax4b'].includes(normalizedId);
    const isAutomacaoSpecial = (normalizedId === 'tax4b.automacao');
    const isShadowTabUiSpecial = ['shadow_tab-ui', 'tax4b.shadow_tab-ui'].includes(normalizedId);
    const fromDbRaw = await this.getRepoNameFor(id);
    const derivedRaw = this.deriveRepoNameFromId(id);
    const fromDb = isApuracaoSpecial ? 'apuracao_tax4b' : (isAutomacaoSpecial ? 'automacao-backend_tax4b' : (isShadowTabUiSpecial ? 'load_shadow_tab-ui_tax4b' : fromDbRaw));
    const derived = isApuracaoSpecial ? 'apuracao_tax4b' : (isAutomacaoSpecial ? 'automacao-backend_tax4b' : (isShadowTabUiSpecial ? 'load_shadow_tab-ui_tax4b' : derivedRaw));
    const fileId = isApuracaoSpecial ? 'tax4b.apuracao' : (isAutomacaoSpecial ? 'tax4b.automacao-backend' : (isShadowTabUiSpecial ? 'tax4b.load_shadow_tab-ui' : normalizedId));
    const baseTpl = process.env.MTAR_URL_TEMPLATE ||
      'https://onesource4sap-repository.thomsonreuters.com/content/raw/release/mtar_18/{repoName}/{id}_{version}.mtar';
    const altTpl  = 'https://onesource4sap-repository.thomsonreuters.com/content/raw/release/mtar_18/{repoName}/{id}-{version}.mtar';
    /** 
     * Função (arrow) fill
     * - O que faz: Procedimento/serviço utilizado no fluxo atual.
     * - Retorno: Conforme uso do chamador.
     * @param {{any}} tpl 
     * @param {{any}} repo 
     */
    const fill = (tpl, repo) => tpl
      .replace(/\{repoName\}/g, repo)
      .replace(/\{id\}/g, fileId)
      .replace(/\{version\}/g, version);
    const urls = [];
    if (fromDb) { urls.push(fill(baseTpl, fromDb)); urls.push(fill(altTpl, fromDb)); }
    if (derived && derived !== fromDb) { urls.push(fill(baseTpl, derived)); urls.push(fill(altTpl, derived)); }
    
    // --- Preferência do usuário: normal vs unshipped ---
    // opts.preferredFolder: 'normal' | 'unshipped' (default: normal)
    let __pref = '';
    try{ __pref = String(opts && opts.preferredFolder || '').toLowerCase(); }catch(_){ __pref = ''; }
    const __forceUnshipped = (__pref === 'unshipped');
    const __forceNormal = (__pref === 'normal');

    // Se o usuário escolher unshipped, tenta primeiro (independente do tipo)
    if (__forceUnshipped){
      try{
        const unshippedUrls = urls.map(u => u.replace(/(\/mtar_18\/[^\/]+\/)/, "$1unshipped/"));
        urls.unshift(...unshippedUrls);
      }catch(_){ }
    }
    
    // --- CF rules ---
    // 1) CF + backend: prioriza "unshipped" (ex.: .../{repoName}/unshipped/{id}_{version}.mtar)
    // 2) CF + -ui: tenta "cf" subfolder primeiro (ex.: .../{repoName}/cf/{id}_{version}.mtar)
    try{
      const envType = String(this.envTypeHint||'').toUpperCase();
      if (envType === 'CF'){
        const isUi = /-ui$/i.test(id);
        const isDb = /-db$/i.test(id);
        const isBackend = /backend/i.test(id) && !isUi && !isDb;

        if (isBackend && !__forceNormal){
          const unshippedUrls = urls.map(u => u.replace(/(\/mtar_18\/[^\/]+\/)/, "$1unshipped/"));
          // Prepend unshipped candidates to be tried first
          urls.unshift(...unshippedUrls);
        }

        if (isUi){
          const cfUrls = urls.map(u => u.replace(/(\/mtar_18\/[^\/]+\/)/, "$1cf/"));
          // Prepend CF candidates to be tried first
          urls.unshift(...cfUrls);
        }
      }
    }catch(__e){/*noop*/}

    // Se o usuário escolher 'normal', removemos candidatos de unshipped
    if (__forceNormal){
      try{
        for (let i = urls.length - 1; i >= 0; i--){
          if (String(urls[i]).includes('/unshipped/')) urls.splice(i,1);
        }
      }catch(_){ }
    }

    return Array.from(new Set(urls));
}
  async resolveMtarUrl(id, version, opts, onLog){
    // Backward-compat: (id, version, onLog)
    if (typeof opts === 'function' && onLog === undefined){ onLog = opts; opts = {}; }
    opts = opts || {};
    const candidates = await this.buildCandidates(id, version, opts);
    /** 
     * Função (arrow) log
     * - O que faz: Procedimento/serviço utilizado no fluxo atual.
     * - Retorno: Conforme uso do chamador.
     * @param {{any}} t 
     */
    const log = (t)=>{ try{ onLog && onLog(t);}catch(_){}};
    for (const url of candidates){
      try{
        log(`Testando URL: ${url}`);
        const head = await axios.head(url, { timeout: 20000, maxRedirects: 5, validateStatus: ()=>true });
        log(`HEAD => ${head.status}`);
        if (head.status >= 200 && head.status < 300) return url;
        const check = await axios.get(url, { responseType: 'stream', timeout: 20000, maxRedirects: 5, validateStatus: ()=>true });
        log(`GET(check) => ${check.status}`);
        if (check.status >= 200 && check.status < 300) { try { check.data.destroy(); } catch(_){ } return url; }
      }catch(e){
        log(`Falha na verificação: ${(e && e.message) || e}`);
      }
    }
    throw new Error('Nenhuma URL válida encontrada para o MTAR.');
  }
  async buildMtarUrl(id, version){
    // Mantém compatível se alguém ainda chamar este método: usa o candidato principal (underscore).
    const normalizedId = String(id || '').trim();
    const isApuracaoSpecial = ['tax4b.apuracao_tax4b', 'apuracao_tax4b'].includes(normalizedId);
    const isAutomacaoSpecial = (normalizedId === 'tax4b.automacao');
    const isShadowTabUiSpecial = ['shadow_tab-ui', 'tax4b.shadow_tab-ui'].includes(normalizedId);
    const repo = isApuracaoSpecial
      ? 'apuracao_tax4b'
      : (isAutomacaoSpecial ? 'automacao-backend_tax4b' : (isShadowTabUiSpecial ? 'load_shadow_tab-ui_tax4b' : ((await this.getRepoNameFor(id)) || this.deriveRepoNameFromId(id))));
    const fileId = isApuracaoSpecial ? 'tax4b.apuracao' : (isAutomacaoSpecial ? 'tax4b.automacao-backend' : (isShadowTabUiSpecial ? 'tax4b.load_shadow_tab-ui' : normalizedId));
    const tpl = process.env.MTAR_URL_TEMPLATE ||
      'https://onesource4sap-repository.thomsonreuters.com/content/raw/release/mtar_18/{repoName}/{id}_{version}.mtar';
    return tpl.replace(/\{repoName\}/g, repo).replace(/\{id\}/g, fileId).replace(/\{version\}/g, version);
  }

  // ===== Dependencies validation (robust) =====
  async _tableExists(name){
    try{
      const row = await this.db.get('select name from sqlite_master where type=? and name=?', ['table', name]);
      return !!row;
    }catch(_e){ return false; }
  }
  _vkey(v){ return String(v||'0').split('.').map(x=>String(x).padStart(3,'0')).join(''); }
  async validateInstallSet(envId, appsToInstall){
    // Resolve tabela de ambientes dinamicamente
    const envTable = (await this._tableExists('environments')) ? 'environments'
                    : (await this._tableExists('enviroments')) ? 'enviroments'
                    : null;
    if (!envTable) { return []; }

    // Resolve a coluna do "nome do ambiente"
    const envNameCol = (await this._firstExistingColumn(envTable, ['environment','name','enviroment'])) || 'name';

    // Resolve installed_apps e coluna de chave estrangeira (source/environment/env)
    const hasInstalled = await this._tableExists('installed_apps');
    let installedSourceCol = 'source';
    if (hasInstalled){
      const alt = await this._firstExistingColumn('installed_apps', ['source','environment','env','env_id']);
      installedSourceCol = alt || 'source';
    }

    // Busca ambiente por id ou nome
    const envRow = await this.db.get(
      'select e.id as id, e.' + envNameCol + ' as name from ' + envTable + ' e where e.id = ? or e.' + envNameCol + ' = ?',
      [envId, envId]
    );

    // Dependências por app selecionado
    const dependencyApps = await this.db.all(
      'select parent_id, component_id as component, max(version) as version from available_apps_dependency group by component_id, parent_id',
      []
    );

    
    
    // Versões instaladas neste ambiente (busca todas e resolve maior via _vkey)
    /** 
     * Função (arrow) fetchInstalled
     * - O que faz: Procedimento/serviço utilizado no fluxo atual.
     * - Retorno: Conforme uso do chamador.
     * @param {{any}} key 
     */
    const fetchInstalled = async (key) => {
      if (!hasInstalled) return [];
      if (!key && key !== 0) return [];
      const rows = await this.db.all(
        'select component, version from installed_apps where ' + installedSourceCol + ' = ?',
        [key]
      );
      return Array.isArray(rows) ? rows : [];
    };
    const installedByName = await fetchInstalled(envRow && envRow.name);
    const installedById   = await fetchInstalled(envRow && envRow.id);
    const installedAll = [].concat(installedByName||[], installedById||[]);
// Consolidar maior versão por componente via _vkey
    const best = new Map();
    for (const r of (installedAll||[])){
      const comp = this.__normComp(r.component);
      const v = this.__normVer(r.version || '0.0.0');
      const prev = best.get(comp);
      if (!prev || this._vkey(v) > this._vkey(prev)) best.set(comp, v);
    }
    const installedApps = Array.from(best, ([component, version]) => ({ component, version }));
// Requisitos (maior versão por componente exigida pelos apps selecionados)
    const selectedSet = new Set((appsToInstall||[]).map(a => a.app_name));
    const reqs = new Map();
    for (const d of (dependencyApps||[])){
      if (!selectedSet.has(d.parent_id)) continue;
      const compRaw = d.component;
      const comp = this.__normComp(compRaw);
      const v = this.__normVer(d.version || '0');
      const prev = reqs.get(comp);
      if (!prev || this._vkey(v) > this._vkey(prev)) reqs.set(comp, v);
    }

    // Compara instalado x requerido
    const ret = [];
    for (const [comp, reqV] of reqs.entries()){
      const key = this.__normComp(comp);
      const found = (installedApps||[]).find(r => r.component === key);
      const instV = this.__normVer((found && found.version) || '0.0.0');
      if (this._vkey(instV) < this._vkey(this.__normVer(reqV))){
        ret.push({ id: key, version: this.__normVer(reqV) });
      }
    }
    return ret;
}

  async _columnExists(table, col){
    try{
      const rows = await this.db.all('PRAGMA table_info(' + table + ')', []);
      return Array.isArray(rows) && rows.some(r => (r.name||'').toLowerCase() === String(col).toLowerCase());
    }catch(_e){ return false; }
  }

  async _firstExistingColumn(table, candidates){
    for (const c of candidates){
      if (await this._columnExists(table, c)) return c;
    }
    return null;
  }

}

// =============== Views (HTML) ===============
/** 
 * Classe LoginView
 * - O que faz: Representa uma entidade/serviço com estado e comportamentos.
 * - Observação: Métodos internos seguem as regras originais do código.
 */
class LoginView {
  static html(){
    return `<!DOCTYPE html><html lang="pt-br"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<link<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<style>${baseCss}
.page{min-height:100vh;display:flex;align-items:center;justify-content:center;flex-direction:column;padding:24px}
.stack{width:min(360px,92vw)}
.stack img{max-width:200px;height:auto;margin:0 auto 12px;display:block}
.stack label{display:block;margin-top:8px;font-size:13px;color:#334155}
.stack input{width:100%}
.stack .btn{width:100%;justify-content:center;margin-top:12px}
.link{display:block;text-align:center;margin-top:10px;font-size:13px;color:#6366f1;cursor:pointer}
.msg{min-height:18px;font-size:12px;color:#475569;margin-top:8px;text-align:center}
.actions{display:flex;gap:8px;align-items:center}
#overviewTable td.actions-cell{white-space:nowrap}

/* === Estilo azul claro para botão Entrar da tela inicial === */
#btnLogin {
  background-color: #eef2ff !important;
  border-color: #a5b4fc !important;
  color: #000 !important;
}
#btnLogin:hover {
  background-color: #c7d2fe !important;
}
/* === fim estilo azul claro botão Entrar === */

/* === Borda cinza mais forte + sombra suave na tela inicial === */
.login-container {
  border: 1px solid #9ca3af !important;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}
/* === fim borda + sombra === */

/* === Borda cinza clara + sombra suave nos diálogos === */
dialog {
  border: 1px solid #9ca3af !important;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}
/* === fim borda + sombra diálogos === */

#btnUpdateRepo, #btnLoadStatus {
  background-color: #fef3c7 !important;
  border-color: #fcd34d !important;
  color: #000 !important;
}
#btnUpdateRepo:hover, #btnLoadStatus:hover {
  background-color: #fef3c7 !important;
}
/* === fim estilo amarelo claro === */

.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.header img,
.header .title-block {
  display: inline-flex;
  align-items: center;
}
.header .title-block {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 8px;
}

/* === Centralizar logo + título no cabeçalho, mantendo botões à direita === */
.container > .header {
  position: relative !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important; /* centro exato do cabeçalho */
}
.container > .header .right {
  position: absolute !important;
  right: 14px !important;
  top: 50% !important;
  transform: translateY(-50%) !important;
  margin-left: 0 !important; /* neutraliza empurrão para a esquerda */
}
.container > .header img {
  display: inline-flex !important;
  align-items: center !important;
  margin-right: 8px !important;
}
.container > .header .title-block {
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  flex: 0 0 auto !important;   /* não expandir para lados */
  text-align: center !important;
  margin: 0 !important;
}
/* === fim centralização logo + título === */
.login-wrap{display:flex;flex-direction:column;align-items:center;justify-content:center}
.login-wrap .after-card-note{margin-top:8px}
</style>

</head><body>
<div class="page">
  <div class="login-wrap">
    <div class="card stack empresas-form">
    <img src="/static/logo.png" alt="Alliance Consultoria">
    
    <!-- TÍTULO DE BOAS-VINDAS -->
    <h2 style="text-align:center; margin:12px 0; font-size:20px; color:#666666;font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;  font-weight: 600;">Bem-vindo ao Atualizador de Componentes</h2>
    <!-- fim título -->
<label>Usuário</label><input id="username" autocomplete="username">
    <label>Senha</label><input id="password" type="password" autocomplete="current-password">
    <button class="btn" id="btnLogin">Entrar</button>
    <div id="msg" class="msg"></div>
    <div id="forgot" class="link">Esqueci minha senha</div>

  </div>

<!-- TEXTO ADICIONADO FORA DO CARD -->
<div class="after-card-note" style="margin-top:6px; text-align:center; font-size:12px; color:#777; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b></b>
</div>
<!-- fim texto adicionado -->
</div>
<script>

// ===== Report Mode Isolation (injected) =====
(function(){
  try {
    if (typeof window !== 'undefined') {
      if (!('__REPORT_MODE' in window)) window.__REPORT_MODE = false;
      // Universal capturing guards to suppress unrelated UI while in report mode
      var capGuard = function(ev){
        try{
          var insideReport = ev.target && (ev.target.closest('#dlgReport') || ev.target.closest('#btnReport'));
          if (window.__REPORT_MODE && !insideReport) {
            ev.stopImmediatePropagation && ev.stopImmediatePropagation();
            return;
          }
        }catch(_){}
      };
      ['click','change','input','submit'].forEach(function(type){
        document.addEventListener(type, capGuard, true); // capture phase
      });
      window.__enterReportMode = function(){ window.__REPORT_MODE = true; };
      window.__exitReportMode  = function(){ window.__REPORT_MODE = false; };
    }
  } catch(e){ try{ console.warn('ReportMode guard init failed', e); }catch(_){ } }

// Observa mudanças na tabela para reaplicar a regra em PRD
(function(){
  try{
    var _tbl = document.getElementById('overviewTable');
    if(!_tbl || window.__overviewObserverAdded) return;
    window.__overviewObserverAdded = true;
    var mo = new MutationObserver(function(muts){
      var st = (typeof __getSelectedEnvStage==='function' && __getSelectedEnvStage()) || null;
      if (__isProdStage(st)) { try{ __toggleProdOnlyButtons(st); }catch(_){ } }
    });
    mo.observe(_tbl, {childList:true, subtree:true});
  }catch(_){}
})();

})();
// ===== End Report Mode Isolation =====

async function safeJson(resp){
  try{
    const ct = resp.headers && resp.headers.get ? (resp.headers.get('content-type')||'') : '';
    if (ct.includes('application/json')) return await resp.json();
    const text = await resp.text();
    try{ return JSON.parse(text); } catch(_){ return { ok:false, error: text || 'Resposta não é JSON' }; }
  }catch(e){
    return { ok:false, error: e && e.message ? e.message : String(e) };
  }
}

const $ = (s)=>document.querySelector(s);
$('#btnLogin').addEventListener('click',async function(){

// Habilitar tecla Enter nos campos de login
['#username','#password'].forEach(function(sel){
  var el = document.querySelector(sel);
  if(el){
    el.addEventListener('keydown', function(ev){
      if(ev.key === 'Enter'){
        ev.preventDefault();
        try{ document.getElementById('btnLogin').click(); }catch(_){}
      }
    });
  }
});

  const username=$('#username').value.trim(), password=$('#password').value;
  $('#msg').textContent='Validando...';
  try{
    const r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json', 'X-Edit-Id': String((typeof document!=='undefined' && document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : ((typeof window!=='undefined' && window.currentEditId) ? window.currentEditId : ''))},body:JSON.stringify({username,password})});
    const j=await r.json(); if(j.ok){location.href='/';} else{$('#msg').textContent=j.error||'Falha no login';}
  }catch(e){$('#msg').textContent=e.message||e;}
});
$('#forgot').addEventListener('click',async function(){
  const email=prompt('Informe seu e-mail cadastrado:'); if(!email) return;
  try{
    const r=await fetch('/api/forgot',{method:'POST',headers:{'Content-Type':'application/json', 'X-Edit-Id': String((typeof document!=='undefined' && document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : ((typeof window!=='undefined' && window.currentEditId) ? window.currentEditId : ''))},body:JSON.stringify({email})});
    const j=await r.json(); customAlert(j.ok?'Se o e-mail existir, você receberá instruções.':(j.error||'Não foi possível processar.'));
  }catch(e){customAlert(e.message||e);}
});

// --- Rollback per-row: open live stream page ---
try{
  // Listen dialog select changes
  document.addEventListener('change', function(ev){
  if (window.__REPORT_MODE && !(ev.target && (ev.target.closest('#dlgReport') || ev.target.closest('#btnReport')))) { return; }

    var t = ev.target;
    if (t && t.id === 'rep_env_select'){
            // Report-only: do NOT sync with header or dispatch global changes
      try{ updateHiddenFromDialog(); }catch(_){ }
}
  });
  
  document.addEventListener('click', function(ev){
  if (window.__REPORT_MODE && !(ev.target && (ev.target.closest('#dlgReport') || ev.target.closest('#btnReport')))) { return; }

    var t = ev.target;
    if (t && t.classList && t.classList.contains('btnRollbackRow')){
      // Se ambiente for Produção, não deixa executar rollback
      try{
        var __st = (typeof __getSelectedEnvStage==='function' && __getSelectedEnvStage()) || null;
        if (typeof __isProdStage === 'function' && __isProdStage(__st)) {
          // Garante visual de desabilitado também
          t.setAttribute('data-disabled','1');
          t.setAttribute('aria-disabled','true');
          t.setAttribute('tabindex','-1');
          t.disabled = true;
          if (t.classList) t.classList.add('disabled');
          t.style.opacity = '0.5';
          t.style.pointerEvents = 'none';
          t.style.filter = 'grayscale(1)';
          t.style.cursor = 'not-allowed';
          if(!t.getAttribute('title')) t.setAttribute('title','Indisponível em Produção');
          customAlert('Rollback indisponível em Produção.');
          return;
        }
      }catch(_){}

      var id = t.getAttribute('data-id') || '';
      var sel = document.getElementById('envSelectHeader') || document.getElementById('environmentSelect');
      if(!sel || !sel.value){ customAlert('Selecione um ambiente.'); return; }
      var url = '/api/rollback/live?env_id=' + encodeURIComponent(sel.value) + '&component_id=' + encodeURIComponent(id);
      try{ window.open(url, '_blank'); }catch(_){ location.href = url; }
    }
  });
}catch(_){}
// --- /Rollback per-row ---

// === Tecla Enter para login (LoginView) ===
/* Report isolation guard */
document.addEventListener('click', function(ev){
  if (window.__REPORT_MODE && !(ev.target && (ev.target.closest('#dlgReport') || ev.target.closest('#btnReport')))) { return; }

  try{
    if (window.__reportOpen && ev.target && ev.target.closest && ev.target.closest('#dlgReport')){
      ev.stopPropagation();
    }
  }catch(_){ }
}, true);
document.addEventListener('change', function(ev){
  if (window.__REPORT_MODE && !(ev.target && (ev.target.closest('#dlgReport') || ev.target.closest('#btnReport')))) { return; }

  try{
    if (window.__reportOpen && ev.target && ev.target.closest && ev.target.closest('#dlgReport')){
      ev.stopPropagation();
    }
  }catch(_){ }
}, true);
document.addEventListener('DOMContentLoaded', function(){
  try{
    var u = document.getElementById('username');
    var p = document.getElementById('password');
    var b = document.getElementById('btnLogin');
    if(u && p && b){
      [u, p].forEach(function(el){
        el.addEventListener('keydown', function(ev){
          if(ev.key === 'Enter'){
            ev.preventDefault();
            try{ b.click(); }catch(_){}
          }
        });
      });
    }
  }catch(_){}
});
// === fim tecla Enter ===
</script>
<script>
document.addEventListener('DOMContentLoaded', function(){
  // Capturing listener cancels inline onclick/href and uses SSE
  document.addEventListener('click', async function(ev){
  if (window.__REPORT_MODE && !(ev.target && (ev.target.closest('#dlgReport') || ev.target.closest('#btnReport')))) { return; }

    var el = ev.target && ev.target.closest('.btnRollbackRow, #btnRollback, [data-action="rollback"]');
    if(!el) return;
      // Guard: ignore clicks on Report button/dialog so no other screens run
  if (ev.target && (ev.target.closest('#btnReport') || ev.target.closest('#dlgReport'))) {
    return;
  }
// Cancel any default navigation and inline handlers
    ev.preventDefault();
    ev.stopPropagation();
    ev.stopImmediatePropagation();
    try { el.onclick = null; el.setAttribute && el.setAttribute('onclick',''); }catch(_){}

    try{
      var id = el.getAttribute('data-id') || (el.closest('[data-component-id]') && el.closest('[data-component-id]').getAttribute('data-component-id')) || '';
      var sel = document.getElementById('envSelectHeader') || document.getElementById('environmentSelect');
      if(!sel || !sel.value){ customAlert('Selecione um ambiente.'); return; }
      if(!id){ customAlert('ID do componente não encontrado.'); return; }
      var pwd = await await customPasswordPrompt('Informe a senha do usuário do ambiente para executar o rollback:');
          if(!pwd) return;
          // Start rollback via token
      const rs = await fetch('/api/rollback-start', {
        method:'POST',
        headers:{'Content-Type':'application/json', 'X-Edit-Id': String((typeof document!=='undefined' && document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : ((typeof window!=='undefined' && window.currentEditId) ? window.currentEditId : ''))},
        body: JSON.stringify({ envId: sel.value, objectId: id, password: pwd, ticket: (await customTicketPrompt('Informe o número do chamado (ticket):'))?.trim(), packageSource: (typeof __getMtarSource==='function' ? __getMtarSource() : 'normal') })
      });
      const js = await rs.json();
      if(!js.ok){ customAlert(js.error || 'Falha ao iniciar rollback'); return; }

      // Show Deploy (tempo real) and stream there
      var wrap = document.getElementById('deployWrap');
      var box = document.getElementById('deployBox');
      var status = document.getElementById('deployStatus');
      if (wrap) wrap.style.display = 'block';
      if (box) box.textContent = '';
      if(status) status.textContent='rollback'; try{ document.getElementById('deployProgress').style.display='block'; }catch(_){}

      const es = new EventSource('/api/rollback-stream?token=' + encodeURIComponent(js.token));
      es.onmessage = function(ev2){
        if (!box) return;
        box.textContent += (ev2.data||'') + '\\n';
        box.scrollTop = box.scrollHeight;
      };
      es.addEventListener('done', function(ev2){
        try{
          const payload = JSON.parse(ev2.data||'{}');
          if(status) status.textContent = payload.ok ? 'concluído' : 'erro'; try{ document.getElementById('deployProgress').style.display='none'; }catch(_){}
          if (box) box.textContent += '\\n--- rollback ' + (payload.ok?'concluído com sucesso.':'finalizado com erro.');
            customAlert(payload.ok ? 'Rollback concluído com sucesso.' : 'Rollback finalizado com erro. Verifique os logs.' ) + '\\n';
        }catch(_){}
        es.close();
        var btn = document.getElementById('btnOverview'); if(btn) btn.click();
      });
      es.onerror = function(){ if(status) status.textContent='erro'; try{ document.getElementById('deployProgress').style.display='none'; }catch(_){} es.close(); };
    }catch(e){
      customAlert(e.message||e);
    }
  }, true); // capture = true
});
document.addEventListener('DOMContentLoaded', function(){
  const btnOpen = document.getElementById('btnOpenCreateUser');
  const dlg = document.getElementById('dlgCreateUser');
  const btnCancel = document.getElementById('btnCreateUserCancel');
  const btnSave = document.getElementById('btnCreateUserSave');

  if(btnOpen && dlg){
    btnOpen.addEventListener('click', ()=>{
      if(typeof dlg.showModal==='function') dlg.showModal(); else dlg.style.display='block';
    });
  }
  if(btnCancel && dlg){
    btnCancel.addEventListener('click', ()=>{
      if(typeof dlg.close==='function') dlg.close(); else dlg.style.display='none';
    });
  }
  if(btnSave){
    btnSave.addEventListener('click', async ()=>{
      const username = document.getElementById('cuUsername').value.trim();
      const email = document.getElementById('cuEmail').value.trim();
      const password = document.getElementById('cuPassword').value;
      const role = document.getElementById('cuRole').value;
      if(!username || !email || !password){ customAlert('Preencha usuário, e-mail e senha.'); return; }
      const r = await fetch('/api/users', {
        method:'POST',
        headers:{'Content-Type':'application/json', 'X-Edit-Id': String((typeof document!=='undefined' && document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : ((typeof window!=='undefined' && window.currentEditId) ? window.currentEditId : ''))},
        body: JSON.stringify({ username,email,password,role })
      });
      const j = await r.json();
      if(j.ok){
        customAlert('Usuário criado!');
        if(typeof dlg.close==='function') dlg.close(); else dlg.style.display='none';
      }else{
        customAlert(j.error || 'Erro ao criar usuário');
      }
    });
  }
});
</script>

<!-- Polyfill para <dialog> em navegadores sem suporte -->
<script>
(function() {
  if (typeof HTMLDialogElement === 'undefined') {
        document.querySelectorAll('dialog').forEach(function(dlg){
      if(!dlg.showModal){
        dlg.showModal = function(){
          this.style.display = 'block';
        };
      }
      if(!dlg.close){
        dlg.close = function(){
          this.style.display = 'none';
        };
      }
    });
  }
})();
</script>
<!-- BEGIN Utilities (customAlert, toast, theme) -->
<div class="toast-container" id="toastContainer"></div>
<dialog id="customAlert" style="border:1px solid #9ca3af;border-radius:8px;padding:18px;max-width:520px;box-shadow:0 2px 10px rgba(0,0,0,.12)">
  <h3 style="margin:0 0 8px;font-size:16px">TAXONE FOR SAP Solutions diz:</h3>
  <div id="customAlertMsg" style="font-size:14px;line-height:1.4"></div>
  <div style="text-align:right;margin-top:14px">
    <button id="customAlertOk" class="btn">OK</button>
  </div>
</dialog>
<script>
(function(){
/** 
 * Função ensureAlert
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem ensureAlert.
 * - Retorno: Valor compatível com o uso corrente.

 */
function ensureAlert(){
    var dlg=document.getElementById('customAlert');
    if(!dlg){
      dlg=document.createElement('dialog'); dlg.id='customAlert';
      dlg.innerHTML='<h3>TAXONE FOR SAP Solutions diz:</h3><div id="customAlertMsg"></div><div style="text-align:right;margin-top:12px"><button id="customAlertOk" class="btn">OK</button></div>';
      document.body.appendChild(dlg);
    }
    var ok=document.getElementById('customAlertOk');
    if(ok){ ok.onclick=function(){ if(dlg.close) dlg.close(); else dlg.style.display='none'; }; }
    return dlg;
  }
  window.customAlert = function(msg){
    var dlg=ensureAlert();
    var box=document.getElementById('customAlertMsg'); if(box) box.textContent=(msg==null?'':String(msg));
    if(dlg.showModal) dlg.showModal(); else dlg.style.display='block';
  };
  window.toast = function(msg, type){
    var wrap=document.getElementById('toastContainer'); if(!wrap){ wrap=document.createElement('div'); wrap.id='toastContainer'; wrap.className='toast-container'; document.body.appendChild(wrap); }
    var t=document.createElement('div'); t.className='toast ' + (type||'info'); t.textContent=String(msg||''); wrap.appendChild(t);
    setTimeout(function(){ t.style.opacity='0'; setTimeout(function(){ t.remove(); }, 320); }, 3200);
  };
  
})();
</script>
<!-- END Utilities -->
<!-- BEGIN: Password Prompt -->
<dialog id="customPwdDialog" style="border:1px solid #9ca3af;border-radius:8px;padding:18px;max-width:520px;box-shadow:0 2px 10px rgba(0,0,0,.12)">
  <h3 style="margin:0 0 8px;font-size:16px">TAXONE FOR SAP Solutions diz:</h3>
  <div class="muted" id="customPwdMsg" style="margin-bottom:8px;font-size:14px;line-height:1.4"></div>
  <input id="customPwdInput" type="password" style="width:100%;-webkit-text-security:disc;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px">
  <div style="text-align:right;margin-top:12px;display:flex;gap:8px;justify-content:flex-end">
    <button id="customPwdCancel" class="btn">Cancelar</button>
    <button id="customPwdOk" class="btn">OK</button>
  </div>
</dialog>
<script>
(function(){
  window.customPasswordPrompt = function(message){
    return new Promise(function(resolve){
      var dlg = document.getElementById('customPwdDialog');
      if(!dlg){
        dlg = document.createElement('dialog');
        dlg.id = 'customPwdDialog';
        dlg.innerHTML = '<h3>TAXONE FOR SAP Solutions diz:</h3>' +
                        '<div id="customPwdMsg" class="muted" style="margin-bottom:8px"></div>' +
                        '<input id="customPwdInput" type="password" style="-webkit-text-security:disc;width:100%;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px">' +
                        '<div style="text-align:right;margin-top:12px"><button id="customPwdCancel" class="btn">Cancelar</button> <button id="customPwdOk" class="btn">OK</button></div>';
        document.body.appendChild(dlg);
      }
      var msg = document.getElementById('customPwdMsg');
      if(msg){ msg.textContent = message || 'Informe a senha:'; }
      var input = document.getElementById('customPwdInput');
      if(input){ input.value=''; input.setAttribute('type','password'); input.style.webkitTextSecurity='disc'; }
      /** 
       * Função onCancel
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onCancel.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onCancel(){ try{ dlg.close(); }catch(_){} cleanup(); resolve(null); }
      /** 
       * Função onOk
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onOk.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onOk(){ var v=input?input.value:''; try{ dlg.close(); }catch(_){} cleanup(); resolve(v); }
      /** 
       * Função onKey
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onKey.
       * - Retorno: Valor compatível com o uso corrente.
       * @param {{any}} e 
       */
      function onKey(e){ if(e.key==='Enter'){ e.preventDefault(); onOk(); } }
      /** 
       * Função cleanup
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem cleanup.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function cleanup(){
        try {
          document.getElementById('customPwdOk')?.removeEventListener('click', onOk);
          document.getElementById('customPwdCancel')?.removeEventListener('click', onCancel);
          input?.removeEventListener('keydown', onKey);
        } catch(_){}
      }
      document.getElementById('customPwdOk')?.addEventListener('click', onOk);
      document.getElementById('customPwdCancel')?.addEventListener('click', onCancel);
      input?.addEventListener('keydown', onKey);
      try{ input?.focus(); }catch(_){}
      if(dlg.showModal){ dlg.showModal(); } else { dlg.style.display='block'; }
    });
  };
})();
</script>
<!-- END: Password Prompt -->
<!-- BEGIN: Ticket Prompt -->
<dialog id="customTicketDialog" style="border:1px solid #9ca3af;border-radius:8px;padding:18px;max-width:520px;box-shadow:0 2px 10px rgba(0,0,0,.12)">
  <h3 style="margin:0 0 8px;font-size:16px">TAXONE FOR SAP Solutions diz:</h3>
  <div class="muted" id="customTicketMsg" style="margin-bottom:8px;font-size:14px;line-height:1.4"></div>
  <input id="customTicketInput" type="text" style="width:100%;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px" placeholder="Número do chamado (ticket)">
  <div style="text-align:right;margin-top:12px;display:flex;gap:8px;justify-content:flex-end">
    <button id="customTicketCancel" class="btn">Cancelar</button>
    <button id="customTicketOk" class="btn">OK</button>
  </div>
</dialog>
<script>
(function(){
  window.customTicketPrompt = function(message){
    return new Promise(function(resolve){
      var dlg = document.getElementById('customTicketDialog');
      if(!dlg){
        dlg = document.createElement('dialog');
        dlg.id = 'customTicketDialog';
        dlg.innerHTML = '<h3>TAXONE FOR SAP Solutions diz:</h3>' +
                        '<div id="customTicketMsg" class="muted" style="margin-bottom:8px"></div>' +
                        '<input id="customTicketInput" type="text" style="width:100%;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px" placeholder="Número do chamado (ticket)">' +
                        '<div style="text-align:right;margin-top:12px"><button id="customTicketCancel" class="btn">Cancelar</button> <button id="customTicketOk" class="btn">OK</button></div>';
        document.body.appendChild(dlg);
      }
      var msg = document.getElementById('customTicketMsg');
      if(msg){ msg.textContent = message || 'Informe o número do chamado (ticket):'; }
      var input = document.getElementById('customTicketInput');
      if(input){ input.value=''; }
      /** 
       * Função onCancel
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onCancel.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onCancel(){ try{ dlg.close(); }catch(_){} cleanup(); resolve(null); }
      /** 
       * Função onOk
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onOk.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onOk(){ var v=input?String(input.value||'').trim():''; try{ dlg.close(); }catch(_){} cleanup(); resolve(v); }
      /** 
       * Função onKey
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onKey.
       * - Retorno: Valor compatível com o uso corrente.
       * @param {{any}} e 
       */
      function onKey(e){ if(e.key==='Enter'){ e.preventDefault(); onOk(); } }
      /** 
       * Função cleanup
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem cleanup.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function cleanup(){
        try {
          document.getElementById('customTicketOk')?.removeEventListener('click', onOk);
          document.getElementById('customTicketCancel')?.removeEventListener('click', onCancel);
          input?.removeEventListener('keydown', onKey);
        } catch(_){}
      }
      document.getElementById('customTicketOk')?.addEventListener('click', onOk);
      document.getElementById('customTicketCancel')?.addEventListener('click', onCancel);
      input?.addEventListener('keydown', onKey);
      try{ input?.focus(); }catch(_){}
      if(dlg.showModal){ dlg.showModal(); } else { dlg.style.display='block'; }
    });
  };
})();
</script>

<!-- END: Ticket Prompt -->

<footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b></b>
<footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b></b>
</footer>
<footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b>Desenvolvido por AMS Sustentação - Alliance Consultoria V3.0</b>
</footer>
</body></html>`;
  }
}

/** 
 * Classe ResetView
 * - O que faz: Representa uma entidade/serviço com estado e comportamentos.
 * - Observação: Métodos internos seguem as regras originais do código.
 */
class ResetView {
  static html(token,email){
    return `<!DOCTYPE html><html lang="pt-br"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Redefinir senha</title>
<style>${baseCss}
.page{min-height:100vh;display:flex;align-items:center;justify-content:center;flex-direction:column;padding:24px}
.stack{width:min(360px,92vw)}
.stack img{max-width:180px;height:auto;margin:0 auto 10px;display:block}
.muted{color:#475569;font-size:13px;margin-bottom:6px;text-align:center}
.stack input{width:100%}
.stack .btn{width:100%;justify-content:center;margin-top:10px}
.msg{min-height:18px;font-size:12px;color:#475569;margin-top:8px;text-align:center}
.actions{display:flex;gap:8px;align-items:center}
#overviewTable td.actions-cell{white-space:nowrap}
.login-wrap{display:flex;flex-direction:column;align-items:center;justify-content:center}
.login-wrap .after-card-note{margin-top:8px}
</style>

</head><body>
<div class="page">
  <div class="login-wrap">
    <div class="card stack empresas-form">
    <img src="/static/logo.png" alt="Alliance Consultoria">
    <h1 style="font-size:18px;margin:4px 0 8px;text-align:center">Redefinir senha</h1>
    <div class="muted">Conta: <strong>` + String(email||'') + `</strong></div>
    <input id="password" type="password" placeholder="Nova senha" autocomplete="new-password">
    <button class="btn" id="btn">Salvar nova senha</button>
    <div id="msg" class="msg"></div>
  </div>

<!-- TEXTO ADICIONADO FORA DO CARD -->
<div class="after-card-note" style="margin-top:6px; text-align:center; font-size:12px; color:#777; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  
</div>
<!-- fim texto adicionado -->
</div>
<script>
const token=` + JSON.stringify(token||'') + `;
document.getElementById('btn').addEventListener('click',async function(){
  const password=document.getElementById('password').value;
  const r=await fetch('/api/reset',{method:'POST',headers:{'Content-Type':'application/json', 'X-Edit-Id': String((typeof document!=='undefined' && document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : ((typeof window!=='undefined' && window.currentEditId) ? window.currentEditId : ''))},body:JSON.stringify({token,password})});
  const j=await r.json();
  document.getElementById('msg').textContent=j.ok?'Senha redefinida! Faça login.':(j.error||'Erro ao redefinir');
  if(j.ok) setTimeout(()=>{location.href='/login';},1000);
});
</script>
<script>
document.addEventListener('DOMContentLoaded', function(){
  // Capturing listener cancels inline onclick/href and uses SSE
  document.addEventListener('click', async function(ev){
  if (window.__REPORT_MODE && !(ev.target && (ev.target.closest('#dlgReport') || ev.target.closest('#btnReport')))) { return; }

    var el = ev.target && ev.target.closest('.btnRollbackRow, #btnRollback, [data-action="rollback"]');
    if(!el) return;
      // Guard: ignore clicks on Report button/dialog so no other screens run
  if (ev.target && (ev.target.closest('#btnReport') || ev.target.closest('#dlgReport'))) {
    return;
  }
// Cancel any default navigation and inline handlers
    ev.preventDefault();
    ev.stopPropagation();
    ev.stopImmediatePropagation();
    try { el.onclick = null; el.setAttribute && el.setAttribute('onclick',''); }catch(_){}

    try{
      var id = el.getAttribute('data-id') || (el.closest('[data-component-id]') && el.closest('[data-component-id]').getAttribute('data-component-id')) || '';
      var sel = document.getElementById('envSelectHeader') || document.getElementById('environmentSelect');
      if(!sel || !sel.value){ customAlert('Selecione um ambiente.'); return; }
      if(!id){ customAlert('ID do componente não encontrado.'); return; }
      var pwd = await await customPasswordPrompt('Informe a senha do usuário do ambiente para executar o rollback:');
          if(!pwd) return;
          // Start rollback via token
      const rs = await fetch('/api/rollback-start', {
        method:'POST',
        headers:{'Content-Type':'application/json', 'X-Edit-Id': String((typeof document!=='undefined' && document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : ((typeof window!=='undefined' && window.currentEditId) ? window.currentEditId : ''))},
        body: JSON.stringify({ envId: sel.value, objectId: id, password: pwd, ticket: (await customTicketPrompt('Informe o número do chamado (ticket):'))?.trim(), packageSource: (typeof __getMtarSource==='function' ? __getMtarSource() : 'normal') })
      });
      const js = await rs.json();
      if(!js.ok){ customAlert(js.error || 'Falha ao iniciar rollback'); return; }

      // Show Deploy (tempo real) and stream there
      var wrap = document.getElementById('deployWrap');
      var box = document.getElementById('deployBox');
      var status = document.getElementById('deployStatus');
      if (wrap) wrap.style.display = 'block';
      if (box) box.textContent = '';
      if(status) status.textContent='rollback'; try{ document.getElementById('deployProgress').style.display='block'; }catch(_){}

      const es = new EventSource('/api/rollback-stream?token=' + encodeURIComponent(js.token));
      es.onmessage = function(ev2){
        if (!box) return;
        box.textContent += (ev2.data||'') + '\\n';
        box.scrollTop = box.scrollHeight;
      };
      es.addEventListener('done', function(ev2){
        try{
          const payload = JSON.parse(ev2.data||'{}');
          if(status) status.textContent = payload.ok ? 'concluído' : 'erro'; try{ document.getElementById('deployProgress').style.display='none'; }catch(_){}
          if (box) box.textContent += '\\n--- rollback ' + (payload.ok?'concluído com sucesso.':'finalizado com erro.');
            customAlert(payload.ok ? 'Rollback concluído com sucesso.' : 'Rollback finalizado com erro. Verifique os logs.' ) + '\\n';
        }catch(_){}
        es.close();
        var btn = document.getElementById('btnOverview'); if(btn) btn.click();
      });
      es.onerror = function(){ if(status) status.textContent='erro'; try{ document.getElementById('deployProgress').style.display='none'; }catch(_){} es.close(); };
    }catch(e){
      customAlert(e.message||e);
    }
  }, true); // capture = true
});
document.addEventListener('DOMContentLoaded', function(){
  const btnOpen = document.getElementById('btnOpenCreateUser');
  const dlg = document.getElementById('dlgCreateUser');
  const btnCancel = document.getElementById('btnCreateUserCancel');
  const btnSave = document.getElementById('btnCreateUserSave');

  if(btnOpen && dlg){
    btnOpen.addEventListener('click', ()=>{
      if(typeof dlg.showModal==='function') dlg.showModal(); else dlg.style.display='block';
    });
  }
  if(btnCancel && dlg){
    btnCancel.addEventListener('click', ()=>{
      if(typeof dlg.close==='function') dlg.close(); else dlg.style.display='none';
    });
  }
  if(btnSave){
    btnSave.addEventListener('click', async ()=>{
      const username = document.getElementById('cuUsername').value.trim();
      const email = document.getElementById('cuEmail').value.trim();
      const password = document.getElementById('cuPassword').value;
      const role = document.getElementById('cuRole').value;
      if(!username || !email || !password){ customAlert('Preencha usuário, e-mail e senha.'); return; }
      const r = await fetch('/api/users', {
        method:'POST',
        headers:{'Content-Type':'application/json', 'X-Edit-Id': String((typeof document!=='undefined' && document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : ((typeof window!=='undefined' && window.currentEditId) ? window.currentEditId : ''))},
        body: JSON.stringify({ username,email,password,role })
      });
      const j = await r.json();
      if(j.ok){
        customAlert('Usuário criado!');
        if(typeof dlg.close==='function') dlg.close(); else dlg.style.display='none';
      }else{
        customAlert(j.error || 'Erro ao criar usuário');
      }
    });
  }
});
</script>
<!-- BEGIN Utilities (customAlert, toast, theme) -->
<div class="toast-container" id="toastContainer"></div>
<dialog id="customAlert" style="border:1px solid #9ca3af;border-radius:8px;padding:18px;max-width:520px;box-shadow:0 2px 10px rgba(0,0,0,.12)">
  <h3 style="margin:0 0 8px;font-size:16px">TAXONE FOR SAP Solutions diz:</h3>
  <div id="customAlertMsg" style="font-size:14px;line-height:1.4"></div>
  <div style="text-align:right;margin-top:14px">
    <button id="customAlertOk" class="btn">OK</button>
  </div>
</dialog>
<script>
(function(){
  
  /** 
   * Função ensureAlert
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem ensureAlert.
   * - Retorno: Valor compatível com o uso corrente.

   */
  function ensureAlert(){
    var dlg=document.getElementById('customAlert');
    if(!dlg){
      dlg=document.createElement('dialog'); dlg.id='customAlert';
      dlg.innerHTML='<h3>TAXONE FOR SAP Solutions diz:</h3><div id="customAlertMsg"></div><div style="text-align:right;margin-top:12px"><button id="customAlertOk" class="btn">OK</button></div>';
      document.body.appendChild(dlg);
    }
    var ok=document.getElementById('customAlertOk');
    if(ok){ ok.onclick=function(){ if(dlg.close) dlg.close(); else dlg.style.display='none'; }; }
    return dlg;
  }
  window.customAlert = function(msg){
    var dlg=ensureAlert();
    var box=document.getElementById('customAlertMsg'); if(box) box.textContent=(msg==null?'':String(msg));
    if(dlg.showModal) dlg.showModal(); else dlg.style.display='block';
  };
  window.toast = function(msg, type){
    var wrap=document.getElementById('toastContainer'); if(!wrap){ wrap=document.createElement('div'); wrap.id='toastContainer'; wrap.className='toast-container'; document.body.appendChild(wrap); }
    var t=document.createElement('div'); t.className='toast ' + (type||'info'); t.textContent=String(msg||''); wrap.appendChild(t);
    setTimeout(function(){ t.style.opacity='0'; setTimeout(function(){ t.remove(); }, 320); }, 3200);
  };
  
})();
</script>
<!-- END Utilities -->
<!-- BEGIN: Password Prompt -->
<dialog id="customPwdDialog" style="border:1px solid #9ca3af;border-radius:8px;padding:18px;max-width:520px;box-shadow:0 2px 10px rgba(0,0,0,.12)">
  <h3 style="margin:0 0 8px;font-size:16px">TAXONE FOR SAP Solutions diz:</h3>
  <div class="muted" id="customPwdMsg" style="margin-bottom:8px;font-size:14px;line-height:1.4"></div>
  <input id="customPwdInput" type="password" style="width:100%;-webkit-text-security:disc;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px">
  <div style="text-align:right;margin-top:12px;display:flex;gap:8px;justify-content:flex-end">
    <button id="customPwdCancel" class="btn">Cancelar</button>
    <button id="customPwdOk" class="btn">OK</button>
  </div>
</dialog>
<script>
(function(){
  window.customPasswordPrompt = function(message){
    return new Promise(function(resolve){
      var dlg = document.getElementById('customPwdDialog');
      if(!dlg){
        dlg = document.createElement('dialog');
        dlg.id = 'customPwdDialog';
        dlg.innerHTML = '<h3>TAXONE FOR SAP Solutions diz:</h3>' +
                        '<div id="customPwdMsg" class="muted" style="margin-bottom:8px"></div>' +
                        '<input id="customPwdInput" type="password" style="-webkit-text-security:disc;width:100%;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px">' +
                        '<div style="text-align:right;margin-top:12px"><button id="customPwdCancel" class="btn">Cancelar</button> <button id="customPwdOk" class="btn">OK</button></div>';
        document.body.appendChild(dlg);
      }
      var msg = document.getElementById('customPwdMsg');
      if(msg){ msg.textContent = message || 'Informe a senha:'; }
      var input = document.getElementById('customPwdInput');
      if(input){ input.value=''; input.setAttribute('type','password'); input.style.webkitTextSecurity='disc'; }
      /** 
       * Função onCancel
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onCancel.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onCancel(){ try{ dlg.close(); }catch(_){} cleanup(); resolve(null); }
      /** 
       * Função onOk
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onOk.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onOk(){ var v=input?input.value:''; try{ dlg.close(); }catch(_){} cleanup(); resolve(v); }
      /** 
       * Função onKey
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onKey.
       * - Retorno: Valor compatível com o uso corrente.
       * @param {{any}} e 
       */
      function onKey(e){ if(e.key==='Enter'){ e.preventDefault(); onOk(); } }
      /** 
       * Função cleanup
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem cleanup.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function cleanup(){
        try {
          document.getElementById('customPwdOk')?.removeEventListener('click', onOk);
          document.getElementById('customPwdCancel')?.removeEventListener('click', onCancel);
          input?.removeEventListener('keydown', onKey);
        } catch(_){}
      }
      document.getElementById('customPwdOk')?.addEventListener('click', onOk);
      document.getElementById('customPwdCancel')?.addEventListener('click', onCancel);
      input?.addEventListener('keydown', onKey);
      try{ input?.focus(); }catch(_){}
      if(dlg.showModal){ dlg.showModal(); } else { dlg.style.display='block'; }
    });
  };
})();
</script>
<!-- END: Password Prompt -->
<!-- BEGIN: Ticket Prompt -->
<dialog id="customTicketDialog" style="border:1px solid #9ca3af;border-radius:8px;padding:18px;max-width:520px;box-shadow:0 2px 10px rgba(0,0,0,.12)">
  <h3 style="margin:0 0 8px;font-size:16px">TAXONE FOR SAP Solutions diz:</h3>
  <div class="muted" id="customTicketMsg" style="margin-bottom:8px;font-size:14px;line-height:1.4"></div>
  <input id="customTicketInput" type="text" style="width:100%;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px" placeholder="Número do chamado (ticket)">
  <div style="text-align:right;margin-top:12px;display:flex;gap:8px;justify-content:flex-end">
    <button id="customTicketCancel" class="btn">Cancelar</button>
    <button id="customTicketOk" class="btn">OK</button>
  </div>
</dialog>
<script>
(function(){
  window.customTicketPrompt = function(message){
    return new Promise(function(resolve){
      var dlg = document.getElementById('customTicketDialog');
      if(!dlg){
        dlg = document.createElement('dialog');
        dlg.id = 'customTicketDialog';
        dlg.innerHTML = '<h3>TAXONE FOR SAP Solutions diz:</h3>' +
                        '<div id="customTicketMsg" class="muted" style="margin-bottom:8px"></div>' +
                        '<input id="customTicketInput" type="text" style="width:100%;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px" placeholder="Número do chamado (ticket)">' +
                        '<div style="text-align:right;margin-top:12px"><button id="customTicketCancel" class="btn">Cancelar</button> <button id="customTicketOk" class="btn">OK</button></div>';
        document.body.appendChild(dlg);
      }
      var msg = document.getElementById('customTicketMsg');
      if(msg){ msg.textContent = message || 'Informe o número do chamado (ticket):'; }
      var input = document.getElementById('customTicketInput');
      if(input){ input.value=''; }
      /** 
       * Função onCancel
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onCancel.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onCancel(){ try{ dlg.close(); }catch(_){} cleanup(); resolve(null); }
      /** 
       * Função onOk
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onOk.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onOk(){ var v=input?String(input.value||'').trim():''; try{ dlg.close(); }catch(_){} cleanup(); resolve(v); }
      /** 
       * Função onKey
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onKey.
       * - Retorno: Valor compatível com o uso corrente.
       * @param {{any}} e 
       */
      function onKey(e){ if(e.key==='Enter'){ e.preventDefault(); onOk(); } }
      /** 
       * Função cleanup
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem cleanup.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function cleanup(){
        try {
          document.getElementById('customTicketOk')?.removeEventListener('click', onOk);
          document.getElementById('customTicketCancel')?.removeEventListener('click', onCancel);
          input?.removeEventListener('keydown', onKey);
        } catch(_){}
      }
      document.getElementById('customTicketOk')?.addEventListener('click', onOk);
      document.getElementById('customTicketCancel')?.addEventListener('click', onCancel);
      input?.addEventListener('keydown', onKey);
      try{ input?.focus(); }catch(_){}
      if(dlg.showModal){ dlg.showModal(); } else { dlg.style.display='block'; }
    });
  };
})();
</script>
<!-- END: Ticket Prompt -->

<footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b></b>
<footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b></b>
</footer>
<footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b>Desenvolvido por AMS Sustentação - Alliance Consultoria V3.0</b>
</footer>
</body></html>`;
  }
}

/** 
 * Classe AuthController
 * - O que faz: Representa uma entidade/serviço com estado e comportamentos.
 * - Observação: Métodos internos seguem as regras originais do código.
 */
class AuthController {
  constructor(userSvc, resetSvc){ this.userSvc=userSvc; this.resetSvc=resetSvc; this.router=express.Router(); this.mount(); }
  mount(){
    this.router.get('/login', this.renderLogin.bind(this));
    this.router.post('/api/login', this.login.bind(this));
    this.router.post('/api/logout', this.logout.bind(this));
        this.router.post('/api/users', this.requireAdmin.bind(this), this.createUser.bind(this));
this.router.get('/api/me', this.me.bind(this));
    this.router.post('/api/forgot', this.forgot.bind(this));
    this.router.get('/reset/:token', this.renderReset.bind(this));
    this.router.post('/api/reset', this.resetPassword.bind(this));
this.router.get('/2fa', (req,res)=>{
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Verificação 2FA</title>
  <style>${baseCss}.login-wrap{display:flex;flex-direction:column;align-items:center;justify-content:center}
.login-wrap .after-card-note{margin-top:8px}
</style>

</head><body>
  <div class="page"><div class="card stack login-container">
    <h3 style="margin:0 0 8px">Verificação em duas etapas</h3>
    <div class="muted">Enviamos um código para o seu e-mail.</div>
    <input id="otp" placeholder="Código de 6 dígitos">
    <button class="btn" id="btnV">Verificar</button>
    <div id="msg" class="msg"></div>
  </div></div>
  <script>
  document.getElementById('btnV').onclick = async function(){
    var otp=document.getElementById('otp').value.trim();
    const r=await fetch('/api/2fa-verify',{method:'POST',headers:{'Content-Type':'application/json', 'X-Edit-Id': String((typeof document!=='undefined' && document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : ((typeof window!=='undefined' && window.currentEditId) ? window.currentEditId : ''))},body:JSON.stringify({otp})});
    const j=await r.json(); if(j.ok){ location.href='/'; } else { document.getElementById('msg').textContent=j.error||'Falha'; }
  };
  </script>
  <footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b></b>
<footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b></b>
</footer>
<footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b>Desenvolvido por AMS Sustentação - Alliance Consultoria V3.0</b>
</footer>
</body></html>`;
  res.type('html').send(html);
});
this.router.post('/api/2fa-verify', async (req,res)=>{
  try{
    const sess = req.session && req.session.twofa;
    if(!sess) return res.status(400).json({ok:false,error:'Sessão 2FA não iniciada'});
    const {otp} = req.body || {};
    if(!otp || String(otp) !== String(sess.otp)){
      return res.status(400).json({ok:false,error:'Código inválido'});
    }
    const user = await this.userSvc.db.get(`SELECT username, role FROM users WHERE id=?`, [sess.user_id]);
    req.session.user = { id: sess.user_id, username: user?.username || 'user', role: user?.role || 'user' };
    delete req.session.twofa;
    return res.json({ok:true});
  }catch(e){ res.status(500).json({ok:false,error:'Erro 2FA'}); }
});

  }
  renderLogin(req,res){ if(req.session?.user) return res.redirect('/'); res.type('html').send(LoginView.html()); }
  async login(req,res){
    try{
      const {username,password}=req.body||{};
      if(!username||!password) return res.status(400).json({ok:false,error:'Usuário e senha são obrigatórios'});
      const user=await this.userSvc.findByUsername(username);
      if(!user) return res.status(401).json({ok:false,error:'Credenciais inválidas'});
      try{
        const li = await getLockInfo(this.userSvc.db, user.id);
        if(li && li.locked_until && new Date(li.locked_until.replace(' ', 'T')) > new Date()){
          return res.status(423).json({ok:false,error:'Conta temporariamente bloqueada por tentativas inválidas. Tente mais tarde.'});
        }
      }catch(_){}

      const ok=await this.userSvc.verifyPassword(user,password);
      if(!ok){ try{ await bumpFailure(this.userSvc.db, user.id); }catch(_){}
        return res.status(401).json({ok:false,error:'Credenciais inválidas'});
      }
      try{ await clearFailures(this.userSvc.db, user.id); }catch(_){}
      if(user.twofa_email_enabled){
        const otp=(''+Math.floor(100000+Math.random()*900000));
        req.session.twofa={user_id:user.id, otp, created: Date.now()};
        try{ await sendResetEmail(user.email, 'Código de verificação: '+otp); }catch(_){}
        return res.json({ok:true, twofa_required:true, method:'email'});
      }
      req.session.user={id:user.id,username:user.username,role:user.role};
      res.json({ok:true,user:{username:user.username,role:user.role,email:user.email}});

    }catch(e){ console.error(e); res.status(500).json({ok:false,error:'Erro ao autenticar'}); }
  }
  logout(req,res){ if(!req.session) return res.json({ok:true}); req.session.destroy(()=>{ res.clearCookie('sid'); res.json({ok:true}); }); }
  me(req,res){ if(!req.session?.user) return res.status(401).json({error:'Unauthorized'}); res.json({user:req.session.user}); }
  async forgot(req,res){
    try{
      const {email}=req.body||{}; if(!email) return res.status(400).json({ok:false,error:'Informe o e-mail'});
      const user=await this.userSvc.findByEmail(email);
      if(user){
        const t = await this.resetSvc.createTokenForUser(user.id,30);
        const url = `${req.protocol}://${req.get('host')}/reset/${t}`;
        console.log('> [RESET LINK]', url);
        try{
          const sendResult = await sendResetEmail(user.email, url);
          if(!sendResult.ok){
            console.error('Falha ao enviar e-mail de reset:', sendResult.error || sendResult.info);
          }
        }catch(e){ console.error('Erro no envio do e-mail de reset:', (e && e.message) || e); }
      }
      res.json({ok:true,message:'Se o e-mail existir, você receberá instruções.'});
    }catch(e){ console.error(e); res.status(500).json({ok:false,error:'Erro ao solicitar redefinição'}); }
  }
  async renderReset(req,res){
    const rec=await this.resetSvc.getValidToken(req.params.token);
    if(!rec) return res.status(400).send('<h3>Token inválido ou expirado.</h3>');
    res.type('html').send(ResetView.html(req.params.token, rec.email));
  }
  async resetPassword(req,res){
    try{
      const {token,password}=req.body||{}; if(!token||!password) return res.status(400).json({ok:false,error:'Dados insuficientes'});
      // if(!isStrongPassword(password)) return res.status(400).json({ok:false,error:'Senha fraca: mínimo 10 caracteres, com maiúscula, minúscula, número e símbolo.'});
      const rec=await this.resetSvc.getValidToken(token); if(!rec) return res.status(400).json({ok:false,error:'Token inválido ou expirado'});
      await this.userSvc.setPassword(rec.user_id,password); await this.resetSvc.markUsed(token);
      res.json({ok:true,message:'Senha redefinida com sucesso'});
    }catch(e){ console.error(e); res.status(500).json({ok:false,error:'Erro ao redefinir senha'}); }
  }

  requireAdmin(req,res,next){
    try{
      if(!req.session?.user) return res.status(401).json({ok:false,error:'Unauthorized'});
      if(req.session.user.role!=='admin') return res.status(403).json({ok:false,error:'Forbidden'});
      next();
    }catch(e){ res.status(500).json({ok:false,error:'Auth error'}); }
  }

  async createUser(req,res){
    try{
      const { username, email, password, role } = req.body || {};
      if(!username || !email || !password){
        return res.status(400).json({ok:false,error:'Dados insuficientes'});
      }
      // if(!isStrongPassword(password)){
      //   return res.status(400).json({ok:false,error:'Senha fraca: mínimo 10 caracteres, com maiúscula, minúscula, número e símbolo.'});
      // }
      const exists = await this.userSvc.findByUsername(username) || await this.userSvc.findByEmail(email);
      if(exists) return res.status(409).json({ok:false,error:'Usuário/E-mail já existe'});
      const h = await bcrypt.hash(password,10);
      await this.userSvc.db.run(
        `INSERT INTO users (username,email,password_hash,role) VALUES (?,?,?,?)`,
        [username, email, h, role || 'user']
      );
      res.json({ok:true,message:'Usuário criado com sucesso'});
    }catch(e){ console.error(e); res.status(500).json({ok:false,error:'Erro ao criar usuário'}); }
  }

}

/** 
 * Função extractClientVersionFromLines
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem extractClientVersionFromLines.
 * - Retorno: Valor compatível com o uso corrente.
 * @param {{any}} lines 
 * @param {{any}} objectId 
 */
function extractClientVersionFromLines(lines, objectId){
  const joined = (lines || []).join('\n');
  const idEsc = objectId.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const versionPat = '(\\d+(?:\\.\\d+){1,3})';

  let re1 = new RegExp(idEsc + '[^\\n\\r]{0,60}?\\b' + versionPat + '\\b', 'i');
  let m = re1.exec(joined);
  if (m && m[1]) return m[1];

  let re2 = new RegExp(idEsc + '[\\s\\S]{0,120}?Version\\s*[:=]\\s*' + versionPat, 'i');
  m = re2.exec(joined);
  if (m && m[1]) return m[1];

  for (const l of (lines || [])){
    if (l.toLowerCase().includes(objectId.toLowerCase())){
      const tokens = l.trim().split(/\s+/);
      const maybe = tokens[tokens.length - 1];
      if (/^\d+(?:\.\d+){1,3}$/.test(maybe)) return maybe;
    }
  }
  return null;
}

/** 
 * Classe EnvironmentsService
 * - O que faz: Representa uma entidade/serviço com estado e comportamentos.
 * - Observação: Métodos internos seguem as regras originais do código.
 */
class EnvironmentsService {
  constructor(db) { this.db = db; }
  
async findDuplicateId(env) {
    const row = await this.db.get(
      `SELECT id FROM environments
         WHERE name = ?
           AND origem = ?
           AND ifnull(org_url, '') = ifnull(?, '')
           AND ifnull(org, '')     = ifnull(?, '')
           AND ifnull(space, '')   = ifnull(?, '')
           AND ifnull(username,'') = ifnull(?, '')`,
      [env.name, env.origem, env.org_url || null, env.org || null, env.space || null, env.username || null]
    );
    return row?.id || null;
  }
  async createOrUpdate(env) {
    const now = nowSqlite();
    const dupId = await this.findDuplicateId(env);
    if (!env.id && dupId) return { duplicate: true, id: dupId };
    if (env.id && dupId && Number(dupId) !== Number(env.id)) return { duplicate: true, id: dupId };
    if (!env.id) {
      const r = await this.db.run(
        `INSERT INTO environments (name, origem, org_url, org, space, username, env_type, stage, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)`,
        [env.name, env.origem, env.org_url || null, env.org || null, env.space || null,
         env.username || null, (env.env_type || 'CF'), (env.stage || 'HML'), now, now]
      );
      return { id: r.lastID };
    }
    await this.db.run(
      `UPDATE environments
          SET name=?, origem=?, org_url=?, org=?, space=?, username=?, env_type=?, stage=?, updated_at=? WHERE id=?`,
      [env.name, env.origem, env.org_url || null, env.org || null, env.space || null,
       env.username || null, (env.env_type || 'CF'), (env.stage || 'HML'), now, env.id]
    );
    return { id: env.id };
  }
  listAll() {
    return this.db.all(
      `SELECT id, name, origem, org_url, org, space, username, env_type, created_at, updated_at, stage
         FROM environments
        ORDER BY name`
    );
  }
  async getById(id){
    return this.db.get(
      `SELECT id, name, origem, org_url, org, space, username, env_type, stage
         FROM environments WHERE id=?`, [id]
    );
  }
  delete(id) { return this.db.run(`DELETE FROM environments WHERE id = ?`, [id]); }
}

// =============== Views (HTML) simples para Home e Ambientes ===============
/** 
 * Classe HomeView
 * - O que faz: Representa uma entidade/serviço com estado e comportamentos.
 * - Observação: Métodos internos seguem as regras originais do código.
 */
class HomeView {
  static _envOptionsHtml(envItems){
    try{
      const items = Array.isArray(envItems) ? envItems : [];
      // placeholder
      let out = '<option value="" selected>Selecione uma empresa/ambiente...</option>';
      for (let i=0;i<items.length;i++){
        const e = items[i] || {};
        const id = (e.id!=null ? e.id : (e._id!=null ? e._id : (e.value!=null ? e.value : '')));
        const company = (e.name || e.nome || e.company || e.empresa || '').toString();
        const space = (e.space || e.espaco || e.ambiente || e.env || e.spaceName || '').toString();
        const envType = (e.env_type || e.type || '').toString().toUpperCase();
        let label = '';
        if (envType === 'XS'){
          if (company && space) label = company + ' - ' + space;
          else label = company || space || String(id || '');
        } else {
          label = company || space || String(id || '');
        }
        // Basic HTML escaping
        const esc = (s)=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/\'/g,'&#39;');
        out += '<option value="' + esc(id) + '">' + esc(label) + '</option>';
      }
      return out;
    }catch(_){
      return '<option value="" selected>Selecione uma empresa/ambiente...</option>';
    }
  }

  static html(envItems){
    const __envOpts = HomeView._envOptionsHtml(envItems);
    return `<!DOCTYPE html><html lang="pt-br"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ALLIANCE - Atualizador de Componentes</title>
<style>${baseCss}
/***** Title split and centered *****/
.title-block{display:inline-block; line-height:1.05; margin-left:8px; text-align:center;}
.title-top{font-size:16px; font-weight:700; color:#0f172a; display:block;}
.title-bottom{font-size:16px; font-weight:700; color:#0f172a; display:block;}
/***** Keep header actions on one line *****/
.header{display:flex;align-items:center;gap:16px;justify-content:flex-start;align-content:center;background:#ffffff;padding:10px 14px;border-radius:12px;}
.header .right{display:flex;align-items:center;gap:10px;flex-wrap:nowrap;}
.header .right label{display:inline-block;margin:0;}
.header .right .btn{white-space:nowrap;}
/* keep select from pushing items to a new line */
.header .right select{max-width:300px}
@media (max-width: 1024px){
  .header .right{flex-wrap:wrap;} /* allow wrap on smaller screens */
}

.grid{display:grid;grid-template-columns: minmax(800px,80%) minmax(640px,65%);gap:16px;align-items:startmargin:0 auto;}
@media(max-width:980px){.grid{grid-template-columns:1fr}}
#deployWrap{display:none}

.footer{margin-top:16px;color:#666;font-size:12px;text-align:center;padding-top:8px;border-top:1px solid #eee}
.actions{display:flex;gap:8px;align-items:center}
#overviewTable td.actions-cell{white-space:nowrap}

#btnUpdate,
#btnOverview {
  background-color: #fef3c7 !important;
  border-color: #fcd34d !important;
  color: #000 !important;
}
#btnUpdate:hover,
#btnOverview:hover {
  background-color: #fef3c7 !important;
}
/* === fim estilo amarelo claro === */

/* === Estilo amarelo claro (FAFAF2) === */
#btnUpdate,
#btnOverview {
  background-color: #FAFAF2 !important;
  border-color: #e6e6d9 !important;
  color: #000 !important;
}
#btnUpdate:hover,
#btnOverview:hover {
  background-color: #f0f0e6 !important;
}
/* === fim estilo === */
.login-wrap{display:flex;flex-direction:column;align-items:center;justify-content:center}
.login-wrap .after-card-note{margin-top:8px}
</style>

</head><body>
<div class="container">
  <div class="header">
    <img src="/static/logo_translucent.png" alt="Alliance Consultoria">
    <div class="title-block">
      <span class="title-top">TAXONE FOR SAP Solutions - Atualizador de Componentes</span>
    </div>
    <div class="right">
      <a class="btn" href="/environments" title="Cadastro de Ambientes">Cadastro de Ambientes</a>
      <label class="muted" for="envSelectHeader"></label>
      <select id="envSelectHeader" title="Selecione a empresa/ambiente" style="min-width:240px;max-width:360px">${__envOpts}</select>
      <button id="btnReport" class="btn btn-primary" title="Gerar relatório" onclick="if(window.__openReport){window.__openReport();}">Relatório</button>

<script>
document.addEventListener('DOMContentLoaded', function(){
  try{
    var btn = document.getElementById('btnReport');
    if (btn && !btn.__wiredReport){
      btn.__wiredReport = true;
      btn.addEventListener('click', function(e){
        try{ e.preventDefault(); }catch(_){}
        try{ e.stopPropagation(); e.stopImmediatePropagation(); }catch(_){ } try{
          if (typeof openReportDialog === 'function'){ openReportDialog(); return; }
          if (window.__openReport){ window.__openReport(); return; }
          console.warn('openReportDialog/__openReport não encontrados.');
        }catch(err){ console.error('Erro ao abrir relatório:', err); }
      });
    }
  }catch(err){ console.error(err); }
});
</script>

<!-- Report Dialog (singleton, header-bound) -->
<dialog id="dlgReport" style="padding:20px;border:none;border-radius:12px;max-width:520px;width:520px">
  <h3 style="margin-top:0">Gerar Relatório (PDF)</h3>
  <div style="display:grid;gap:8px">
    <label>Empresa / Ambiente</label>
    <select id="rep_env_select" title="Selecione a empresa/ambiente"></select>
    <!-- hidden fields used for querystring -->
    <input id="rep_company" type="hidden">
    <input id="rep_space" type="hidden">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
      <div>
        <label>Início</label>
        <input id="rep_start" type="date">
      </div>
      <div>
        <label>Fim</label>
        <input id="rep_end" type="date">
      </div>
    </div>
  </div>
  <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px">
    <button id="btnRepCancel" type="button" class="btn muted">Cancelar</button>
    <button id="btnRepGenerate" class="btn">Gerar PDF</button>
  </div>
</dialog>
<script>
(function(){
  /** 
   * Função fetchJSON
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem fetchJSON.
   * - Retorno: Valor compatível com o uso corrente.
   * @param {{any}} url 
   * @param {{any}} cb 
   */
  function fetchJSON(url, cb){
    try{
      var xhr = new XMLHttpRequest();
      xhr.open('GET', url, true);
      xhr.onreadystatechange = function(){
        if (xhr.readyState === 4){
          try{
            if (xhr.status >= 200 && xhr.status < 300){
              cb(null, JSON.parse(xhr.responseText));
            } else {
              cb(new Error('HTTP '+xhr.status));
            }
          }catch(e){ cb(e); }
        }
      };
      xhr.send(null);
    }catch(e){ cb(e); }
  }

  /** 
   * Função loadEnvById
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem loadEnvById.
   * - Retorno: Valor compatível com o uso corrente.
   * @param {{any}} id 
   * @param {{any}} cb 
   */
  function loadEnvById(id, cb){
    if(!id){ cb(null, null); return; }
    try{
      if (window.__envCache && window.__envCache[id]){ cb(null, window.__envCache[id]); return; }
      fetchJSON('/api/environments', function(err, d){
        if (err){ cb(null, null); return; }
        var items = (d && d.items) || d || [];
        window.__envCache = window.__envCache || {};
        for (var i=0;i<items.length;i++){
          var e = items[i];
          var key = String(e.id || e._id || e.value || e.env_id || '');
          if (key) window.__envCache[key] = e;
        }
        cb(null, window.__envCache[id] || null);
      });
    }catch(_){ cb(null, null); }
  }

  /** 
   * Função getSelectedEnv
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem getSelectedEnv.
   * - Retorno: Valor compatível com o uso corrente.
   * @param {{any}} cb 
   */
  function getSelectedEnv(cb){
    try{
      var sel = document.getElementById('envSelectHeader') || document.getElementById('environmentSelect');
      if(!sel || sel.selectedIndex < 0){ cb(null, null); return; }
      var opt = sel.options[sel.selectedIndex];
      if(opt && opt.dataset && opt.dataset.raw){
        try { cb(null, JSON.parse(opt.dataset.raw)); return; } catch(_){}
      }
      loadEnvById(sel.value, function(){ 
        var env = (window.__envCache && window.__envCache[sel.value]) || null;
        if (env){ cb(null, env); return; }
        var txt = (opt && (opt.textContent || opt.innerText) || '').trim();
        var parts = txt.split(' - ');
        var company = (parts[0] || '').trim();
        var space = (parts[1] || '').trim();
        cb(null, { name: company, company_name: company, space: space });
      });
    }catch(_){ cb(null, null); }
  }

  /** 
   * Função cloneHeaderOptionsIntoDialog
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem cloneHeaderOptionsIntoDialog.
   * - Retorno: Valor compatível com o uso corrente.

   */
  function cloneHeaderOptionsIntoDialog(){
    try{
      var header = document.getElementById('envSelectHeader') || document.getElementById('environmentSelect');
      var dlgSel = document.getElementById('rep_env_select');
      if(!dlgSel) return;
      dlgSel.innerHTML = '';
      var opt0 = document.createElement('option');
      opt0.value=''; opt0.textContent='Selecione uma empresa/ambiente...';
      dlgSel.appendChild(opt0);
      if(!header) return;
      Array.prototype.forEach.call(header.options, function(o, idx){
        var n = document.createElement('option');
        n.value = o.value;
        n.textContent = o.textContent || o.innerText || '';
        if (o.dataset && o.dataset.raw) n.dataset.raw = o.dataset.raw;
        dlgSel.appendChild(n);
      });
      dlgSel.value = header.value || '';
    }catch(_){}
  }

  /** 
   * Função updateHiddenFromDialog
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem updateHiddenFromDialog.
   * - Retorno: Valor compatível com o uso corrente.

   */
  function updateHiddenFromDialog(){
    var dlgSel = document.getElementById('rep_env_select');
    if(!dlgSel) return;
    var opt = dlgSel.options[dlgSel.selectedIndex];
    var company = '', space = '';
    try{
      if(opt && opt.dataset && opt.dataset.raw){
        var raw = JSON.parse(opt.dataset.raw);
        company = raw.name || raw.company_name || raw.company || raw.empresa || '';
        space   = raw.space || raw.espaco || raw.ambiente || raw.env || '';
      }else{
        var txt = (opt && (opt.textContent || opt.innerText) || '').trim();
        var parts = txt.split(' - ');
        company = (parts[0]||'').trim();
        space = (parts[1]||'').trim();
      }
    }catch(_){}
    var cEl = document.getElementById('rep_company');
    var sEl = document.getElementById('rep_space');
    if(cEl) cEl.value = company;
    if(sEl) sEl.value = space;
  }

  /** 
   * Função openReportDialog
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem openReportDialog.
   * - Retorno: Valor compatível com o uso corrente.

   */
  function openReportDialog(){
    try{ window.__reportOpen = true; try{ if(window.__enterReportMode) window.__enterReportMode(); }catch(_){}  }catch(_){ } var dlg = document.getElementById('dlgReport'); if(!dlg) return;
    cloneHeaderOptionsIntoDialog();
    getSelectedEnv(function(_e, env){
      try{
        env = env || {};
        var company = env.name || env.company_name || env.company || env.empresa || '';
        var space   = env.space || env.espaco || env.ambiente || env.env || '';
        var dlgSel = document.getElementById('rep_env_select');
        if (dlgSel && !dlgSel.value){
          // tenta selecionar por label
          var want = (company && space) ? (company + ' - ' + space) : (company || '');
          for (var i=0;i<dlgSel.options.length;i++){
            if ((dlgSel.options[i].textContent||'').trim() === want){ dlgSel.selectedIndex = i; break; }
          }
        }
        updateHiddenFromDialog();
      }catch(_){}
      // período padrão: mês atual
      var today = new Date();
      var yyyy = today.getFullYear();
      var mm = String(today.getMonth()+1).padStart(2,'0');
      var dd = String(today.getDate()).padStart(2,'0');
      try{
        var rs = document.getElementById('rep_start');
        var re = document.getElementById('rep_end');
        if(rs && !rs.value) rs.value = yyyy + '-' + mm + '-01';
        if(re && !re.value) re.value = yyyy + '-' + mm + '-' + dd;
      }catch(_){}
      if(dlg.showModal) dlg.showModal(); else dlg.setAttribute('open','open');
    });
  }

  /** 
   * Função closeReportDialog
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem closeReportDialog.
   * - Retorno: Valor compatível com o uso corrente.

   */
  function closeReportDialog(){
    try{ window.__reportOpen = false; try{ if(window.__exitReportMode) window.__exitReportMode(); }catch(_){}  }catch(_){ } var dlg = document.getElementById('dlgReport'); if(!dlg) return;
    try{ dlg.close(); }catch(_){ dlg.removeAttribute('open'); }
  }

  /** 
   * Função genPdf
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem genPdf.
   * - Retorno: Valor compatível com o uso corrente.

   */
  function genPdf(){
    var dlgSel = document.getElementById('rep_env_select');
    if(!dlgSel || !dlgSel.value){ alert('Selecione uma empresa/ambiente.'); return; }
    updateHiddenFromDialog();
    var company = (document.getElementById('rep_company')?.value || '').trim();
    var space   = (document.getElementById('rep_space')?.value || '').trim();
    var start   = (document.getElementById('rep_start')?.value || '').trim();
    var end     = (document.getElementById('rep_end')?.value || '').trim();
    if(!start || !end){ alert('Informe o período (início e fim).'); return; }
    var qs = new URLSearchParams({ company_name: company, space: space, start: start, end: end });
    try{ window.open('/api/report.pdf?' + qs.toString(), '_blank'); }catch(_){ location.href = '/api/report.pdf?' + qs.toString(); }
    closeReportDialog();
  }

  // Listeners
  document.addEventListener('change', function(ev){
  if (window.__REPORT_MODE && !(ev.target && (ev.target.closest('#dlgReport') || ev.target.closest('#btnReport')))) { return; }

    var t = ev.target;
    if (t && t.id === 'rep_env_select'){
      /* [Independente] não sincroniza header durante relatório */ try{ updateHiddenFromDialog(); }catch(_){ }
      updateHiddenFromDialog();
    }
  });

  document.addEventListener('click', function(ev){
  if (window.__REPORT_MODE && !(ev.target && (ev.target.closest('#dlgReport') || ev.target.closest('#btnReport')))) { return; }

    var t = ev.target;
    if (t && (t.id === 'btnReport' || t.getAttribute('data-action') === 'open-report')){ try{ev.preventDefault();}catch(_){ } openReportDialog(); }
    if (t && t.id === 'btnRepCancel'){ try{ev.preventDefault();}catch(_){ } closeReportDialog(); }
    if (t && t.id === 'btnRepGenerate'){ try{ev.preventDefault();}catch(_){ } genPdf(); }
  });

  if (typeof window !== 'undefined') window.__openReport = openReportDialog;
})();
</script>
<!-- END Report Dialog (singleton) -->

<button id="btnOpenCreateUser" class="btn" title="Criar Usuário">Criar Usuário</button>
      <button id="btnLogout" class="btn" title="Sair">Sair</button>
    </div>
  </div>

  <dialog id="dlgCreateUser" style="padding:20px;border:none;border-radius:12px;max-width:420px">
  <h3 style="margin-top:0">Criar Usuário</h3>
  <div style="display:grid;gap:8px">
    <input id="cuUsername" placeholder="Usuário">
    <input id="cuEmail" type="email" placeholder="E-mail">
    <input id="cuPassword" type="password" placeholder="Senha">
    <select id="cuRole">
      <option value="user">Usuário</option>
      <option value="admin">Admin</option>
    </select>
  </div>
  <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px">
    <button id="btnCreateUserCancel" type="button" class="btn muted">Cancelar</button>
    <button id="btnCreateUserSave" class="btn">Salvar</button>
  </div>
</dialog>
<div class="grid">
    <div id="leftPane">
      <div class="card" style="margin-bottom:12px">
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
          <button id="btnUpdate" class="btn" data-default-label="Atualizar do repositório">Atualizar do repositório</button>
          <span id="repoUpdateIndicator" class="badge" style="display:none">atualizando...</span>
          <small id="msg" class="muted"></small>
        </div>

        <div id="output" style="margin-top:10px">
          <div class="chips" id="versions"></div>
          <div id="envStatus" style="margin-top:12px;"></div>

          <div style="margin-top:10px">
            <button id="btnOverview" class="btn" title="Status de todos os objetos">Carregar status do ambiente</button>
          </div>

          <div style="margin:8px 0; display:flex; gap:8px; align-items:center">
  <label class="muted">Filtro:</label>
  <select id="ovFilter" class="btn">
    <option value="all">Todos</option>
    <option value="up">Atualizado</option>
    <option value="down">Desatualizado</option>
    <option value="cross">Componentes Cross</option>
    <option value="db">Componentes DB</option>
    <option value="js">Componentes JS</option>
    <option value="odata">Componentes ODATA</option>
    <option value="ui">Componentes UI</option>
    <option value="backend">Componentes BACKEND</option>
  </select>
  <label class="muted" style="margin-left:12px">Fonte MTAR:</label>
  <select id="mtarSourceSelect" class="btn" title="Escolha de onde buscar o MTAR (normal ou unshipped)">
    <option value="normal">Normal</option>
    <option value="unshipped">Unshipped</option>
  </select>
</div>
          <div id="overviewWrap" style="display:none;margin-top:8px">
            <table id="overviewTable" class="table">
              <thead>
                <tr>
                  <th>Objeto</th>
                  <th>Versão (ambiente)</th>
                  <th>Versão (repositório)</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody></tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

    <div id="rightPane" class="sticky">
      <div class="card">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
          <strong>Deploy (tempo real)</strong>
          <span id="deployStatus" class="badge">parado</span>
        </div>
        <div class="progress" id="deployProgress" style="display:none"><div class="bar"></div></div>
          <div id="deployWrap">
          <div id="deployBox" class="pre"></div>
        </div>
      </div>
    </div>
  </div>

<!-- TEXTO ADICIONADO FORA DO CARD -->
<div class="after-card-note" style="margin-top:6px; text-align:center; font-size:12px; color:#777; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  
</div>
<!-- fim texto adicionado -->
</div>

<script>var $=function(s){return document.querySelector(s)};
/* aliases for backward-compat */
if (typeof window !== 'undefined'){
  if (typeof window.loadEnvs === 'undefined' && typeof refreshEnvList === 'function'){
    window.loadEnvs = function(){ return refreshEnvList(); };
  }
  if (typeof window.loadApps === 'undefined' && typeof refreshAppsList === 'function'){
    window.loadApps = function(){ return refreshAppsList(); };
  }
}

var $$=function(s){return Array.prototype.slice.call(document.querySelectorAll(s))};
var $id=function(i){return document.getElementById(i)};
/** 
 * Função on
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem on.
 * - Retorno: Valor compatível com o uso corrente.
 * @param {{any}} id 
 * @param {{any}} ev 
 * @param {{any}} fn 
 */
function on(id, ev, fn){ var el=$id(id); if(el){ el.addEventListener(ev, fn); } }
var $=function(s){return document.querySelector(s);};

// === Dinamismo de cabeçalhos do Overview conforme Stage (HML/PRD) ===
/** 
 * Função __getSelectedEnvStage
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem __getSelectedEnvStage.
 * - Retorno: Valor compatível com o uso corrente.

 */
function __getSelectedEnvStage(){
  try{
    var sel = document.getElementById('envSelectHeader');
    if(!sel) return null;
    var opt = sel.options && sel.options[sel.selectedIndex];
    if(!opt) return null;
    var raw = opt.dataset && opt.dataset.raw ? opt.dataset.raw : null;
    if(!raw) return null;
    var obj; try{ obj = JSON.parse(raw); }catch(_){ obj = null; }
    var st = obj && obj.stage ? String(obj.stage).toUpperCase() : null;
    return st;
  }catch(_e){ return null; }

function __isProdStage(stage){
  try{
    if(stage == null || stage === undefined) return false;
    var s = String(stage)
      .toUpperCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g,''); // remove acentos

    // Considera Produção para vários padrões comuns
    return (s === 'PRD' || s === 'PROD' || s === 'PRODUCAO' || s === 'PRODUCTION');
  }catch(_){
    return false;
  }
}

}

/** 
 * Função __updateOverviewHeadersForStage
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem __updateOverviewHeadersForStage.
 * - Retorno: Valor compatível com o uso corrente.
 * @param {{any}} stage 
 */
function __updateOverviewHeadersForStage(stage){
  try{
    var thead = document.querySelector('#overviewTable thead');
    if(!thead) return;
    var ths = thead.querySelectorAll('th');
    if(!ths || ths.length < 4) return;
    if (String(stage).toUpperCase() === 'PRD'){
      ths[1].textContent = 'Versão QAS';
      ths[2].textContent = 'Versão PRD';
    } else {
      ths[1].textContent = 'Versão (ambiente)';
      ths[2].textContent = 'Versão (repositório)';
    }
  }catch(_){}
}
// === fim dinamismo de cabeçalhos ===

async function refreshEnvList(){
  // Carrega empresas/ambientes e popula o select com "empresa - SPACE"
  const sel = document.getElementById('envSelectHeader');
  if (!sel) return;
  sel.innerHTML = '';

  const ph = document.createElement('option');
  ph.value = '';
  ph.textContent = 'Selecione uma empresa/ambiente...';
  ph.selected = true;
  sel.appendChild(ph);

  let data;
  try{
    const r = await fetch('/api/environments');
    if(r.status === 401){ location.href = '/login'; return; }
    data = await r.json();
  }catch(e){
    console.error('Falha ao buscar /api/environments', e);
    return;
  }

  const items = Array.isArray(data) ? data : (data.items || []);

  /** 
   * Função labelFromEnv
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem labelFromEnv.
   * - Retorno: Valor compatível com o uso corrente.
   * @param {{any}} e 
   */
  function labelFromEnv(e){
  // Mostrar "EMPRESA - SPACE" apenas se tipo de ambiente for XS;
  // Para CF, mostrar somente EMPRESA (pedido do Leonardo).
  const company = e.name || e.nome || e.company || e.empresa || '';
  const space   = e.space || e.espaco || e.ambiente || e.env || e.spaceName || '';
  const envType = (e.env_type || e.type || '').toString().toUpperCase();
  if (envType === 'XS') {
    if (company && space) return String(company) + ' - ' + String(space);
    if (company) return String(company);
    if (space) return String(space);
    return String(e.id || '');
  } else {
    // CF (ou desconhecido): só EMPRESA
    if (company) return String(company);
    // fallback mínimo
    if (space) return String(space);
    return String(e.id || '');
  }
}

  for (const e of items){
    const opt = document.createElement('option');
    opt.value = String(e.id ?? e.envId ?? e.value ?? labelFromEnv(e));
    opt.textContent = labelFromEnv(e);
    // guarda campos úteis para debug/uso posterior
    try{ opt.dataset.raw = JSON.stringify(e); }catch(_){}
    sel.appendChild(opt);
  }
}

async function refreshAppsList(){
try{
    var r = await fetch('/api/apps');
    if(r.status===401){ location.href='/login'; return; 
}
    var d = await r.json();
    var sel = $('#objSelect');
    sel.innerHTML='';
    // placeholder removido por solicitação do usuário
(Array.isArray(d?.items)?d.items:[]).forEach(function(it){
      var o = document.createElement('option');
      o.value = it.id;
      o.textContent = it.label || it.id;
      sel.appendChild(o);
    });
  }catch(e){
    console.error(e);
  }
}

async function showVersions(){
  var id = (function(){var _el=$('#objSelect'); return _el ? _el.value : '';})();
  var box = $('#versions');
  var envBox = $('#envStatus');
  if(!_el || !id){
    if(box) box.innerHTML='';
    if(envBox) envBox.innerHTML='';
    return;
  }
  try{
    var r = await fetch('/api/versions/' + encodeURIComponent(id));
    if(r.status===401){ location.href='/login'; return; }
    var d = await r.json();
    box.innerHTML='';
    (d.versions||[]).forEach(function(v){
      var s = document.createElement('span');
      s.className='chip';
      s.textContent= v;
      box.appendChild(s);
    });
    if((d.versions||[]).length===0){
      box.innerHTML='<small>Nenhuma versão encontrada.</small>';
    }
  }catch(e){
    box.innerHTML = '<div class="pre">Erro: ' + (e.message||e) + '</div>';
  }

  var envId = $('#envSelectHeader').value;
  if(!envId){
    envBox.innerHTML='<small class="muted">Selecione uma Empresa/Ambiente no topo para verificar a versão no ambiente.</small>';
    return;
  }
  var pass = await customPasswordPrompt('Digite a senha do usuário do ambiente selecionado:');
  if(pass===null || pass===''){
    envBox.innerHTML='<small class="muted">Consulta ao ambiente cancelada.</small>';
    return;
  }
  envBox.innerHTML = '<div class="pre">Consultando versão instalada no ambiente...</div>';
  try{
    var rr = await fetch('/api/object-env-status', {
      method:'POST',
      headers:{'Content-Type':'application/json', 'X-Edit-Id': String((typeof document!=='undefined' && document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : ((typeof window!=='undefined' && window.currentEditId) ? window.currentEditId : ''))},
      body: JSON.stringify({ envId: envId, objectId: id, password: pass })
    });
    var jj = await rr.json();
    if(!jj.ok){
      envBox.innerHTML = '<div class="pre">Erro: ' + (jj.error || 'Falha na consulta') + '</div>';
      return;
    }
    envBox.innerHTML='';
    var label = document.createElement('div');
    label.innerHTML = '<strong>Versão no ambiente:</strong> ';
    var val = document.createElement('span');
    val.className = 'value';
    val.textContent = jj.clientVersion || 'Não encontrado no ambiente';
    label.appendChild(val);
    envBox.appendChild(label);
  }catch(e){
    envBox.innerHTML = '<div class="pre">Erro: ' + (e.message||e) + '</div>';
  }
}

// Listeners
window.__repoUpdateBusy = false;
function setRepoUpdateLoading(isLoading, text){
  var btn = document.getElementById('btnUpdate');
  var msg = document.getElementById('msg');
  var indicator = document.getElementById('repoUpdateIndicator');
  if(!btn) return;
  var defaultLabel = btn.getAttribute('data-default-label') || 'Atualizar do repositório';
  btn.disabled = !!isLoading;
  btn.style.opacity = isLoading ? '0.75' : '';
  btn.style.cursor = isLoading ? 'wait' : '';
  btn.textContent = isLoading ? 'Atualizando...' : defaultLabel;
  btn.setAttribute('aria-busy', isLoading ? 'true' : 'false');
  if(indicator) indicator.style.display = isLoading ? 'inline-flex' : 'none';
  if(msg && text !== undefined) msg.textContent = text || '';
}
on('btnUpdate', 'click', async function(){
  if (window.__repoUpdateBusy) return;
  window.__repoUpdateBusy = true;
  setRepoUpdateLoading(true, 'Sincronizando componentes do repositório...');
  try{
    var r = await fetch('/api/update-apps?ticket=manual');
    if(r.status===401){ location.href='/login'; return; }
    var d;
      try{
        d = await r.json();
      }catch(e){
        try{
          const t = await r.text();
          d = { ok:false, error: t };
        }catch(e2){
          d = { ok:false, error: e.message||String(e) };
        }
      }
    if(d.ok){
      setRepoUpdateLoading(true, 'Recarregando a lista local...');
      await refreshAppsList();
      var __el=document.getElementById('objSelect'); if(__el && __el.value) showVersions();
      setRepoUpdateLoading(false, 'Atualizado: ' + d.updated + ' apps');
    }else{
      setRepoUpdateLoading(false, 'Falha na atualização.');
      customAlert(JSON.stringify(d));
    }
  }catch(e){
    setRepoUpdateLoading(false, 'Erro na atualização.');
    customAlert(e.message||e);
  } finally {
    window.__repoUpdateBusy = false;
    var btn = document.getElementById('btnUpdate');
    if (btn) btn.disabled = false;
  }
});

if(document.getElementById('objSelect')){ on('objSelect', 'change', showVersions); }

on('envSelectHeader', 'change', function(){
  try {
    // Sempre exigir senha ao trocar de ambiente
    if (typeof ENV_PASS !== 'undefined') { try { ENV_PASS = null; } catch(_){} }
    if (typeof window !== 'undefined' && 'ENV_PASS' in window) { try { delete window.ENV_PASS; } catch(_){} }
    // Opcional: limpar qualquer cache de senha em atributos de dados (se houver)
    try { document.body && document.body.removeAttribute && document.body.removeAttribute('data-env-pass'); } catch(_){}
  } catch(_) {}

  try {
    // Sempre exigir senha ao trocar de ambiente
    if (typeof ENV_PASS !== 'undefined') { try { ENV_PASS = null; } catch(_){} }
    if (typeof window !== 'undefined' && 'ENV_PASS' in window) { try { delete window.ENV_PASS; } catch(_){} }
    // Opcional: limpar qualquer cache de senha em atributos de dados (se houver)
    try { document.body && document.body.removeAttribute && document.body.removeAttribute('data-env-pass'); } catch(_){}
  } catch(_) {}

  try { __updateOverviewHeadersForStage(__getSelectedEnvStage()); __toggleProdOnlyButtons(__getSelectedEnvStage());
  try { __normalizeOverviewColumnLayout(); } catch(_) {} } catch(_) {}

  // Atualiza lista de objetos (se houver função)
  if (typeof refreshAppsList === 'function') { try { refreshAppsList(); } catch(_){} }
  // Se já houver objeto selecionado, atualiza suas versões
  if ((function(){var _s=document.getElementById('objSelect'); return _s && _s.value;})()){
    try { showVersions(); } catch(_) {}
  }
  // Garantir que a senha seja solicitada ao disparar novo overview
  try { if (typeof ENV_PASS !== 'undefined') { ENV_PASS = null; } } catch(_){}
  // Dispara o overview automático (sem await)
  var btn = document.getElementById('btnOverview');
  if (btn) btn.click();
});
on('btnLogout', 'click', async function(){
  try{ await fetch('/api/logout', {method:'POST'});}catch(_){}
  location.href='/login';
});

on('btnOverview', 'click', async function(){
on('ovFilter','change', function(){
  var v = document.getElementById('ovFilter').value;
  var crossSet = new Set(['tax4b.wrapper','tax4b.dbobjects','tax4b.nomos-db','tax4b.nomos-js','tax4b.nomos-odata','tax4b.koine-db']);
  document.querySelectorAll('#overviewTable tbody tr').forEach(function(tr){
    var up = tr.getAttribute('data-up') === '1';
    var name = (tr.children[0] && tr.children[0].textContent || '').trim();
    var lname = name.toLowerCase();
    var show = false;
    if (v==='all') show = true;
    else if (v==='up') show = up;
    else if (v==='down') show = !up;
    else if (v==='cross') show = crossSet.has(name);
    else if (v==='db') show = lname.endsWith('-db');
    else if (v==='js') show = lname.endsWith('-js');
    else if (v==='odata') show = lname.endsWith('-odata');
    else if (v==='ui') show = lname.endsWith('-ui');
    else if (v==='backend') show = lname.endsWith('-backend');
    tr.style.display = show ? '' : 'none';
  });
});

  try{
    const envSel = document.getElementById('envSelectHeader');
    if(!envSel || !envSel.value){ customAlert('Selecione uma empresa/ambiente.'); return; }
    const envId = envSel.value;
  try { __updateOverviewHeadersForStage(__getSelectedEnvStage()); __toggleProdOnlyButtons(__getSelectedEnvStage());
  try { __normalizeOverviewColumnLayout(); } catch(_) {} } catch(_) {}

    let pass = (typeof ENV_PASS !== 'undefined' && ENV_PASS) ? ENV_PASS : null;
    if(!pass){
      pass = await customPasswordPrompt('Senha do usuário do ambiente para consulta:');
      if (pass === null) return;
      try{ ENV_PASS = pass; }catch(_){}
    }

    const wrap = document.getElementById('overviewWrap');
    const tbody = document.querySelector('#overviewTable tbody');
    if(wrap) wrap.style.display = 'block';
    if(tbody) tbody.innerHTML = '<tr><td colspan="4">Carregando overview do ambiente...</td></tr>';

    const r = await fetch('/api/overview', {
      method:'POST',
      headers:{'Content-Type':'application/json', 'X-Edit-Id': String((typeof document!=='undefined' && document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : ((typeof window!=='undefined' && window.currentEditId) ? window.currentEditId : ''))},
      body: JSON.stringify({ envId: envId, password: pass })
    });
    const j = await r.json();

    if(!tbody){ return; }
    tbody.innerHTML = '';
    if(!j || j.ok === false){
      const tr = document.createElement('tr');
      const td = document.createElement('td');
      td.colSpan = 4;
      td.innerHTML = '<div class="pre">' + (j && j.error ? j.error : 'Falha ao carregar overview') + '</div>';
      tr.appendChild(td);
      tbody.appendChild(tr);
      return;
    }

    (j.items||[]).forEach(function(it){
      var compId = (it.id || '').toString();
      if (compId.toLowerCase() === 'tax4b') { return; }
      const tr = document.createElement('tr');
      var up = (it.prev_version || '-') === (it.repo_version || '-');
      tr.setAttribute('data-up', up ? '1':'0');
      tr.innerHTML =
        '<td><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" class="ovSel" data-id="' + (it.id || '') + '"> <span>' + (it.id || '') + '</span></label></td>' +
        '<td>' + (it.prev_version || '-') + '</td>' +
        '<td>' + (it.repo_version || '-') + '</td>' +
        '<td class="actions-cell"><div class="actions"><button class="btn btnDeployRow" data-id="' + (it.id || '') + '">Deploy</button><button class="btn btnRollbackRow" data-id="' + (it.id || '') + '">Rollback</button></div></td>';
      tbody.appendChild(tr);
    });

    
try { __toggleProdOnlyButtons(__getSelectedEnvStage && __getSelectedEnvStage()); } catch(_){ }

// === Bulk deploy: selecionar múltiplos componentes no overview ===
(function(){
  try{
    // cria barra de ações acima da tabela (uma vez)
    if(!document.getElementById('overviewBulkBar')){
      var wrap = document.getElementById('overviewWrap');
      var tbl = document.getElementById('overviewTable');
      if(wrap && tbl){
        var bar = document.createElement('div');
        bar.id = 'overviewBulkBar';
        bar.style.cssText = 'display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:8px 0';
        bar.innerHTML =
          '<button id="btnDeploySelected" class="btn" title="Executa deploy em todos os componentes selecionados (respeitando dependências)">Deploy selecionados</button>' +
          '<button id="btnClearSelected" class="btn" title="Limpa a seleção">Limpar seleção</button>' + '<label class="muted" style="display:flex;gap:6px;align-items:center"><input id="chkSelectAllVisible" type="checkbox"> Selecionar Todos</label>' +
          '<small id="bulkMsg" class="muted"></small>';
        wrap.insertBefore(bar, tbl);

        // Persistir seleção de fonte do MTAR (normal/unshipped)
        try{
          var selSrc = document.getElementById('mtarSourceSelect');
          if (selSrc){
            var saved = null;
            try{ saved = localStorage.getItem('mtarSourceSelect'); }catch(_){ saved = null; }
            if (saved === 'normal' || saved === 'unshipped') selSrc.value = saved;
            selSrc.addEventListener('change', function(){
              try{ localStorage.setItem('mtarSourceSelect', String(selSrc.value||'normal')); }catch(_){ }
            });
          }
        }catch(_){ }
      }
    }

    function __getMtarSource(){
      try{ var el=document.getElementById('mtarSourceSelect'); var v=el?String(el.value||'normal'):'normal'; v=v.toLowerCase(); return (v==='unshipped') ? 'unshipped' : 'normal'; }catch(_){ return 'normal'; }
    }

    function getSelectedIds(){
      var ids = [];
      document.querySelectorAll('#overviewTable tbody input.ovSel:checked').forEach(function(chk){
        var id = chk.getAttribute('data-id');
        if(id) ids.push(id);
      });
      // uniq preserve order
      var seen = {};
      var out = [];
      ids.forEach(function(x){ if(!seen[x]){ seen[x]=1; out.push(x); } });
      return out;
    }

    function setBulkMsg(t){ try{ var el=document.getElementById('bulkMsg'); if(el) el.textContent = t||''; }catch(_){ } }

    // select all visible
    var chkAll = document.getElementById('chkSelectAllVisible');
    if(chkAll && !chkAll.__wired){
      chkAll.__wired = true;
      chkAll.addEventListener('change', function(){
        var on = !!chkAll.checked;
        document.querySelectorAll('#overviewTable tbody tr').forEach(function(tr){
          if(tr.style && tr.style.display==='none') return;
          var chk = tr.querySelector('input.ovSel');
          if(chk) chk.checked = on;
        });
      });
    }

    var btnClear = document.getElementById('btnClearSelected');
    if(btnClear && !btnClear.__wired){
      btnClear.__wired = true;
      btnClear.addEventListener('click', function(){
        document.querySelectorAll('#overviewTable tbody input.ovSel').forEach(function(chk){ chk.checked=false; });
        var a=document.getElementById('chkSelectAllVisible'); if(a) a.checked=false;
        setBulkMsg('');
      });
    }

    async function ensureEnvPasswordForDeploy(){
      var pwd = (typeof ENV_PASS !== 'undefined' && ENV_PASS) ? ENV_PASS : null;
      if(!pwd){
        pwd = await customPasswordPrompt('Senha do usuário do ambiente para efetuar o deploy:');
        if (pwd === null || pwd === '') return null;
        try{ ENV_PASS = pwd; }catch(_){}
      }
      return pwd;
    }

    // Resolve dependências para um conjunto de componentes selecionados.
    // Estratégia: consulta /api/validate/install-apps para cada componente e monta um grafo (dep -> comp),
    // depois faz uma ordenação por DFS (best-effort). Se a API falhar para algum item, segue apenas com o selecionado.
    async function buildDeployQueue(envId, selectedIds){
      var edges = {}; // dep -> [comp]
      var nodes = {}; // set of ids
      selectedIds.forEach(function(x){ nodes[x]=1; });

      for (var i=0;i<selectedIds.length;i++){
        var comp = selectedIds[i];
        try{
          var resp = await fetch('/api/validate/install-apps/' + encodeURIComponent(envId), {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify([{ app_name: comp }])
          });
          if(!resp.ok) continue;
          var miss = await resp.json();
          if(Array.isArray(miss)){
            miss.forEach(function(d){
              var depId = d && (d.id || d.component_id || d.component || d.name);
              if(!depId) return;
              depId = String(depId);
              nodes[depId]=1;
              if(!edges[depId]) edges[depId]=[];
              if(edges[depId].indexOf(comp)===-1) edges[depId].push(comp);
            });
          }
        }catch(_e){}
      }

      // invert edges into adjacency for DFS: comp -> deps (so we can order deps before comp)
      var depsOf = {};
      Object.keys(nodes).forEach(function(n){ depsOf[n]=[]; });
      Object.keys(edges).forEach(function(dep){
        edges[dep].forEach(function(comp){
          if(!depsOf[comp]) depsOf[comp]=[];
          if(depsOf[comp].indexOf(dep)===-1) depsOf[comp].push(dep);
        });
      });

      var order = [];
      var temp = {};
      var perm = {};
      function visit(n){
        if(perm[n]) return;
        if(temp[n]) return; // cycle; ignore
        temp[n]=1;
        var ds = depsOf[n] || [];
        for (var k=0;k<ds.length;k++) visit(ds[k]);
        perm[n]=1;
        order.push(n);
      }
      // visit selected first (so they end up later, after deps)
      for (var j=0;j<selectedIds.length;j++) visit(selectedIds[j]);

      // ensure deps that were discovered but not connected (rare) are included before dependents
      Object.keys(nodes).forEach(function(n){ if(!perm[n]) visit(n); });

      // remove items that are not in overview table at all? keep anyway (deploy endpoint will handle)
      // uniq
      var seen = {};
      var out = [];
      order.forEach(function(x){ if(!seen[x]){ seen[x]=1; out.push(x); } });
      return out;
    }

    async function runSingleDeploy(envId, objectId, pwd, ticket){
      return new Promise(async function(resolve){
        try{
          var rs = await fetch('/api/deploy-start', {
            method:'POST',
            headers:{'Content-Type':'application/json', 'X-Edit-Id': String((typeof document!=='undefined' && document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : ((typeof window!=='undefined' && window.currentEditId) ? window.currentEditId : ''))},
            body: JSON.stringify({ envId: envId, objectId: objectId, password: pwd, ticket: (ticket||'').trim(), packageSource: __getMtarSource() })
          });
          var js = await rs.json();
          if(!js.ok){ resolve({ok:false, error: js.error || 'Falha ao iniciar deploy'}); return; }

          document.getElementById('deployWrap').style.display = 'block';
          document.getElementById('deployStatus').textContent = 'executando';
          var box = document.getElementById('deployBox');
          if(box) box.textContent += '\\n\\n===== DEPLOY: ' + objectId + ' =====\\n';

          var es = new EventSource('/api/deploy-stream?token=' + encodeURIComponent(js.token));
          es.onmessage = function(ev2){
            if (!box) return;
            box.textContent += (ev2.data||'') + '\\n';
            box.scrollTop = box.scrollHeight;
          };
          es.addEventListener('done', function(ev2){
            try{
              var payload = JSON.parse(ev2.data||'{}');
              if(box) box.textContent += '\\n==> ' + (payload.ok ? 'Deploy OK: ' : 'Deploy ERRO: ') + objectId + '\\n';
              es.close();
              resolve({ok: !!payload.ok, payload: payload});
            }catch(_e){
              es.close();
              resolve({ok:false, error:'Falha ao interpretar retorno do deploy'});
            }
          });
          es.onerror = function(){ try{ es.close(); }catch(_){} resolve({ok:false, error:'Erro de stream do deploy'}); };
        }catch(e){
          resolve({ok:false, error: e && e.message ? e.message : String(e)});
        }
      });
    }

    var btnBulk = document.getElementById('btnDeploySelected');
    if(btnBulk && !btnBulk.__wired){
      btnBulk.__wired = true;
      btnBulk.addEventListener('click', async function(){
        try{
          var envSel = document.getElementById('envSelectHeader');
          if(!envSel || !envSel.value){ customAlert('Selecione uma empresa/ambiente.'); return; }
          var envId = envSel.value;

          var selected = getSelectedIds();
          if(!selected.length){ customAlert('Selecione ao menos 1 componente no overview.'); return; }

          // PRD: deploy em lote habilitado (rollback/dependências continuam bloqueados por regra separada)

          var pwd = await ensureEnvPasswordForDeploy();
          if(!pwd) return;

          var ticket = await customTicketPrompt('Informe o número do chamado (ticket) para o deploy em lote:');
          if(ticket === null) return;

          setBulkMsg('Resolvendo dependências...');
          var queue = await buildDeployQueue(envId, selected);

          // best-effort: garante que o selecionado venha depois dos deps
          setBulkMsg('Fila: ' + queue.length + ' item(ns). Iniciando...');

          for (var i=0;i<queue.length;i++){
            var obj = queue[i];
            setBulkMsg('Deploy ' + (i+1) + '/' + queue.length + ': ' + obj);
            var r = await runSingleDeploy(envId, obj, pwd, ticket);
            if(!r.ok){
              setBulkMsg('Erro no deploy de ' + obj + '. Processo interrompido.');
              customAlert('Erro no deploy de ' + obj + ': ' + (r.error||'ver logs'));
              return;
            }
          }
          setBulkMsg('Deploy em lote concluído!');
          try{ document.getElementById('btnOverview').click(); }catch(_){}
        }catch(e){
          customAlert(e && e.message ? e.message : String(e));
        }
      });
    }
  }catch(_e){}
})();

document.querySelectorAll('#overviewTable .btnDeployRow').forEach(function(btn){
      btn.addEventListener('click', async function(ev){
        const objectId = ev.currentTarget.getAttribute('data-id');
        if(!objectId){ customAlert('Objeto inválido.'); return; }
        
        // === Pré-validação de dependências antes do deploy (skip em PRD) ===
        const __st = (typeof __getSelectedEnvStage==='function' ? __getSelectedEnvStage() : null);
        if (__st !== 'PRD') {
        try {
          const envSelForCheck = document.getElementById('envSelectHeader');
          const envIdCheck = envSelForCheck && envSelForCheck.value ? envSelForCheck.value : envId;
          const checkResp = await fetch('/api/validate/install-apps/' + encodeURIComponent(envIdCheck), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify([{ app_name: objectId }])
          });
          if (checkResp && checkResp.ok) {
            const miss = await checkResp.json();
            if (Array.isArray(miss) && miss.length > 0) {
              customAlert('Este objeto possui dependências pendentes. Verifique as Dependências antes de executar o Deploy.');
              return; // bloqueia o deploy
            }
          } else {
            // Se a checagem falhar, por segurança bloqueia o deploy
            customAlert('Não foi possível verificar dependências. Tente novamente após atualizar o repositório.');
            return;
          }
        } catch(_e) {
          customAlert('Falha ao verificar dependências. Operação cancelada.');
          return;
        }
        } // fim skip guard
        // === fim pré-validação ===
let pwd = (typeof ENV_PASS !== 'undefined' && ENV_PASS) ? ENV_PASS : null;
        if(!pwd){
          pwd = await customPasswordPrompt('Senha do usuário do ambiente para efetuar o deploy:');
          if (pwd === null || pwd === '') return;
          try{ ENV_PASS = pwd; }catch(_){}
        }
        try{
          const rs = await fetch('/api/deploy-start', {
            method:'POST',
            headers:{'Content-Type':'application/json', 'X-Edit-Id': String((typeof document!=='undefined' && document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : ((typeof window!=='undefined' && window.currentEditId) ? window.currentEditId : ''))},
            body: JSON.stringify({ envId: envId, objectId: objectId, password: pwd, ticket: (await customTicketPrompt('Informe o número do chamado (ticket):'))?.trim(), packageSource: (typeof __getMtarSource==='function' ? __getMtarSource() : 'normal') })
          });
          const js = await rs.json();
          if(!js.ok){ customAlert(js.error || 'Falha ao iniciar deploy'); return; }

          document.getElementById('deployWrap').style.display = 'block';
          document.getElementById('deployBox').textContent = '';
          document.getElementById('deployStatus').textContent = 'executando';

          const es = new EventSource('/api/deploy-stream?token=' + encodeURIComponent(js.token));
          es.onmessage = function(ev2){
            const box = document.getElementById('deployBox');
            box.textContent += ev2.data + '\\\\n';
            box.scrollTop = box.scrollHeight;
          };
          es.addEventListener('done', async function(ev2){
            document.getElementById('deployStatus').textContent = 'finalizado';
            try{
              const payload = JSON.parse(ev2.data||'{}');
              document.getElementById('deployBox').textContent += '\\\\n==> ' + (payload.ok ? 'Deploy finalizado com sucesso.' : 'Deploy finalizado com erro.');
            
              customAlert(payload.ok ? 'Deploy concluído com sucesso.' : 'Deploy finalizado com erro. Verifique os logs.');
}catch(_){}
            es.close();
            // auto-refresh overview
            document.getElementById('btnOverview').click();
          });
          es.onerror = function(){ document.getElementById('deployStatus').textContent = 'erro'; es.close(); };
        }catch(e){
          customAlert(e.message||e);
        }
      });
    });
  }catch(e){
    const tbody = document.querySelector('#overviewTable tbody');
    if(tbody){
      const tr = document.createElement('tr');
      const td = document.createElement('td');
      td.colSpan = 4;
      td.innerHTML = '<div class="pre">Erro: ' + (e && e.message ? e.message : e) + '</div>';
      tr.appendChild(td);
      tbody.appendChild(tr);
    }
  }
});

on('btnEnvSave', 'click', async function(){
  var payload = {
    id: (document.getElementById('env_id') && document.getElementById('env_id').value
         ? Number(document.getElementById('env_id').value)
         : (window.currentEditId ? Number(window.currentEditId) : undefined)),
    name: document.getElementById('env_name').value.trim(),
    origem: document.getElementById('env_origem').value,
    org_url: document.getElementById('env_org_url').value.trim(),
    org: document.getElementById('env_org').value.trim(),
    space: document.getElementById('env_space').value.trim(),
    username: (document.getElementById('env_username') ? document.getElementById('env_username').value.trim() : ''),
    env_type: (document.getElementById('env_type') ? document.getElementById('env_type').value : ''),
    env_type: (document.getElementById('env_type') ? document.getElementById('env_type').value : ''),
    env_type: document.getElementById('env_type') ? document.getElementById('env_type').value : 'CF',
    stage: (document.getElementById('env_stage') ? document.getElementById('env_stage').value : 'HML')
  };
  document.getElementById('env_msg').textContent='Salvando...';
  try{
    var _eid = (document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : (window.currentEditId||'');
    var r=await fetch('/api/environments',{method:'POST',headers:{'Content-Type':'application/json', 'X-Edit-Id': String((typeof document!=='undefined' && document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : ((typeof window!=='undefined' && window.currentEditId) ? window.currentEditId : ''))},body:JSON.stringify(payload)});
    var j=await r.json();
    if(j.ok){
      document.getElementById('env_msg').textContent = (window.currentEditId ? 'Registro atualizado!' : 'Registro salvo!');
      window.currentEditId = null;
      var hid = document.getElementById('env_id'); if (hid) hid.value = '';
      var _b = document.getElementById('btnEnvSave'); if (_b) _b.textContent = 'Salvar empresa/ambiente';
      loadEnvs();
    } else if (j.duplicate) {
      document.getElementById('env_msg').textContent = j.error || 'Já existe um registro com as mesmas informações.';
    } else {
      document.getElementById('env_msg').textContent = j.error || 'Falha ao salvar';
    }
  }catch(e){
    document.getElementById('env_msg').textContent=e.message||e;
  }
});

loadEnvs();</script><footer class="footer"></footer>

<script>
document.addEventListener('DOMContentLoaded', function(){
  // Evita duplicidade de opções por chamadas repetidas
  window.__envLoading = false;
  window.__envLast = window.__envLast || '';

  if (typeof window.refreshEnvList === 'function'){
    const _orig = window.refreshEnvList;
    window.refreshEnvList = async function(){
      if (window.__envLoading) return;
      window.__envLoading = true;
      try {
        await _orig();
        // Normalizar e deduplicar opções se necessário
        const sel = document.getElementById('envSelectHeader') || document.getElementById('environmentSelect');
        if (sel){
          const seen = new Set();
          const opts = Array.from(sel.querySelectorAll('option'));
          for (let i=opts.length-1; i>=0; i--){
            const key = (opts[i].value||'') + '|' + (opts[i].textContent||'');
            if (opts[i].value === '' || !seen.has(key)){ seen.add(key); continue; }
            sel.removeChild(opts[i]);
          }
        }
      } finally {
        window.__envLoading = false;
      }
    };
  }

  // Chama uma vez no Home
  try{
    if (document.getElementById('envSelectHeader') && typeof refreshEnvList === 'function'){
      refreshEnvList();
    }
  }catch(e){ console.error('Erro ao carregar ambientes', e); }

  // Garante que os botões de rollback funcionem (delegação + wiring direto)
  /** 
   * Função wireRollbackButtons
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem wireRollbackButtons.
   * - Retorno: Valor compatível com o uso corrente.

   */
  function wireRollbackButtons(){
    document.querySelectorAll('.btnRollbackRow, #btnRollback, [data-action=\"rollback\"]').forEach(function(el){
      if (el.__wiredRollback) return;
      el.__wiredRollback = true;
      el.addEventListener('click', function(ev){
        ev.preventDefault();
        var id = el.getAttribute('data-id') || (el.closest('[data-component-id]') && el.closest('[data-component-id]').getAttribute('data-component-id')) || '';
        var sel = document.getElementById('envSelectHeader') || document.getElementById('environmentSelect');
        if(!sel || !sel.value){ customAlert('Selecione um ambiente.'); return; }
        if(!id){ customAlert('ID do componente não encontrado.'); return; }
        location.href = '/api/rollback/live?env_id=' + encodeURIComponent(sel.value) + '&component_id=' + encodeURIComponent(id);
      });
    });
  }
  wireRollbackButtons();
  new MutationObserver(wireRollbackButtons).observe(document.body, {subtree:true, childList:true});
});
</script>

<script>
document.addEventListener('DOMContentLoaded', function(){
  // Capturing listener cancels inline onclick/href and uses SSE
  document.addEventListener('click', async function(ev){
  if (window.__REPORT_MODE && !(ev.target && (ev.target.closest('#dlgReport') || ev.target.closest('#btnReport')))) { return; }

    var el = ev.target && ev.target.closest('.btnRollbackRow, #btnRollback, [data-action="rollback"]');
    if(!el) return;
      // Guard: ignore clicks on Report button/dialog so no other screens run
  if (ev.target && (ev.target.closest('#btnReport') || ev.target.closest('#dlgReport'))) {
    return;
  }
// Cancel any default navigation and inline handlers
    ev.preventDefault();
    ev.stopPropagation();
    ev.stopImmediatePropagation();
    try { el.onclick = null; el.setAttribute && el.setAttribute('onclick',''); }catch(_){}

    try{
      var id = el.getAttribute('data-id') || (el.closest('[data-component-id]') && el.closest('[data-component-id]').getAttribute('data-component-id')) || '';
      var sel = document.getElementById('envSelectHeader') || document.getElementById('environmentSelect');
      if(!sel || !sel.value){ customAlert('Selecione um ambiente.'); return; }
      if(!id){ customAlert('ID do componente não encontrado.'); return; }
      var pwd = await await customPasswordPrompt('Informe a senha do usuário do ambiente para executar o rollback:');
          if(!pwd) return;
          // Start rollback via token
      const rs = await fetch('/api/rollback-start', {
        method:'POST',
        headers:{'Content-Type':'application/json', 'X-Edit-Id': String((typeof document!=='undefined' && document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : ((typeof window!=='undefined' && window.currentEditId) ? window.currentEditId : ''))},
        body: JSON.stringify({ envId: sel.value, objectId: id, password: pwd, ticket: (await customTicketPrompt('Informe o número do chamado (ticket):'))?.trim(), packageSource: (typeof __getMtarSource==='function' ? __getMtarSource() : 'normal') })
      });
      const js = await rs.json();
      if(!js.ok){ customAlert(js.error || 'Falha ao iniciar rollback'); return; }

      // Show Deploy (tempo real) and stream there
      var wrap = document.getElementById('deployWrap');
      var box = document.getElementById('deployBox');
      var status = document.getElementById('deployStatus');
      if (wrap) wrap.style.display = 'block';
      if (box) box.textContent = '';
      if(status) status.textContent='rollback'; try{ document.getElementById('deployProgress').style.display='block'; }catch(_){}

      const es = new EventSource('/api/rollback-stream?token=' + encodeURIComponent(js.token));
      es.onmessage = function(ev2){
        if (!box) return;
        box.textContent += (ev2.data||'') + '\\n';
        box.scrollTop = box.scrollHeight;
      };
      es.addEventListener('done', function(ev2){
        try{
          const payload = JSON.parse(ev2.data||'{}');
          if(status) status.textContent = payload.ok ? 'concluído' : 'erro'; try{ document.getElementById('deployProgress').style.display='none'; }catch(_){}
          if (box) box.textContent += '\\n--- rollback ' + (payload.ok?'concluído com sucesso.':'finalizado com erro.');
            customAlert(payload.ok ? 'Rollback concluído com sucesso.' : 'Rollback finalizado com erro. Verifique os logs.' ) + '\\n';
        }catch(_){}
        es.close();
        var btn = document.getElementById('btnOverview'); if(btn) btn.click();
      });
      es.onerror = function(){ if(status) status.textContent='erro'; try{ document.getElementById('deployProgress').style.display='none'; }catch(_){} es.close(); };
    }catch(e){
      customAlert(e.message||e);
    }
  }, true); // capture = true
});
document.addEventListener('DOMContentLoaded', function(){
  const btnOpen = document.getElementById('btnOpenCreateUser');
  const dlg = document.getElementById('dlgCreateUser');
  const btnCancel = document.getElementById('btnCreateUserCancel');
  const btnSave = document.getElementById('btnCreateUserSave');

  if(btnOpen && dlg){
    btnOpen.addEventListener('click', ()=>{
      if(typeof dlg.showModal==='function') dlg.showModal(); else dlg.style.display='block';
    });
  }
  if(btnCancel && dlg){
    btnCancel.addEventListener('click', ()=>{
      if(typeof dlg.close==='function') dlg.close(); else dlg.style.display='none';
    });
  }
  if(btnSave){
    btnSave.addEventListener('click', async ()=>{
      const username = document.getElementById('cuUsername').value.trim();
      const email = document.getElementById('cuEmail').value.trim();
      const password = document.getElementById('cuPassword').value;
      const role = document.getElementById('cuRole').value;
      if(!username || !email || !password){ customAlert('Preencha usuário, e-mail e senha.'); return; }
      const r = await fetch('/api/users', {
        method:'POST',
        headers:{'Content-Type':'application/json', 'X-Edit-Id': String((typeof document!=='undefined' && document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : ((typeof window!=='undefined' && window.currentEditId) ? window.currentEditId : ''))},
        body: JSON.stringify({ username,email,password,role })
      });
      const j = await r.json();
      if(j.ok){
        customAlert('Usuário criado!');
        if(typeof dlg.close==='function') dlg.close(); else dlg.style.display='none';
      }else{
        customAlert(j.error || 'Erro ao criar usuário');
      }
    });
  }
});
</script>

<script>
// === Fix: delegated handler to garantir fechamento do Cancelar ===
document.addEventListener('click', function(ev){
  if (window.__REPORT_MODE && !(ev.target && (ev.target.closest('#dlgReport') || ev.target.closest('#btnReport')))) { return; }

  var c = ev.target && ev.target.closest && ev.target.closest('#btnCreateUserCancel');
  if(!c) return;
  try{
    var dlg = document.getElementById('dlgCreateUser');
    if(dlg){
      if(typeof dlg.close === 'function') dlg.close(); else dlg.style.display = 'none';
    }
  }catch(_){ }
});
// === fim fix cancelar ===

/* ===== Dependências: injeção pós-Rollback + SweetAlert (single handler) ===== */
(function(){
  async function ensureSwal(){
    if (window.Swal && typeof window.Swal.fire === 'function') return;
    await new Promise((resolve) => {
      const s = document.createElement('script');
      s.src = 'https://cdn.jsdelivr.net/npm/sweetalert2@11';
      s.defer = true;
      s.onload = resolve;
      s.onerror = resolve;
      document.head.appendChild(s);
    });
  }
  /** 
   * Função norm
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem norm.
   * - Retorno: Valor compatível com o uso corrente.
   * @param {{any}} t 
   */
  function norm(t){ return (t||'').toString().trim().toLowerCase(); }
  /** 
   * Função isRollback
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem isRollback.
   * - Retorno: Valor compatível com o uso corrente.
   * @param {{any}} btn 
   */
  function isRollback(btn){
    const t = norm(btn.textContent);
    return (btn.matches && btn.matches('[data-action="rollback"]')) ||
           t === 'rollback' || t.includes('rollback') || t === 'reverter' || t.includes('reverter');
  }
  /** 
   * Função inferIdFrom
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem inferIdFrom.
   * - Retorno: Valor compatível com o uso corrente.
   * @param {{any}} node 
   */
  function inferIdFrom(node){
    if(!node) return null;
    const attrs = ['data-id','data-app','data-object','data-name','data-component','data-key','data-component-id'];
    for (let i=0;i<attrs.length;i++){
      const v = node.getAttribute && node.getAttribute(attrs[i]);
      if (v) return v;
    }
    if (node.dataset){
      const pref = ['id','app','object','name','component','key','componentId'];
      for (let j=0;j<pref.length;j++){ if (node.dataset[pref[j]]) return node.dataset[pref[j]]; }
    }
    const host = node.closest && node.closest('tr,[data-id],[data-component-id]');
    if (host) return inferIdFrom(host);
    return null;
  }
  /** 
   * Função injectButtons
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem injectButtons.
   * - Retorno: Valor compatível com o uso corrente.
   * @param {{any}} root 
   */
  function injectButtons(root){
    const scope = root || document;
    const nodes = scope.querySelectorAll('button, a');
    nodes.forEach((b)=>{
      if (!isRollback(b)) return;
      const wrap = b.parentElement || b;
      const objectId = inferIdFrom(b) || inferIdFrom(wrap);
      if (wrap.querySelector('[data-action="check-deps"]')) return;
      const chk = document.createElement('button');
      chk.type = 'button';
      chk.className = 'btn btn-outline btnCheckDepsRow';
      chk.setAttribute('data-action','check-deps');
      if (objectId) chk.setAttribute('data-id', objectId);
      chk.textContent = 'Dependências';
      b.insertAdjacentElement('afterend', chk);
    
  try {
    var __st = (typeof __currentStage==='function' && __currentStage()) || (typeof __getSelectedEnvStage==='function' && __getSelectedEnvStage()) || null;
    var __probe = (__st||'').toString().toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
    if (__probe === 'PRD' || __probe === 'PROD' || __probe === 'PRODUCAO' || __probe === 'PRODUCTION') {
      try{
        // Desabilita botão de Dependências
        chk.setAttribute('data-disabled','1');
        chk.setAttribute('aria-disabled','true');
        chk.setAttribute('tabindex','-1');
        chk.disabled = true;
        chk.classList.add('disabled');

        // Desabilita também o botão de Rollback da mesma linha
        if (b && b.classList) {
          b.setAttribute('data-disabled','1');
          b.setAttribute('aria-disabled','true');
          b.setAttribute('tabindex','-1');
          b.disabled = true;
          b.classList.add('disabled');
        }
      }catch(_){}}
  } catch(_){}
});
  }
  
  // aplica regra imediatamente para PRD
  try {
    var __st = (typeof __getSelectedEnvStage==='function' && __getSelectedEnvStage()) || null;
    if (__isProdStage(__st)) {
      try{
        // Dependências
        chk.setAttribute('data-disabled','1');
        chk.setAttribute('aria-disabled','true');
        chk.style.opacity = '0.5';
        chk.style.pointerEvents = 'none';
        chk.style.filter = 'grayscale(1)';
        chk.style.cursor = 'not-allowed';
        if(!chk.getAttribute('title')) chk.setAttribute('title','Indisponível em Produção');

        // Rollback da mesma linha
        if (b && b.classList) {
          b.setAttribute('data-disabled','1');
          b.setAttribute('aria-disabled','true');
          b.style.opacity = '0.5';
          b.style.pointerEvents = 'none';
          b.style.filter = 'grayscale(1)';
          b.style.cursor = 'not-allowed';
          if(!b.getAttribute('title')) b.setAttribute('title','Indisponível em Produção');
        }
      }catch(_){}
    }
  } catch(_){}
if (!window.__depsListenerAdded){
    window.__depsListenerAdded = true;
    window.__depsPopupOpen = false;
    window.__checkDeps = async function(el){
      if (window.__depsPopupOpen) return false;
      window.__depsPopupOpen = true;
      try{
        let objectId = el.getAttribute && el.getAttribute('data-id');
        objectId = objectId || inferIdFrom(el);
        if (!objectId){
          await ensureSwal();
          if (window.Swal) await Swal.fire({icon:'error', title:'Erro', text:'Não foi possível identificar o componente.'});
          return false;
        }
        /** 
         * Função (arrow) qs
         * - O que faz: Procedimento/serviço utilizado no fluxo atual.
         * - Retorno: Conforme uso do chamador.
         * @param {{any}} s 
         */
        const qs = (s)=>document.querySelector(s);
        let envSel = qs('#envSelectHeader') || qs('#environmentSelect') || qs('#env') || qs('[name="envId"]');
        let envId = envSel && (envSel.value || envSel.getAttribute('value'));
        if(!envId){
          try{
            const u = new URL(window.location.href);
            envId = u.searchParams.get('target') || u.searchParams.get('env') || u.searchParams.get('environment');
          }catch(_){}
        }
        if(!envId){
          await ensureSwal();
          const ask = await Swal.fire({title:'Qual ambiente?', input:'text', inputPlaceholder:'ID ou nome do ambiente', showCancelButton:true});
          if (!ask || !ask.value) return false;
          envId = ask.value;
        }
        const res = await fetch('/api/validate/install-apps/' + encodeURIComponent(envId), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify([{ app_name: objectId }])
        });
        await ensureSwal();
        if(!res.ok){
          const txt = await res.text().catch(()=> '');
          await Swal.fire({icon:'error', title:'Falha ao consultar dependências',
                           html:'HTTP ' + res.status + '<pre style="text-align:left;white-space:pre-wrap">'+(txt||'')+'</pre>'});
          return false;
        }
        const miss = await res.json().catch(()=>[]);
        if (Array.isArray(miss) && miss.length){
          const listHtml = miss.map(function(m){ return '<li><code>' + (m.id||'') + '</code> &ge; <strong>' + (m.version||'') + '</strong></li>'; }).join('');
          await Swal.fire({title:'Dependências para ' + objectId,
                           html: '<ul style="text-align:left">' + listHtml + '</ul>', icon:'info', confirmButtonText:'OK'});
        } else {
          await Swal.fire({icon:'success', title:'Sem dependências pendentes',
                           text:'Nenhuma dependência a cumprir para ' + objectId});
        }
      }catch(e){
        await ensureSwal();
        await Swal.fire({icon:'error', title:'Erro',
                         text: (e && e.message) ? e.message : String(e)});
      }finally{
        window.__depsPopupOpen = false;
      }
      return false;
    };
    document.addEventListener('click', function(ev){
  if (window.__REPORT_MODE && !(ev.target && (ev.target.closest('#dlgReport') || ev.target.closest('#btnReport')))) { return; }

      const btn = ev.target && ev.target.closest && ev.target.closest('[data-action="check-deps"], .btnCheckDepsRow');
      if (!btn) return;
      ev.preventDefault(); ev.stopPropagation(); ev.stopImmediatePropagation();
      window.__checkDeps(btn);
    });
  }
  if (document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', function(){ injectButtons(document); });
  } else {
    injectButtons(document);
  }
  new MutationObserver((muts)=>{
    for (let i=0;i<muts.length;i++){
      if (muts[i].addedNodes && muts[i].addedNodes.length){ injectButtons(document); break; }
    }
  }).observe(document.documentElement, { childList:true, subtree:true });
})();
/* ===== fim injeção ver dependências ===== */
</script>
<!-- BEGIN Utilities (customAlert, toast, theme) -->
<div class="toast-container" id="toastContainer"></div>
<dialog id="customAlert" style="border:1px solid #9ca3af;border-radius:8px;padding:18px;max-width:520px;box-shadow:0 2px 10px rgba(0,0,0,.12)">
  <h3 style="margin:0 0 8px;font-size:16px">TAXONE FOR SAP Solutions diz:</h3>
  <div id="customAlertMsg" style="font-size:14px;line-height:1.4"></div>
  <div style="text-align:right;margin-top:14px">
    <button id="customAlertOk" class="btn">OK</button>
  </div>
</dialog>
<script>
(function(){
  
  /** 
   * Função ensureAlert
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem ensureAlert.
   * - Retorno: Valor compatível com o uso corrente.

   */
  function ensureAlert(){
    var dlg=document.getElementById('customAlert');
    if(!dlg){
      dlg=document.createElement('dialog'); dlg.id='customAlert';
      dlg.innerHTML='<h3>TAXONE FOR SAP Solutions diz:</h3><div id="customAlertMsg"></div><div style="text-align:right;margin-top:12px"><button id="customAlertOk" class="btn">OK</button></div>';
      document.body.appendChild(dlg);
    }
    var ok=document.getElementById('customAlertOk');
    if(ok){ ok.onclick=function(){ if(dlg.close) dlg.close(); else dlg.style.display='none'; }; }
    return dlg;
  }
  window.customAlert = function(msg){
    var dlg=ensureAlert();
    var box=document.getElementById('customAlertMsg'); if(box) box.textContent=(msg==null?'':String(msg));
    if(dlg.showModal) dlg.showModal(); else dlg.style.display='block';
  };
  window.toast = function(msg, type){
    var wrap=document.getElementById('toastContainer'); if(!wrap){ wrap=document.createElement('div'); wrap.id='toastContainer'; wrap.className='toast-container'; document.body.appendChild(wrap); }
    var t=document.createElement('div'); t.className='toast ' + (type||'info'); t.textContent=String(msg||''); wrap.appendChild(t);
    setTimeout(function(){ t.style.opacity='0'; setTimeout(function(){ t.remove(); }, 320); }, 3200);
  };
  
})();
</script>
<!-- END Utilities -->
<!-- BEGIN: Password Prompt -->
<dialog id="customPwdDialog" style="border:1px solid #9ca3af;border-radius:8px;padding:18px;max-width:520px;box-shadow:0 2px 10px rgba(0,0,0,.12)">
  <h3 style="margin:0 0 8px;font-size:16px">TAXONE FOR SAP Solutions diz:</h3>
  <div class="muted" id="customPwdMsg" style="margin-bottom:8px;font-size:14px;line-height:1.4"></div>
  <input id="customPwdInput" type="password" style="width:100%;-webkit-text-security:disc;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px">
  <div style="text-align:right;margin-top:12px;display:flex;gap:8px;justify-content:flex-end">
    <button id="customPwdCancel" class="btn">Cancelar</button>
    <button id="customPwdOk" class="btn">OK</button>
  </div>
</dialog>
<script>
(function(){
  window.customPasswordPrompt = function(message){
    return new Promise(function(resolve){
      var dlg = document.getElementById('customPwdDialog');
      if(!dlg){
        dlg = document.createElement('dialog');
        dlg.id = 'customPwdDialog';
        dlg.innerHTML = '<h3>TAXONE FOR SAP Solutions diz:</h3>' +
                        '<div id="customPwdMsg" class="muted" style="margin-bottom:8px"></div>' +
                        '<input id="customPwdInput" type="password" style="-webkit-text-security:disc;width:100%;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px">' +
                        '<div style="text-align:right;margin-top:12px"><button id="customPwdCancel" class="btn">Cancelar</button> <button id="customPwdOk" class="btn">OK</button></div>';
        document.body.appendChild(dlg);
      }
      var msg = document.getElementById('customPwdMsg');
      if(msg){ msg.textContent = message || 'Informe a senha:'; }
      var input = document.getElementById('customPwdInput');
      if(input){ input.value=''; input.setAttribute('type','password'); input.style.webkitTextSecurity='disc'; }
      /** 
       * Função onCancel
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onCancel.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onCancel(){ try{ dlg.close(); }catch(_){} cleanup(); resolve(null); }
      /** 
       * Função onOk
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onOk.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onOk(){ var v=input?input.value:''; try{ dlg.close(); }catch(_){} cleanup(); resolve(v); }
      /** 
       * Função onKey
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onKey.
       * - Retorno: Valor compatível com o uso corrente.
       * @param {{any}} e 
       */
      function onKey(e){ if(e.key==='Enter'){ e.preventDefault(); onOk(); } }
      /** 
       * Função cleanup
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem cleanup.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function cleanup(){
        try {
          document.getElementById('customPwdOk')?.removeEventListener('click', onOk);
          document.getElementById('customPwdCancel')?.removeEventListener('click', onCancel);
          input?.removeEventListener('keydown', onKey);
        } catch(_){}
      }
      document.getElementById('customPwdOk')?.addEventListener('click', onOk);
      document.getElementById('customPwdCancel')?.addEventListener('click', onCancel);
      input?.addEventListener('keydown', onKey);
      try{ input?.focus(); }catch(_){}
      if(dlg.showModal){ dlg.showModal(); } else { dlg.style.display='block'; }
    });
  };
})();
</script>
<!-- END: Password Prompt -->
<!-- BEGIN: Ticket Prompt -->
<dialog id="customTicketDialog" style="border:1px solid #9ca3af;border-radius:8px;padding:18px;max-width:520px;box-shadow:0 2px 10px rgba(0,0,0,.12)">
  <h3 style="margin:0 0 8px;font-size:16px">TAXONE FOR SAP Solutions diz:</h3>
  <div class="muted" id="customTicketMsg" style="margin-bottom:8px;font-size:14px;line-height:1.4"></div>
  <input id="customTicketInput" type="text" style="width:100%;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px" placeholder="Número do chamado (ticket)">
  <div style="text-align:right;margin-top:12px;display:flex;gap:8px;justify-content:flex-end">
    <button id="customTicketCancel" class="btn">Cancelar</button>
    <button id="customTicketOk" class="btn">OK</button>
  </div>
</dialog>
<script>
(function(){
  window.customTicketPrompt = function(message){
    return new Promise(function(resolve){
      var dlg = document.getElementById('customTicketDialog');
      if(!dlg){
        dlg = document.createElement('dialog');
        dlg.id = 'customTicketDialog';
        dlg.innerHTML = '<h3>TAXONE FOR SAP Solutions diz:</h3>' +
                        '<div id="customTicketMsg" class="muted" style="margin-bottom:8px"></div>' +
                        '<input id="customTicketInput" type="text" style="width:100%;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px" placeholder="Número do chamado (ticket)">' +
                        '<div style="text-align:right;margin-top:12px"><button id="customTicketCancel" class="btn">Cancelar</button> <button id="customTicketOk" class="btn">OK</button></div>';
        document.body.appendChild(dlg);
      }
      var msg = document.getElementById('customTicketMsg');
      if(msg){ msg.textContent = message || 'Informe o número do chamado (ticket):'; }
      var input = document.getElementById('customTicketInput');
      if(input){ input.value=''; }
      /** 
       * Função onCancel
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onCancel.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onCancel(){ try{ dlg.close(); }catch(_){} cleanup(); resolve(null); }
      /** 
       * Função onOk
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onOk.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onOk(){ var v=input?String(input.value||'').trim():''; try{ dlg.close(); }catch(_){} cleanup(); resolve(v); }
      /** 
       * Função onKey
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onKey.
       * - Retorno: Valor compatível com o uso corrente.
       * @param {{any}} e 
       */
      function onKey(e){ if(e.key==='Enter'){ e.preventDefault(); onOk(); } }
      /** 
       * Função cleanup
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem cleanup.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function cleanup(){
        try {
          document.getElementById('customTicketOk')?.removeEventListener('click', onOk);
          document.getElementById('customTicketCancel')?.removeEventListener('click', onCancel);
          input?.removeEventListener('keydown', onKey);
        } catch(_){}
      }
      document.getElementById('customTicketOk')?.addEventListener('click', onOk);
      document.getElementById('customTicketCancel')?.addEventListener('click', onCancel);
      input?.addEventListener('keydown', onKey);
      try{ input?.focus(); }catch(_){}
      if(dlg.showModal){ dlg.showModal(); } else { dlg.style.display='block'; }
    });
  };
})();
</script>
<!-- END: Ticket Prompt -->

<footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b></b>
</footer>
<footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b></b>
<footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b></b>
</footer>
<footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b>Desenvolvido por AMS Sustentação - Alliance Consultoria V3.0</b>
</footer>
</body></html>`;
  }
}

/** 
 * Classe EnvironmentsView
 * - O que faz: Representa uma entidade/serviço com estado e comportamentos.
 * - Observação: Métodos internos seguem as regras originais do código.
 */
class EnvironmentsView {
  static html(){
    return `<!DOCTYPE html><html lang="pt-br"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Ambientes (Empresas)</title>
<style>${baseCss}
  .empresas-form {margin:0 auto;max-width:860px;width:100%;}
  .empresas-note{ text-align:center; }
  .empresas-form {margin:0 auto;max-width:860px;width:100%;}
.stack{display:block;max-width:860px}
.stack label{display:block;font-size:13px;color:#334155;margin-top:8px}
.stack input,.stack select,.stack button{width:100%}
.stack button{margin-top:12px}

.footer{margin-top:16px;color:#666;font-size:12px;text-align:center;padding-top:8px;border-top:1px solid #eee}
.actions{display:flex;gap:8px;align-items:center}
#overviewTable td.actions-cell{white-space:nowrap}
.login-wrap{display:flex;flex-direction:column;align-items:center;justify-content:center}
.login-wrap .after-card-note{margin-top:8px}
</style>

</head><body>
<div class="container">
  <div class="header">
    <img src="/static/logo_translucent.png" alt="Alliance Consultoria">
    <h2 style="margin:0;font-size:18px">Ambientes (Empresas)</h2>
    <div style="margin-left:auto">
      <a class="btn" href="/">← Voltar</a>
    </div>
  </div>

  <p class="muted empresas-note">Cadastre as empresas/ambientes. A senha NÃO é armazenada: será solicitada no momento da consulta/deploy.</p>

  <div class="card stack empresas-form">
    <label>Empresa</label>
    <input id="env_name" placeholder="Ex.: Empresa X">

    <label>Origem</label>
    <select id="env_origem">
  <option value="" selected disabled>Selecione...</option>
  <option value="TR">TR</option>
  <option value="QAS">QAS</option>
</select>

    <label>URL Organização</label>
    <input id="env_org_url" placeholder="https://...">

    <label>ORG</label>
    <input id="env_org" placeholder="Ex.: MinhaOrg">

    <label>Ambiente (SPACE)</label>
    <input id="env_space" placeholder="Ex.: dev / prod">

    <label>Usuário</label>
    <input id="env_username" placeholder="Ex.: admin">

    <label>Tipo de Ambiente</label>
    <select id="env_type">
      <option value="" selected disabled>Selecione...</option>
      <option value="CF">CF</option>
      <option value="XS">XS</option>
    </select>

    <label>Uso do Ambiente</label>
    <select id="env_stage">
      <option value="" selected disabled>Selecione...</option>
      <option value="HML">Homologação</option>
      <option value="PRD">Produção</option>
    </select>
<input id="env_id" type="hidden" value="">

    <button id="btnEnvSave" class="btn">Salvar empresa/ambiente</button>
    <div id="env_msg" class="muted"></div>
  </div>

  <div class="card" style="margin-top:12px">
    <table id="env_table" class="table"><thead>
      <tr><th>Empresa</th><th>Origem</th><th>URL</th><th>ORG</th><th>Ambiente</th><th>Tipo</th>
<th>Homolog/Prod</th><th>Usuário</th><th>Ações</th></tr>
    </thead><tbody></tbody></table>
  </div>

<!-- TEXTO ADICIONADO FORA DO CARD -->
<div class="after-card-note" style="margin-top:6px; text-align:center; font-size:12px; color:#777; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  
</div>
<!-- fim texto adicionado -->
</div>

<script>
var $=function(s){return document.querySelector(s);};

async function loadEnvs(){
  var r=await fetch('/api/environments'); if(r.status===401){location.href='/login';return;}
  var d=await r.json(); var tb=document.querySelector('#env_table tbody'); tb.innerHTML='';
  (d.items||[]).sort(function(a,b){return (a.name||'').localeCompare(b.name||'');}).forEach(function(env){
    var tr=document.createElement('tr');
    tr.innerHTML =
      '<td>' + (env.name||'') + '</td>' +
      '<td>' + (env.origem||'') + '</td>' +
      '<td>' + (env.org_url||'') + '</td>' +
      '<td>' + (env.org||'') + '</td>' +
      '<td>' + (env.space||'') + '</td>' +
      '<td>' + (env.env_type||'') + '</td>' +
      '<td>' + (env.stage||'') + '</td>' + '<td>' + (env.username||'') + '</td>' + '<td><div class="actions"><button data-id="' + env.id + '" class="btn-edit">Editar</button> <button data-id="' + env.id + '" class="btn-del">Excluir</button></div></td>';
    tb.appendChild(tr);
  });
  
// --- Edição de empresa/ambiente ---
window.currentEditId = window.currentEditId || null;
Array.prototype.forEach.call(document.querySelectorAll('.btn-edit'), function(btn){
  btn.addEventListener('click', function(e){
    var id = e.target.getAttribute('data-id');
    var row = e.target.closest('tr');
    if (!row) return;
    // Preenche o formulário com os valores da linha (colunas fixas conforme cabeçalho)
    document.getElementById('env_name').value    = (row.children[0] && row.children[0].textContent) || '';
    document.getElementById('env_origem').value  = (row.children[1] && row.children[1].textContent) || '';
    document.getElementById('env_org_url').value = (row.children[2] && row.children[2].textContent) || '';
    document.getElementById('env_org').value     = (row.children[3] && row.children[3].textContent) || '';
    document.getElementById('env_space').value   = (row.children[4] && row.children[4].textContent) || '';
    document.getElementById('env_username').value = (row.children[7] && row.children[7].textContent) || '';
    var uso = ((row.children[6] && row.children[6].textContent) || '').toUpperCase();
    var usoSel = document.getElementById('env_stage'); if (usoSel) { usoSel.value = (uso === 'PRD' ? 'PRD' : 'HML'); }
    var tipo = ((row.children[5] && row.children[5].textContent) || '').toUpperCase();
    var tipoSel = document.getElementById('env_type');
    if (tipoSel) { tipoSel.value = (tipo === 'XS' ? 'XS' : 'CF'); }

    window.currentEditId = id;
        var hid = document.getElementById('env_id'); if (hid) hid.value = id;
    var btnSave = document.getElementById('btnEnvSave');
    if (btnSave) btnSave.textContent = 'Salvar alterações';
    var msg = document.getElementById('env_msg');
    if (msg) msg.textContent = 'Editando o registro #' + id + '. Altere os campos e clique em Salvar.';
    try { document.querySelector('.empresas-form').scrollIntoView({behavior:'smooth'}); } catch(_) {}
  });
});

Array.prototype.forEach.call(document.querySelectorAll('.btn-del'), function(btn){
    btn.addEventListener('click', async function(e){
      var id=e.target.getAttribute('data-id'); if(!confirm('Confirmar exclusão?')) return;
      var r=await fetch('/api/environments/'+id,{method:'DELETE'}); var j=await r.json();
      if(j.ok){ loadEnvs(); } else { customAlert(j.error||'Falha ao excluir'); }
    });
  });
}

document.getElementById('btnEnvSave').addEventListener('click', async function(){
  var origemSel = document.getElementById('env_origem').value;
  var tipoSel = (document.getElementById('env_type') ? document.getElementById('env_type').value : '');
  if(!origemSel){ customAlert('Selecione a Origem (TR ou QAS).'); return; }
  if(!tipoSel){ customAlert('Selecione o Tipo de Ambiente (XS ou CF).'); return; }
  var usoSel = (document.getElementById('env_stage') ? document.getElementById('env_stage').value : '');
  if(!usoSel){ customAlert('Selecione o Uso do Ambiente (Homologação ou Produção).'); return; }
  var payload = {
    name: document.getElementById('env_name').value.trim(),
    origem: document.getElementById('env_origem').value,
    org_url: document.getElementById('env_org_url').value.trim(),
    org: document.getElementById('env_org').value.trim(),
    space: document.getElementById('env_space').value.trim(),
    username: (document.getElementById('env_username') ? document.getElementById('env_username').value.trim() : ''),
    env_type: (document.getElementById('env_type') ? document.getElementById('env_type').value : ''),
    env_type: (document.getElementById('env_type') ? document.getElementById('env_type').value : ''),
    env_type: document.getElementById('env_type') ? document.getElementById('env_type').value : 'CF',
    stage: (document.getElementById('env_stage') ? document.getElementById('env_stage').value : 'HML')
  };
  document.getElementById('env_msg').textContent='Salvando...';
  try{
    var _eid = (document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : (window.currentEditId||'');
    var r=await fetch('/api/environments',{method:'POST',headers:{'Content-Type':'application/json', 'X-Edit-Id': String((typeof document!=='undefined' && document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : ((typeof window!=='undefined' && window.currentEditId) ? window.currentEditId : ''))},body:JSON.stringify(payload)});
    var j=await r.json();
    if(j.ok){
      document.getElementById('env_msg').textContent='Registro salvo!';
      loadEnvs();
    } else if (j.duplicate) {
      document.getElementById('env_msg').textContent = j.error || 'Já existe um registro com as mesmas informações.';
    } else {
      document.getElementById('env_msg').textContent = j.error || 'Falha ao salvar';
    }
  }catch(e){
    document.getElementById('env_msg').textContent=e.message||e;
  }
});

loadEnvs();
</script><footer class="footer">Desenvolvido por Alliance Consultoria V1.0</footer>

<script>
document.addEventListener('DOMContentLoaded', function(){
  // Capturing listener cancels inline onclick/href and uses SSE
  document.addEventListener('click', async function(ev){
  if (window.__REPORT_MODE && !(ev.target && (ev.target.closest('#dlgReport') || ev.target.closest('#btnReport')))) { return; }

    var el = ev.target && ev.target.closest('.btnRollbackRow, #btnRollback, [data-action="rollback"]');
    if(!el) return;
      // Guard: ignore clicks on Report button/dialog so no other screens run
  if (ev.target && (ev.target.closest('#btnReport') || ev.target.closest('#dlgReport'))) {
    return;
  }
// Cancel any default navigation and inline handlers
    ev.preventDefault();
    ev.stopPropagation();
    ev.stopImmediatePropagation();
    try { el.onclick = null; el.setAttribute && el.setAttribute('onclick',''); }catch(_){}

    try{
      var id = el.getAttribute('data-id') || (el.closest('[data-component-id]') && el.closest('[data-component-id]').getAttribute('data-component-id')) || '';
      var sel = document.getElementById('envSelectHeader') || document.getElementById('environmentSelect');
      if(!sel || !sel.value){ customAlert('Selecione um ambiente.'); return; }
      if(!id){ customAlert('ID do componente não encontrado.'); return; }
      var pwd = await await customPasswordPrompt('Informe a senha do usuário do ambiente para executar o rollback:');
          if(!pwd) return;
          // Start rollback via token
      const rs = await fetch('/api/rollback-start', {
        method:'POST',
        headers:{'Content-Type':'application/json', 'X-Edit-Id': String((typeof document!=='undefined' && document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : ((typeof window!=='undefined' && window.currentEditId) ? window.currentEditId : ''))},
        body: JSON.stringify({ envId: sel.value, objectId: id, password: pwd, ticket: (await customTicketPrompt('Informe o número do chamado (ticket):'))?.trim(), packageSource: (typeof __getMtarSource==='function' ? __getMtarSource() : 'normal') })
      });
      const js = await rs.json();
      if(!js.ok){ customAlert(js.error || 'Falha ao iniciar rollback'); return; }

      // Show Deploy (tempo real) and stream there
      var wrap = document.getElementById('deployWrap');
      var box = document.getElementById('deployBox');
      var status = document.getElementById('deployStatus');
      if (wrap) wrap.style.display = 'block';
      if (box) box.textContent = '';
      if(status) status.textContent='rollback'; try{ document.getElementById('deployProgress').style.display='block'; }catch(_){}

      const es = new EventSource('/api/rollback-stream?token=' + encodeURIComponent(js.token));
      es.onmessage = function(ev2){
        if (!box) return;
        box.textContent += (ev2.data||'') + '\\n';
        box.scrollTop = box.scrollHeight;
      };
      es.addEventListener('done', function(ev2){
        try{
          const payload = JSON.parse(ev2.data||'{}');
          if(status) status.textContent = payload.ok ? 'concluído' : 'erro'; try{ document.getElementById('deployProgress').style.display='none'; }catch(_){}
          if (box) box.textContent += '\\n--- rollback ' + (payload.ok?'concluído com sucesso.':'finalizado com erro.');
            customAlert(payload.ok ? 'Rollback concluído com sucesso.' : 'Rollback finalizado com erro. Verifique os logs.' ) + '\\n';
        }catch(_){}
        es.close();
        var btn = document.getElementById('btnOverview'); if(btn) btn.click();
      });
      es.onerror = function(){ if(status) status.textContent='erro'; try{ document.getElementById('deployProgress').style.display='none'; }catch(_){} es.close(); };
    }catch(e){
      customAlert(e.message||e);
    }
  }, true); // capture = true
});
document.addEventListener('DOMContentLoaded', function(){
  const btnOpen = document.getElementById('btnOpenCreateUser');
  const dlg = document.getElementById('dlgCreateUser');
  const btnCancel = document.getElementById('btnCreateUserCancel');
  const btnSave = document.getElementById('btnCreateUserSave');

  if(btnOpen && dlg){
    btnOpen.addEventListener('click', ()=>{
      if(typeof dlg.showModal==='function') dlg.showModal(); else dlg.style.display='block';
    });
  }
  if(btnCancel && dlg){
    btnCancel.addEventListener('click', ()=>{
      if(typeof dlg.close==='function') dlg.close(); else dlg.style.display='none';
    });
  }
  if(btnSave){
    btnSave.addEventListener('click', async ()=>{
      const username = document.getElementById('cuUsername').value.trim();
      const email = document.getElementById('cuEmail').value.trim();
      const password = document.getElementById('cuPassword').value;
      const role = document.getElementById('cuRole').value;
      if(!username || !email || !password){ customAlert('Preencha usuário, e-mail e senha.'); return; }
      const r = await fetch('/api/users', {
        method:'POST',
        headers:{'Content-Type':'application/json', 'X-Edit-Id': String((typeof document!=='undefined' && document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : ((typeof window!=='undefined' && window.currentEditId) ? window.currentEditId : ''))},
        body: JSON.stringify({ username,email,password,role })
      });
      const j = await r.json();
      if(j.ok){
        customAlert('Usuário criado!');
        if(typeof dlg.close==='function') dlg.close(); else dlg.style.display='none';
      }else{
        customAlert(j.error || 'Erro ao criar usuário');
      }
    });
  }
});
</script>
<!-- BEGIN Utilities (customAlert, toast, theme) -->
<div class="toast-container" id="toastContainer"></div>
<dialog id="customAlert" style="border:1px solid #9ca3af;border-radius:8px;padding:18px;max-width:520px;box-shadow:0 2px 10px rgba(0,0,0,.12)">
  <h3 style="margin:0 0 8px;font-size:16px">TAXONE FOR SAP Solutions diz:</h3>
  <div id="customAlertMsg" style="font-size:14px;line-height:1.4"></div>
  <div style="text-align:right;margin-top:14px">
    <button id="customAlertOk" class="btn">OK</button>
  </div>
</dialog>
<script>
(function(){
  
  /** 
   * Função ensureAlert
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem ensureAlert.
   * - Retorno: Valor compatível com o uso corrente.

   */
  function ensureAlert(){
    var dlg=document.getElementById('customAlert');
    if(!dlg){
      dlg=document.createElement('dialog'); dlg.id='customAlert';
      dlg.innerHTML='<h3>TAXONE FOR SAP Solutions diz:</h3><div id="customAlertMsg"></div><div style="text-align:right;margin-top:12px"><button id="customAlertOk" class="btn">OK</button></div>';
      document.body.appendChild(dlg);
    }
    var ok=document.getElementById('customAlertOk');
    if(ok){ ok.onclick=function(){ if(dlg.close) dlg.close(); else dlg.style.display='none'; }; }
    return dlg;
  }
  window.customAlert = function(msg){
    var dlg=ensureAlert();
    var box=document.getElementById('customAlertMsg'); if(box) box.textContent=(msg==null?'':String(msg));
    if(dlg.showModal) dlg.showModal(); else dlg.style.display='block';
  };
  window.toast = function(msg, type){
    var wrap=document.getElementById('toastContainer'); if(!wrap){ wrap=document.createElement('div'); wrap.id='toastContainer'; wrap.className='toast-container'; document.body.appendChild(wrap); }
    var t=document.createElement('div'); t.className='toast ' + (type||'info'); t.textContent=String(msg||''); wrap.appendChild(t);
    setTimeout(function(){ t.style.opacity='0'; setTimeout(function(){ t.remove(); }, 320); }, 3200);
  };
  
})();
</script>
<!-- END Utilities -->
<!-- BEGIN: Password Prompt -->
<dialog id="customPwdDialog" style="border:1px solid #9ca3af;border-radius:8px;padding:18px;max-width:520px;box-shadow:0 2px 10px rgba(0,0,0,.12)">
  <h3 style="margin:0 0 8px;font-size:16px">TAXONE FOR SAP Solutions diz:</h3>
  <div class="muted" id="customPwdMsg" style="margin-bottom:8px;font-size:14px;line-height:1.4"></div>
  <input id="customPwdInput" type="password" style="width:100%;-webkit-text-security:disc;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px">
  <div style="text-align:right;margin-top:12px;display:flex;gap:8px;justify-content:flex-end">
    <button id="customPwdCancel" class="btn">Cancelar</button>
    <button id="customPwdOk" class="btn">OK</button>
  </div>
</dialog>
<script>
(function(){
  window.customPasswordPrompt = function(message){
    return new Promise(function(resolve){
      var dlg = document.getElementById('customPwdDialog');
      if(!dlg){
        dlg = document.createElement('dialog');
        dlg.id = 'customPwdDialog';
        dlg.innerHTML = '<h3>TAXONE FOR SAP Solutions diz:</h3>' +
                        '<div id="customPwdMsg" class="muted" style="margin-bottom:8px"></div>' +
                        '<input id="customPwdInput" type="password" style="-webkit-text-security:disc;width:100%;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px">' +
                        '<div style="text-align:right;margin-top:12px"><button id="customPwdCancel" class="btn">Cancelar</button> <button id="customPwdOk" class="btn">OK</button></div>';
        document.body.appendChild(dlg);
      }
      var msg = document.getElementById('customPwdMsg');
      if(msg){ msg.textContent = message || 'Informe a senha:'; }
      var input = document.getElementById('customPwdInput');
      if(input){ input.value=''; input.setAttribute('type','password'); input.style.webkitTextSecurity='disc'; }
      /** 
       * Função onCancel
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onCancel.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onCancel(){ try{ dlg.close(); }catch(_){} cleanup(); resolve(null); }
      /** 
       * Função onOk
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onOk.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onOk(){ var v=input?input.value:''; try{ dlg.close(); }catch(_){} cleanup(); resolve(v); }
      /** 
       * Função onKey
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onKey.
       * - Retorno: Valor compatível com o uso corrente.
       * @param {{any}} e 
       */
      function onKey(e){ if(e.key==='Enter'){ e.preventDefault(); onOk(); } }
      /** 
       * Função cleanup
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem cleanup.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function cleanup(){
        try {
          document.getElementById('customPwdOk')?.removeEventListener('click', onOk);
          document.getElementById('customPwdCancel')?.removeEventListener('click', onCancel);
          input?.removeEventListener('keydown', onKey);
        } catch(_){}
      }
      document.getElementById('customPwdOk')?.addEventListener('click', onOk);
      document.getElementById('customPwdCancel')?.addEventListener('click', onCancel);
      input?.addEventListener('keydown', onKey);
      try{ input?.focus(); }catch(_){}
      if(dlg.showModal){ dlg.showModal(); } else { dlg.style.display='block'; }
    });
  };
})();
</script>
<!-- END: Password Prompt -->
<!-- BEGIN: Ticket Prompt -->
<dialog id="customTicketDialog" style="border:1px solid #9ca3af;border-radius:8px;padding:18px;max-width:520px;box-shadow:0 2px 10px rgba(0,0,0,.12)">
  <h3 style="margin:0 0 8px;font-size:16px">TAXONE FOR SAP Solutions diz:</h3>
  <div class="muted" id="customTicketMsg" style="margin-bottom:8px;font-size:14px;line-height:1.4"></div>
  <input id="customTicketInput" type="text" style="width:100%;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px" placeholder="Número do chamado (ticket)">
  <div style="text-align:right;margin-top:12px;display:flex;gap:8px;justify-content:flex-end">
    <button id="customTicketCancel" class="btn">Cancelar</button>
    <button id="customTicketOk" class="btn">OK</button>
  </div>
</dialog>
<script>
(function(){
  window.customTicketPrompt = function(message){
    return new Promise(function(resolve){
      var dlg = document.getElementById('customTicketDialog');
      if(!dlg){
        dlg = document.createElement('dialog');
        dlg.id = 'customTicketDialog';
        dlg.innerHTML = '<h3>TAXONE FOR SAP Solutions diz:</h3>' +
                        '<div id="customTicketMsg" class="muted" style="margin-bottom:8px"></div>' +
                        '<input id="customTicketInput" type="text" style="width:100%;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px" placeholder="Número do chamado (ticket)">' +
                        '<div style="text-align:right;margin-top:12px"><button id="customTicketCancel" class="btn">Cancelar</button> <button id="customTicketOk" class="btn">OK</button></div>';
        document.body.appendChild(dlg);
      }
      var msg = document.getElementById('customTicketMsg');
      if(msg){ msg.textContent = message || 'Informe o número do chamado (ticket):'; }
      var input = document.getElementById('customTicketInput');
      if(input){ input.value=''; }
      /** 
       * Função onCancel
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onCancel.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onCancel(){ try{ dlg.close(); }catch(_){} cleanup(); resolve(null); }
      /** 
       * Função onOk
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onOk.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onOk(){ var v=input?String(input.value||'').trim():''; try{ dlg.close(); }catch(_){} cleanup(); resolve(v); }
      /** 
       * Função onKey
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onKey.
       * - Retorno: Valor compatível com o uso corrente.
       * @param {{any}} e 
       */
      function onKey(e){ if(e.key==='Enter'){ e.preventDefault(); onOk(); } }
      /** 
       * Função cleanup
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem cleanup.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function cleanup(){
        try {
          document.getElementById('customTicketOk')?.removeEventListener('click', onOk);
          document.getElementById('customTicketCancel')?.removeEventListener('click', onCancel);
          input?.removeEventListener('keydown', onKey);
        } catch(_){}
      }
      document.getElementById('customTicketOk')?.addEventListener('click', onOk);
      document.getElementById('customTicketCancel')?.addEventListener('click', onCancel);
      input?.addEventListener('keydown', onKey);
      try{ input?.focus(); }catch(_){}
      if(dlg.showModal){ dlg.showModal(); } else { dlg.style.display='block'; }
    });
  };
})();
</script>
<!-- END: Ticket Prompt -->

<footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b></b>
</footer>
<footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b></b>
<footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b></b>
</footer>
<footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b>Desenvolvido por AMS Sustentação - Alliance Consultoria V3.0</b>
</footer>
</body></html>`;
  }
}

/** 
 * Classe EnvironmentsController
 * - O que faz: Representa uma entidade/serviço com estado e comportamentos.
 * - Observação: Métodos internos seguem as regras originais do código.
 */
class EnvironmentsController {
  constructor(envSvc){ this.envSvc=envSvc; this.router=express.Router(); this.mount(); }
  mount(){
    this.router.get('/environments', this.page.bind(this));
    this.router.get('/api/environments', this.list.bind(this));
    this.router.post('/api/environments', this.save.bind(this));
    this.router.delete('/api/environments/:id', this.remove.bind(this));
  }
  page(req,res){ res.type('html').send(EnvironmentsView.html()); }
  async list(req,res){ try{ res.json({items: await this.envSvc.listAll()}); }catch(e){ res.status(500).json({error:e.message||String(e)}); } }
  
async save(req,res){
    try{
      const {id,name,origem,org_url,org,space,username,env_type,stage} = req.body||{};
      // Robust: aceitar id vindo de body.env_id, header X-Edit-Id ou query ?id
      let _id = id;
      if (!_id && req && req.body && req.body.env_id) _id = req.body.env_id;
      if (!_id && req && req.headers && req.headers['x-edit-id']) _id = req.headers['x-edit-id'];
      if (!_id && req && req.query && req.query.id) _id = req.query.id;
      if (_id != null && _id !== '' && !Number.isNaN(Number(_id))) _id = Number(_id);

      if(!name||!origem||!['TR','QAS'].includes(origem)) return res.status(400).json({ok:false,error:'Informe empresa e origem (TR ou QAS).'});
      const result=await this.envSvc.createOrUpdate({id:_id,name,origem,org_url,org,space,username,env_type,stage});
      if (result.duplicate) return res.json({ ok:false, duplicate:true, id:result.id, error:'Já existe um registro com as mesmas informações.' });
      return res.json({ ok:true, id:result.id });
    }catch(e){ res.status(500).json({ok:false,error:e.message||String(e)}); }
  }
  async remove(req,res){ try{ const id=Number(req.params.id); if(!id) return res.status(400).json({ok:false,error:'ID inválido'}); await this.envSvc.delete(id); res.json({ok:true}); }catch(e){ res.status(500).json({ok:false,error:e.message||String(e)}); } }
}

/** 
 * Classe AppsController
 * - O que faz: Representa uma entidade/serviço com estado e comportamentos.
 * - Observação: Métodos internos seguem as regras originais do código.
 */
class AppsController {
  async report(req,res){
    try{
      // Accept either direct company/space or envId to derive
      let { company_name, company, empresa, space, start, end, envId, env_id } = (req.query || {});
      company_name = company_name || company || empresa || null;
      space = space || null;
      const envKey = envId || env_id || null;

      if ((!company_name || !space) && envKey){
        try{
          const row = await this.envSvc.getById(Number(envKey));
          if (row){ company_name = company_name || (row.name || null); space = space || (row.space || null); }
        }catch(_){}
      }

      /** 
       * Função normDate
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem normDate.
       * - Retorno: Valor compatível com o uso corrente.
       * @param {{any}} d 
       */
      function normDate(d){
        if(!d) return null;
        if (/^\d{4}-\d{2}-\d{2}$/.test(String(d))) return String(d);
        const m2 = String(d).match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
        if (m2) return `${m2[3]}-${m2[2]}-${m2[1]}`;
        return null;
      }
      start = normDate(start) || null;
      end   = normDate(end)   || null;

      if(!start || !end){
        return res.status(400).json({ ok:false, error: 'Informe período (start e end) no formato YYYY-MM-DD.' });
      }

      // Build query
      const params = [];
      let where = "WHERE 1=1";
      if (company_name){ where += " AND ifnull(company_name,'') = ?"; params.push(company_name); }
      if (space){ where += " AND ifnull(space,'') = ?"; params.push(space); }
      where += " AND datetime(ts) >= datetime(?, 'start of day') AND datetime(ts) <= datetime(?, 'start of day', '+1 day', '-1 second')";
      params.push(start, end);

      const rows = await this.appsSvc.db.all(
        `SELECT ts, company_name, space, object_id, prev_version, new_version, executor_user, ticket
           FROM deploy_audit ${where}
           ORDER BY datetime(ts) ASC`, params);

      // Generate PDF
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="relatorio_deploy_${(company_name||'todas').replace(/\W+/g,'_')}_${(space||'todos').replace(/\W+/g,'_')}_${start}_a_${end}.pdf"`);

      // === Pretty PDF rendering (headers aligned with content) ===
const secondary = '#0f172a';
const zebra = '#FAFAFA';
const grid = '#E5E7EB';

const doc = new PDFDocument({ margin: 36, size: 'A4', layout: 'landscape', bufferPages: true });
doc.pipe(res);

// --- Helpers to keep all pages identical & enforce single-line cells ---
function drawPageChrome(){
  try{
    let logoPath = path.join(__dirname, 'logo.png');
    if (!fs.existsSync(logoPath)) { logoPath = path.join(__dirname, 'static', 'logo.png'); }
    if (!fs.existsSync(logoPath)) { logoPath = path.join(__dirname, 'static', 'logo1.png'); }
    if (fs.existsSync(logoPath)){
      doc.image(logoPath, 36, 14, { width: 110 });
    }
  }catch(_){/* logo opcional */}
  doc.fillColor(secondary).font('Helvetica').fontSize(16)
     .text('Relatório de Deploy — Alliance Consultoria', 36, 16, { width: doc.page.width - 72, align: 'center', lineBreak: false });
  doc.font('Helvetica').fontSize(9).fillColor('#334155')
     .text(`Empresa: ${company_name || 'Todas'}  •  Space: ${space || 'Todos'}  •  Período: ${start} á ${end}`, 36, 36, { width: doc.page.width - 72, align: 'center', lineBreak: false });
  y = 66;
  drawHeader();
  // Padroniza fonte do corpo (linhas) após cabeçalho
  doc.font('Helvetica').fontSize(9).fillColor('#0F172A');
}

function fitToWidth(text, maxWidth){
  if (text == null) return '';
  let s = String(text).replace(/[\r\n]+/g, ' ').replace(/\s+/g, ' ').trim();
  const ell = '…';
  if (doc.widthOfString(s) <= maxWidth) return s;
  let lo = 0, hi = s.length;
  while (lo < hi){
    const mid = Math.floor((lo + hi + 1) / 2);
    if (doc.widthOfString(s.slice(0, mid) + ell) <= maxWidth){
      lo = mid;
    } else {
      hi = mid - 1;
    }
  }
  return s.slice(0, lo) + ell;
}

// Header — centered
// Columns
const columns = [
  { key:'ts',            label:'Data/Hora',       width: 95 },
  { key:'company_name',  label:'Empresa',         width: 105 },
  { key:'space',         label:'Space',           width: 55 },
  { key:'object_id',     label:'Componente',      width: 180 },
  { key:'prev_version',  label:'Versão Anterior', width: 85 },
  { key:'new_version',   label:'Nova Versão',     width: 85 },
  { key:'executor_user', label:'Usuário',        width: 85 },
  { key:'ticket',        label:'Ticket',          width: 80 },
];

let x = 36, y = 66;
const rowH = 18;
const tableWidth = columns.reduce((a,c)=>a+c.width,0);

// draw header after variables are ready
drawPageChrome();
/** 
 * Função drawHeader
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem drawHeader.
 * - Retorno: Valor compatível com o uso corrente.

 */
function drawHeader(){
  // Padroniza fonte do cabeçalho em todas as páginas
  doc.font('Helvetica').fillColor('#0F172A').fontSize(10);
  doc.save().lineWidth(0.8).strokeColor(grid).roundedRect(x, y, tableWidth, rowH, 5).stroke().restore();
  let cx = x + 6;
  for (const c of columns){
    const align = (['ticket','executor_user','space'].includes(c.key)) ? 'center' : 'left';
    doc.text(c.label, cx, y + 4, { width: c.width - 10, ellipsis: true, lineBreak: false, align });
    cx += c.width;
  }
  y += rowH;
}
if (rows && rows.length > 0) { /* header drawn by drawPageChrome() */ }

doc.font('Helvetica').fontSize(9).fillColor('#0F172A');
let count = 0;
let __shouldDrawHeader = false;
doc.on('pageAdded', function(){
  if (__shouldDrawHeader) { drawPageChrome(); }
  // Padroniza fonte do corpo em novas páginas
  doc.font('Helvetica').fontSize(9).fillColor('#0F172A');
  __shouldDrawHeader = false;
});
/** 
 * Função drawRow
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem drawRow.
 * - Retorno: Valor compatível com o uso corrente.
 * @param {{any}} row 
 */
function drawRow(row){
  if (count % 2 === 1){
    doc.save().rect(x, y, tableWidth, rowH).fill(zebra).restore();
  }
  doc.save().lineWidth(0.5).strokeColor(grid).rect(x, y, tableWidth, rowH).stroke().restore();
  let cx = x + 6;
  for (const c of columns){
  let val = row[c.key];
  if (c.key === 'ts' && val) {
    try { val = String(val).replace('T',' ').split('.')[0]; } catch(_){ }
  }
  const align = (['ticket','executor_user','space'].includes(c.key)) ? 'center' : 'left';
  const textVal = fitToWidth(val, c.width - 10);
  doc.text(textVal, cx, y + 4, { width: c.width - 10, ellipsis: true, lineBreak: false, align });
  cx += c.width;
}

  y += rowH;
  count++;
}

/** 
 * Função ensureSpace
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem ensureSpace.
 * - Retorno: Valor compatível com o uso corrente.
 * @param {{any}} remaining 
 */
function ensureSpace(remaining){
  if (remaining > 0 && (y + rowH > doc.page.height - 36)) {
    __shouldDrawHeader = true;
    doc.addPage();
  }
}

if (!rows || rows.length === 0){
  doc.font('Helvetica-Oblique').fillColor('#475569').fontSize(11)
     .text('Nenhum registro encontrado para o período informado.', x, y + 8);
} else {
  for (let i=0;i<rows.length;i++){
    ensureSpace(rows.length - i - 1);
    drawRow(rows[i]);
  }
}

// Footer
// footer desabilitado
doc.end();
// === /Pretty PDF rendering ===// === /Pretty PDF rendering ===// === /Pretty PDF rendering ===// === /Pretty PDF rendering ===// === /Pretty PDF rendering ===
}
catch(e){
      try{ console.error('report error', e && e.message ? e.message : String(e)); }catch(_){}
      res.status(500).json({ ok:false, error: (e && e.message) || String(e) });
    }
  }

  
  async __auditInsert(req, row){
    try{
      // Discover available columns in deploy_audit and cache
      if(!this.__auditCols){
        const cols = await this.appsSvc.db.all(`PRAGMA table_info(deploy_audit)`);
        this.__auditCols = new Set(Array.isArray(cols) ? cols.map(c => c.name) : []);
      }
      /** 
       * Função (arrow) has
       * - O que faz: Procedimento/serviço utilizado no fluxo atual.
       * - Retorno: Conforme uso do chamador.
       * @param {{any}} c 
       */
      const has = (c) => this.__auditCols.has(c);

      
      // --- Minimal rule for action_type ---
      const __url = ((req && (req.originalUrl || req.url)) || '').toString();
      let __actionType = (row && row.action_type) || null;
      if (!__actionType) {
        __actionType = /rollback/i.test(__url) ? 'Rollback' : 'Atualização';
      }
      // --- end minimal rule ---
// Base columns (from original schema)
      const base = ['ts','env_id','company_name','org','space','object_id','prev_version','new_version','executor_user','status','log_text'];
      // Optional columns that may or may not exist
      const optional = ['ticket','action_type','ip','user_agent','host'];

      // Build final column list in the exact order above when present
      const cols = [];
      for(const c of base){ if(has(c)) cols.push(c); }
      for(const c of optional){ if(has(c)) cols.push(c); }

      // Assemble VALUES parts and params (ts via SQL function)
      const placeholders = [];
      const params = [];
      for(const c of cols){
        if(c === 'ts') continue; // will use datetime('now','localtime')
        placeholders.push('?');
        switch(c){
          case 'env_id': params.push(row.env_id ?? null); break;
          case 'company_name': params.push(row.company_name ?? null); break;
          case 'org': params.push(row.org ?? null); break;
          case 'space': params.push(row.space ?? null); break;
          case 'object_id': params.push(row.object_id ?? null); break;
          case 'prev_version': params.push(row.prev_version ?? null); break;
          case 'new_version': params.push(row.new_version ?? null); break;
          case 'executor_user': params.push(row.executor_user ?? null); break;
          case 'ticket':
            params.push((typeof row.ticket === 'string' || typeof row.ticket === 'number') ? String(row.ticket) : (row.ticket ?? null));
            break;
          case 'status': params.push(row.status ?? null); break;
          case 'action_type': params.push(__actionType); break;
          case 'ip':
            params.push((req && req.headers && (req.headers['x-forwarded-for'] || req.headers['x-real-ip'])) || (req && req.socket && req.socket.remoteAddress) || null);
            break;
          case 'user_agent': params.push((req && req.headers && req.headers['user-agent']) || null); break;
          case 'host': params.push((req && req.get && req.get('host')) || (req && req.hostname) || null); break;
          case 'log_text': params.push((row.log_text!=null ? String(row.log_text) : '').slice(0, 300000)); break;
          default: params.push(null);
        }
      }

      const sql = `INSERT INTO deploy_audit
        (${cols.join(', ')})
        VALUES (${ ['ts'].includes(cols[0]) ? "datetime('now','localtime')" : "datetime('now','localtime')" }, ${placeholders.join(', ')})`;

      await this.appsSvc.db.run(sql, params);
      try{ console.log('[audit] insert ok', {object_id: row.object_id, status: row.status}); }catch(_){}
    }catch(e){
      try{ console.error('[audit] insert failed', e && e.message ? e.message : String(e)); }catch(_){}
    }
  }

  constructor(appsSvc, envSvc){ 
    this.appsSvc=appsSvc; 
    this.envSvc=envSvc;
    this.router=express.Router(); 
    this.deployTokens = new Map(); // token => {envId, objectId, password, user}
    
    
    this.rollbackTokens = new Map(); // token => {envId, objectId, password, user, targetVersion}
this.rollbackTokens = new Map(); // token => {envId, objectId, password, user}
this.rollbackTokens = new Map(); // token => {envId, objectId, password, user}
    this.mount(); 
  }
  mount(){
            this.router.post('/api/validate/install-apps/:target', this.validateInstall.bind(this));
this.router.get('/api/update-apps', this.update.bind(this));
    this.router.get('/api/apps', this.listApps.bind(this));
    this.router.get('/api/versions/:id', this.versions.bind(this));
    this.router.post('/api/overview', this.overview.bind(this));
    this.router.post('/api/object-env-status', this.objectEnvStatus.bind(this));
    this.router.post('/api/deploy-start', this.deployStart.bind(this));
    this.router.get('/api/deploy-stream', this.deployStream.bind(this));
    // Rollback routes
    this.router.post('/api/rollback-start', this.rollbackStart.bind(this));
    this.router.get('/api/rollback-stream', this.rollbackStream.bind(this));
    this.router.get('/api/rollback/live', this.rollbackLive.bind(this));
    this.router.post('/api/rollback/live', this.rollbackLive.bind(this));
    this.router.get('/', this.renderHome.bind(this));
      this.router.get('/api/report.pdf', this.report.bind(this));
  }
  async update(req,res){
    
// --- Ticket obrigatório (inline) ---
{ 
  const _tBody = req && req.body && (req.body.ticket ?? req.body.chamado);
  const _tQuery = req && req.query && (req.query.ticket ?? req.query.chamado);
  const _tHead  = req && req.headers && (req.headers['x-ticket'] ?? req.headers['x-chamado']);
  const _tRaw = _tBody ?? _tQuery ?? _tHead;
  const _t = (_tRaw !== undefined && _tRaw !== null) ? String(_tRaw).trim() : '';
  if (!_t) return res.status(400).json({ ok:false, error: 'Informe o número do chamado (ticket) para continuar.' });
  if (req && req.body && !req.body.ticket) req.body.ticket = _t;
}
// --- fim ticket obrigatório (inline) ---
try{ const n=await this.appsSvc.updateFromRemote(); res.json({ok:true,updated:n}); }
    catch(e){ console.error(e); res.status(500).json({ok:false,error:e.message||String(e)}); }
  }
  async listApps(req,res){
    try{ res.json({items: await this.appsSvc.listAppIds()}); }
    catch(e){ console.error(e); res.status(500).json({error:e.message||String(e)}); }
  }
  async versions(req,res){
    try{ res.json({id:req.params.id, versions: await this.appsSvc.versionsFor(req.params.id)}); }
    catch(e){ console.error(e); res.status(500).json({error:e.message||String(e)}); }
  }

  async overview(req,res){
    try{
      const { envId, password } = req.body || {};
      if(!envId) return res.status(400).json({ ok:false, error:'Informe envId.' });
      if(!password) return res.status(400).json({ ok:false, error:'Informe a senha.' });

      const env = await this.envSvc.getById(Number(envId));
      if(!env) return res.status(404).json({ ok:false, error:'Ambiente não encontrado.' });
      const rawType = ((env && typeof env.env_type === 'string') ? env.env_type : '').trim().toUpperCase();
      const normType = (rawType === 'CLOUD FOUNDRY') ? 'CF' : ((rawType === 'XSA') ? 'XS' : rawType);
      CLI_NAME =  (normType === 'XS') ? 'xs' : 'cf';
      CLI_BIN =  (CLI_NAME === 'xs'
        ? ((process.env.XS_BIN && process.env.XS_BIN.trim()) || 'xs')
        : ((process.env.CF_BIN && process.env.CF_BIN.trim()) || 'cf'));
CLI_NAME =  (CLI_BIN === 'cf') ? 'CF' : 'XS';

      // Normalize API URL (ensure protocol)
      let apiUrl = String((env && env.org_url) || '').trim();
      if (apiUrl) apiUrl = apiUrl.replace(/\/+$/, '');
      if (apiUrl && !/^https?:\/\//i.test(apiUrl)) apiUrl = 'https://' + apiUrl;
      // Force CF if API host indicates Cloud Foundry
      try { if (/\bapi\.cf\./i.test(apiUrl)) { CLI_NAME = 'cf'; CLI_BIN = ((process.env.CF_BIN && process.env.CF_BIN.trim()) || 'cf'); } } catch(_e) {}

      // Build login args for the chosen CLI

  const loginArgs = ['login','-a', apiUrl, '--skip-ssl-validation','-u', env.username,'-p', String(password)];
      if (CLI_NAME === 'cf' && env.origin) loginArgs.push('--origin', String(env.origin));
      if (env.org)   loginArgs.push('-o', ensureCliArgQuoted(env.org));
      if (env.space) loginArgs.push('-s', ensureCliArgQuoted(env.space));

      // Masked debug
      try {
        const maskedUser = (env && env.username) ? String(env.username).replace(/.(?=.{3})/g, '*') : '';
        console.log('[DEBUG][login] cli=', CLI_NAME, ' api=', apiUrl, ' org=', env && env.org, ' space=', env && env.space, ' user=', maskedUser);
      } catch(_){}

      let sLogin = await runCmd(CLI_BIN, loginArgs);
      if (sLogin.code !== 0 && CLI_NAME === 'cf') {
        // Fallback sequence for CF CLI: api -> auth -> target
        let details = [];
        /** 
         * Função (arrow) pushDetail
         * - O que faz: Procedimento/serviço utilizado no fluxo atual.
         * - Retorno: Conforme uso do chamador.
         * @param {{any}} label 
         * @param {{any}} r 
         */
        const pushDetail = (label, r) => {
          try {
            const out = (r && r.stdout ? String(r.stdout) : '').split(/\r?\n/).slice(0,5).join('\n');
            const err = (r && r.stderr ? String(r.stderr) : '').split(/\r?\n/).slice(0,5).join('\n');
            details.push(label + ': code=' + (r && r.code) + '\nstdout:\n' + out + '\nstderr:\n' + err);
          } catch(_){}
        };
        const rApi   = await runCmd(CLI_BIN, ['api', apiUrl, '--skip-ssl-validation']); pushDetail('cf api', rApi);
        const authArgs = ['auth', env.username, String(password)];
        if (env.origin) authArgs.push('--origin', String(env.origin));
        const rAuth  = await runCmd(CLI_BIN, authArgs); pushDetail('cf auth', rAuth);
        const tgtArgs = ['target'];
        if (env.org)   tgtArgs.push('-o', `"${String(env.org).replace(/\"/g,'\\\"')}"`);
        if (env.space) tgtArgs.push('-s', `"${String(env.space).replace(/\"/g,'\\\"')}"`);
        const rTarget = await runCmd(CLI_BIN, tgtArgs); pushDetail('cf target', rTarget);
        if (rApi.code === 0 && rAuth.code === 0 && rTarget.code === 0) {
          sLogin = { code: 0, stdout: (rTarget.stdout||''), stderr: (rTarget.stderr||'') };
        } else {
          const reason = details.join('\n---\n');
          console.error('[DEBUG][login][detail]\n' + reason);
          return res.status(500).json({ ok:false, error: 'Falha no login ' + CLI_NAME.toUpperCase() + '.', detail: reason });
        }
      }

      if (sLogin.code !== 0)
        return res.status(500).json({ ok:false, error: 'Falha no login ' + CLI_NAME.toUpperCase() + '.' });

      const sMtas = await runCmd(CLI_BIN, ['mtas']);
      if (sMtas.code !== 0)
        return res.status(500).json({ ok:false, error: 'Falha em ' + CLI_NAME + ' mtas.' });
      
      const mtasLines = (sMtas.stdout || '').split(/\r?\n/);
// Obter lista de objetos conhecidos
      const ids = await this.appsSvc.listAppIds();
      // Mapear versões do ambiente (via CLI 'mtas')
      const envMap = {};
      for (const id of ids){
        const v = extractClientVersionFromLines(mtasLines, id);
        if (v) envMap[id] = v;
      }
      // Mapa do repositório (base Thomson / available_apps)
      const repoMapDefault = await this.appsSvc.latestRepoVersionMap();

      // === NOVO FLUXO PARA PRODUÇÃO (PRD) ===
      // Se o ambiente selecionado for PRD, comparar HML(installed) x PRD(ambiente)
      let usePrdVsHml = false;
      try {
        const _stage = (env && env.stage ? String(env.stage).toUpperCase() : '');
        if (_stage === 'PRD') usePrdVsHml = true;
      } catch(_e){}

      // Helper para ordenar versões semânticas simples n.n.n
      /** 
       * Função (arrow) _vkey
       * - O que faz: Procedimento/serviço utilizado no fluxo atual.
       * - Retorno: Conforme uso do chamador.
       * @param {{any}} v 
       */
      const _vkey = (v) => String(v||'0').split('.').map(x=>String(x).padStart(3,'0')).join('');

      // Buscar instalado da HML correspondente (mesma empresa), quando aplicável
      
let hmlInstalledBest = null;
if (usePrdVsHml) {
  try {
    // Base name da empresa (remove sufixos de stage do nome do env atual)
    const envName = String(env && env.name || '').trim();
    const rootName = envName
      .replace(/\s*-\s*(PRD|PROD|PRODUCAO|PRODUÇÃO)\s*$/i, '')
      .replace(/\s*-\s*(QAS|HML|HOMOLOGA(?:C|Ç)AO|HOMOLOG(?:ACAO)?)\s*$/i, '')
      .trim();

    // Candidatos de nome para HML
    const candNames = Array.from(new Set([
      rootName,
      `${rootName} - QAS`,
      `${rootName}-QAS`,
      `${rootName} - HML`,
      `${rootName}-HML`
    ].filter(Boolean)));

    // Buscar um ambiente HML/QAS que combine pelo nome
    // Observação: aceita stage variados (HML/QAS/HOMOLOGAÇÃO)
    const stageList = ['HML','QAS','HOMOLOG','HOMOLOGACAO','HOMOLOGAÇÃO'];
    let hmlEnv = null;

    // 1) Tentativa por nome exato e stage
    for (const nm of candNames) {
      const row = await this.envSvc.db.get(
        `SELECT id, name, stage FROM environments 
         WHERE name = ? AND UPPER(stage) IN (${stageList.map(()=>'?').join(',')})
         LIMIT 1`, [nm, ...stageList]
      );
      if (row) { hmlEnv = row; break; }
    }

    // 2) Tentativa por LIKE no início do nome + stage
    if (!hmlEnv && rootName) {
      const row = await this.envSvc.db.get(
        `SELECT id, name, stage FROM environments 
         WHERE name LIKE ? AND UPPER(stage) IN (${stageList.map(()=>'?').join(',')})
         ORDER BY name ASC
         LIMIT 1`, [rootName + '%', ...stageList]
      );
      if (row) hmlEnv = row;
    }

    // Coleta install de HML correspondente
    if (hmlEnv) {
      // Buscar installed por várias chaves possíveis de 'source'
      const sources = Array.from(new Set([
        String(hmlEnv.name||''),
        String(hmlEnv.id||''),
        rootName,
        `${rootName} - QAS`,
        `${rootName}-QAS`,
        `${rootName} - HML`,
        `${rootName}-HML`
      ].filter(Boolean)));

      // Union manual: agrupar resultados de várias queries
      let rows = [];
      for (const srcKey of sources) {
        try {
          const r = await this.appsSvc.db.all(
            `SELECT component, version FROM installed_apps WHERE source = ?`,
            [srcKey]
          );
          if (Array.isArray(r) && r.length) rows = rows.concat(r);
        } catch(_e){}
      }
      // Fallback por LIKE se nada veio
      if (!rows.length && rootName) {
        try {
          const r = await this.appsSvc.db.all(
            `SELECT component, version FROM installed_apps WHERE source LIKE ?`,
            [rootName + '%']
          );
          if (Array.isArray(r) && r.length) rows = rows.concat(r);
        } catch(_e){}
      }

      // Consolidar "melhor" versão por componente
      const best = {};
      /** 
       * Função (arrow) _vkey
       * - O que faz: Procedimento/serviço utilizado no fluxo atual.
       * - Retorno: Conforme uso do chamador.
       * @param {{any}} v 
       */
      const _vkey = (v) => String(v||'0').split('.').map(x=>String(x).padStart(3,'0')).join('');
      for (const r of rows) {
        if (!r || !r.component) continue;
        const comp = String(r.component).trim().toLowerCase();
        const ver  = String(r.version||'').trim().replace(/^v/i,'');
        if (!ver) continue;
        if (!best[comp] || _vkey(ver) > _vkey(best[comp])) best[comp] = ver;
      }
      hmlInstalledBest = best;
    }
  } catch(_e){ hmlInstalledBest = null; }
}
const items = ids.map(id => {
        if (usePrdVsHml) {
          // Versão (ambiente) := HML instalada; Versão (repositório) := PRD atual
          const prevV = hmlInstalledBest ? (hmlInstalledBest[String(id).toLowerCase()] || null) : null;
          const repoV = envMap[id] || null;
          return { id, prev_version: prevV || null, repo_version: repoV || null };
        }
        // Fluxo padrão (HML): ambiente atual vs repo Thomson
        return {
          id,
          prev_version: envMap[id] || null,
          repo_version: repoMapDefault[id] || null
        };
      });

      /* sync installed from overview */
      try{
        for (const it of items){
          if (it && it.prev_version){
            await this.appsSvc.upsertInstalled(env, it.id, it.prev_version);
          }
        }
      }catch(_e){ try{ console.error('[installed_apps] overview sync error', _e && _e.message || _e); }catch(_){} }

      res.json({ ok:true, items });
    }catch(e){
      res.status(500).json({ ok:false, error: e.message || String(e) });
    }
  }

  async objectEnvStatus(req,res){
    try{
      const { envId, objectId, password } = req.body || {};
      if(!envId || !objectId) return res.status(400).json({ ok:false, error:'Parâmetros insuficientes (envId e objectId).' });
      if(!password || String(password).length===0) return res.status(400).json({ ok:false, error:'Informe a senha do usuário do ambiente.' });

      const env = await this.envSvc.getById(Number(envId));
      if(!env) return res.status(404).json({ ok:false, error:'Ambiente não encontrado.' });
      if(!env.org_url) return res.status(400).json({ ok:false, error:'Ambiente sem URL configurada (org_url).' });
      if(!env.username) return res.status(400).json({ ok:false, error:'Ambiente sem usuário configurado.' });

      const XS_BIN = process.env.XS_BIN && process.env.XS_BIN.trim() ? process.env.XS_BIN.trim() : 'xs';

      const rawType = ((env && typeof env.env_type === 'string') ? env.env_type : '').trim().toUpperCase();
      const normType = (rawType === 'CLOUD FOUNDRY') ? 'CF' : ((rawType === 'XSA') ? 'XS' : rawType);
      CLI_NAME =  (normType === 'XS') ? 'xs' : 'cf';
      CLI_BIN =  (CLI_NAME === 'xs'
        ? ((process.env.XS_BIN && process.env.XS_BIN.trim()) || 'xs')
        : ((process.env.CF_BIN && process.env.CF_BIN.trim()) || 'cf'));
CLI_NAME =  (CLI_BIN === 'cf') ? 'CF' : 'XS';

  const loginArgs = ['login', '-a', env.org_url, '--skip-ssl-validation', '-u', env.username, '-p', String(password)];
      if (env.org)   { loginArgs.push('-o', ensureCliArgQuoted(env.org)); }
      if (env.space) { loginArgs.push('-s', ensureCliArgQuoted(env.space)); }

      const sLogin = await runCmd(CLI_BIN, loginArgs);
      if (sLogin.code !== 0) {
        return res.status(500).json({ ok:false, error:'Falha ao executar login do ambiente.' });
      }

      const s3 = await runCmd(CLI_BIN, ['mtas']);
      if (s3.code !== 0) {
        return res.status(500).json({ ok:false, error:'Falha ao executar listagem de MTAs.' });
      }
      const linesAll = (s3.stdout || '').split(/\r?\n/);

      const clientVersion = extractClientVersionFromLines(linesAll, objectId);

      // Auditoria adicional
      let xsCliVersion = '';
      const v = await runCmd(XS_BIN, ['--version']);
      if (v.code === 0) {
        xsCliVersion = (v.stdout || '').split(/\r?\n/).filter(Boolean)[0] || (v.stdout || '').trim();
      }
      const repoVersion = await this.appsSvc.latestVersionFor(objectId);
      const executorUser = (req.session && req.session.user && req.session.user.username) ? req.session.user.username : null;

      await this.appsSvc.db.run(
        `INSERT INTO object_version_audit
         (ts, env_id, company_name, origem, org_url, org, space, username,
          object_id, repo_version, client_version, xs_cli_version, raw_mtas, executor_user)
         VALUES (datetime('now','localtime'),?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [
          env.id, env.name || null, env.origem || null, env.org_url || null,
          env.org || null, env.space || null, env.username || null,
          objectId, repoVersion || null, clientVersion || null, xsCliVersion || null,
          (s3.stdout || '').slice(0, 200000),
          executorUser
        ]
      );

      res.json({ ok:true, clientVersion });
    }catch(e){
      res.status(500).json({ ok:false, error: e.message || String(e) });
    }
  }

  async deployStart(req,res){
    // Início do fluxo de deploy: aqui vamos identificar o ambiente e,
    // se for PRD, descobrir a versão instalada na Homologação para amarrar no token.
    try {
      const { envId, objectId, password, ticket, packageSource } = req.body || {};
      if (!envId || !objectId || !password) {
        return res.status(400).json({ ok:false, error: 'Parâmetros insuficientes' });
      }
      if (!req.session?.user) {
        return res.status(401).json({ ok:false, error: 'Unauthorized' });
      }

      const env = await this.envSvc.getById(Number(envId));
      if (!env) {
        return res.status(404).json({ ok:false, error: 'Ambiente não encontrado.' });
      }

      // valores que vão no token
      let __forceVersionFromHml = false;
      let __hmlVersionForObject = null;

      // Se o ambiente selecionado é PRD, precisamos buscar a versão na HML correspondente
      const stage = (env && env.stage ? String(env.stage).toUpperCase() : '');
      if (stage === 'PRD') {
        __forceVersionFromHml = true;

        const envName = String(env.name || '').trim();
        const rootName = envName
          .replace(/\s*-\s*(PRD|PROD|PRODUCAO|PRODUÇÃO)\s*$/i, '')
          .trim();

        const stageList = ['HML','HOMOLOG','HOMOLOGACAO','HOMOLOGAÇÃO'];
        const candNames = Array.from(new Set([
          rootName,
          `${rootName} - HML`, `${rootName}-HML`,
          `${rootName} - HOMOLOG`, `${rootName}-HOMOLOG`
        ].filter(Boolean)));

        let hmlEnv = null;
        // 1) tenta nomes exatos
        for (const nm of candNames) {
          const row = await this.envSvc.db.get(
            `SELECT id, name, stage FROM environments
             WHERE name = ? AND UPPER(stage) IN (${stageList.map(()=>'?').join(',')})
             LIMIT 1`,
            [nm, ...stageList]
          );
          if (row) { hmlEnv = row; break; }
        }
        // 2) tenta LIKE
        if (!hmlEnv && rootName) {
          const row = await this.envSvc.db.get(
            `SELECT id, name, stage FROM environments
             WHERE name LIKE ? AND UPPER(stage) IN (${stageList.map(()=>'?').join(',')})
             ORDER BY name ASC
             LIMIT 1`,
            [rootName + '%', ...stageList]
          );
          if (row) hmlEnv = row;
        }
        // 3) Se achou HML, procura a versão instalada do objeto lá
        if (hmlEnv) {
          const compKey = String(objectId || '').trim().toLowerCase();
          let found = null;
          const sources = Array.from(new Set([
            String(hmlEnv.name || ''),
            String(hmlEnv.id || ''),
            rootName,
            `${rootName} - HML`, `${rootName}-HML`
          ].filter(Boolean)));

          for (const k of sources) {
            const r = await this.appsSvc.db.get(
              `SELECT version FROM installed_apps
               WHERE LOWER(component) = ? AND source = ?
               ORDER BY datetime(installed_at) DESC LIMIT 1`,
              [compKey, String(k)]
            );
            if (r && r.version) {
              found = String(r.version).trim();
              break;
            }
          }
          if (found) {
            __hmlVersionForObject = found;
          }
        }
      }

      // --- Ticket obrigatório (mantido) ---
      {
        const _tBody = req && req.body && (req.body.ticket ?? req.body.chamado);
        const _tQuery = req && req.query && (req.query.ticket ?? req.query.chamado);
        const _tHead  = req && req.headers && (req.headers['x-ticket'] ?? req.headers['x-chamado']);
        const _tRaw = _tBody ?? _tQuery ?? _tHead;
        const _t = (_tRaw !== undefined && _tRaw !== null) ? String(_tRaw).trim() : '';
        if (!_t) return res.status(400).json({ ok:false, error: 'Informe o número do chamado (ticket) para continuar.' });
        if (req && req.body && !req.body.ticket) req.body.ticket = _t;
      }
      // --- fim ticket obrigatório ---

      const t = uuidv4();
      this.deployTokens.set(t, {
        envId: Number(envId),
        objectId: String(objectId),
        password: String(password),
        user: req.session.user.username,
        ticket: (ticket == null ? null : String(ticket)),
        packageSource: (String(packageSource||'normal').toLowerCase()==='unshipped' ? 'unshipped' : 'normal'),
        forceVersionFromHml: __forceVersionFromHml,
        hmlVersionForObject: __hmlVersionForObject,
        created: Date.now()
      });
      // limpa tokens antigos
      for (const [k,v] of this.deployTokens.entries()) {
        if (Date.now() - (v.created || 0) > 10*60*1000) this.deployTokens.delete(k);
      }

      return res.json({ ok:true, token: t });

    } catch (e) {
      return res.status(500).json({ ok:false, error: e.message || String(e) });
    }
  }
async deployStream(req,res){
  const token = String(req.query.token||'');
  const info = this.deployTokens.get(token);
  if (!info) {
    res.status(400).send('token inválido');
    return;
  }
  this.deployTokens.delete(token);

  res.writeHead(200, {
    'Content-Type':'text/event-stream',
    'Cache-Control':'no-cache',
    'Connection':'keep-alive',
    'X-Accel-Buffering':'no'
  });

  let __deployLogBuf = '';
  const __appendDeployLog = (line) => {
    if (line == null) return;
    try {
      const s = String(line);
      __deployLogBuf += s + '\n';
      if (__deployLogBuf.length > 300000) {
        __deployLogBuf = __deployLogBuf.slice(-300000);
      }
    } catch (_) {}
  };

  const send = (line) => {
    __appendDeployLog(line);
    try{
      res.write('data: ' + String(line).replace(/\n/g,'\\n') + '\n\n');
    }catch(_){}
  };
  const sendDone = (payload) => {
    try{
      res.write('event: done\n');
      res.write('data: ' + JSON.stringify(payload) + '\n\n');
    }catch(_){}
  };
  const { envId, objectId, password, user, ticket, forceVersionFromHml, hmlVersionForObject } = info;

  try {
    // 1) Buscar ambiente
    const env = await this.envSvc.getById(envId);
    if (!env) {
      send('Ambiente não encontrado.');
      sendDone({ ok:false });
      return res.end();
    }
    if (!env.org_url) {
      send('Ambiente sem org_url.');
      sendDone({ ok:false });
      return res.end();
    }
    if (!env.username) {
      send('Ambiente sem usuário.');
      sendDone({ ok:false });
      return res.end();
    }

    // 2) Definir CLI
    const rawType = (env && typeof env.env_type === 'string' ? env.env_type : '').trim().toUpperCase();
    const normType = (rawType === 'CLOUD FOUNDRY') ? 'CF' : ((rawType === 'XSA') ? 'XS' : rawType);
    let CLI_BIN = (normType === 'XS')
      ? ((process.env.XS_BIN && process.env.XS_BIN.trim()) || 'xs')
      : ((process.env.CF_BIN && process.env.CF_BIN.trim()) || 'cf');

    // Se a URL apontar para Cloud Foundry (api.cf.*), força uso do cf
    if (env && typeof env.org_url === 'string' && /\bapi\.cf\./i.test(env.org_url)) {
      CLI_BIN = ((process.env.CF_BIN && process.env.CF_BIN.trim()) || 'cf');
    }

    // 3) Login
    const loginArgs = ['login','-a',env.org_url,'--skip-ssl-validation','-u',env.username,'-p',String(password)];
    const _quoteIfNeeded = (v) => {
      return ensureCliArgQuoted(v);
    };
    if (env.org)   loginArgs.push('-o', _quoteIfNeeded(env.org));
    if (env.space) loginArgs.push('-s', _quoteIfNeeded(env.space));
    send('> ' + CLI_BIN + ' ' + loginArgs.join(' '));
    const sLogin = await runCmd(CLI_BIN, loginArgs);
    if (sLogin.code !== 0) {
      send((sLogin.stderr || sLogin.stdout || 'Falha no login').slice(0,2000));
      sendDone({ ok:false });
      return res.end();
    }

    // 4) Descobrir versão a usar
    let repoVersion = null;

    // 4.a) Se o token já trouxe a versão da HML, usa direto
    if (info.forceVersionFromHml && info.hmlVersionForObject) {
      repoVersion = String(info.hmlVersionForObject).trim();
      send('Produção: usando versão da Homologação já resolvida: ' + repoVersion);
    } else {
      // 4.b) Senão aplica a regra de origem
      const origem = (env && env.origem ? String(env.origem).toUpperCase() : '');
      if (origem === 'QAS') {
        // achar HML da mesma empresa
        const envName = String(env.name || '');
        const rootName = envName          .replace(/\s*-\s*(PRD|PROD|PRODUCAO|PRODUÇÃO)\s*$/i, '')          .replace(/\s*-\s*(QAS|HML|HOMOLOGA(?:C|Ç)AO|HOMOLOG(?:ACAO)?)\s*$/i, '')          .trim();

        const stageList = ['HML','HOMOLOG','HOMOLOGACAO','HOMOLOGAÇÃO'];
        const candNames = Array.from(new Set([
          rootName,
          `${rootName} - HML`, `${rootName}-HML`,
          `${rootName} - HOMOLOG`, `${rootName}-HOMOLOG`
        ].filter(Boolean)));

        let hmlEnv = null;
        for (const nm of candNames) {
          const row = await this.envSvc.db.get(
            `SELECT id, name, stage FROM environments
             WHERE name = ? AND UPPER(stage) IN (${stageList.map(()=>'?').join(',')})
             LIMIT 1`,
            [nm, ...stageList]
          );
          if (row) { hmlEnv = row; break; }
        }
        if (!hmlEnv && rootName) {
          const row = await this.envSvc.db.get(
            `SELECT id, name, stage FROM environments
             WHERE name LIKE ? AND UPPER(stage) IN (${stageList.map(()=>'?').join(',')})
             ORDER BY name ASC
             LIMIT 1`,
            [rootName + '%', ...stageList]
          );
          if (row) hmlEnv = row;
        }

        if (!hmlEnv) {
          send('Não foi possível localizar a Homologação correspondente para buscar a versão.');
          sendDone({ ok:false });
          return res.end();
        }

        // buscar versão instalada na HML
        const compKey = String(objectId || '').trim().toLowerCase();
        let found = null;
        const sources = Array.from(new Set([
          String(hmlEnv.name||''),
          String(hmlEnv.id||''),
          rootName,
          `${rootName} - HML`, `${rootName}-HML`
        ].filter(Boolean)));

        for (const k of sources) {
          const r = await this.envSvc.db.get(
            `SELECT version FROM installed_apps
             WHERE LOWER(component) = ? AND source = ?
             ORDER BY datetime(installed_at) DESC LIMIT 1`,
            [compKey, String(k)]
          );
          if (r && r.version) { found = String(r.version).trim(); break; }
        }

        if (!found) {
          send('Não encontrei versão instalada em Homologação para este componente. Operação cancelada.');
          sendDone({ ok:false });
          return res.end();
        }

        repoVersion = found;
        send('Origem=QAS (Produção): será aplicada a MESMA versão de Homologação: ' + repoVersion);
      } else {
        // homologação normal
        repoVersion = await this.appsSvc.latestVersionFor(objectId);
        send('Origem=TR (Homologação): última versão do repositório: ' + repoVersion);
      }
    }

    if (!repoVersion) {
      send('Não encontrei versão do objeto para continuar.');
      sendDone({ ok:false });
      return res.end();
    }

    // 5) Baixar MTAR (com cache local: mtars/ e mtars_old/)
    const path = require('path');
// Banco de dados: use caminho absoluto no diretório do projeto para não “perder” cadastros ao iniciar de outra pasta
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'apps.db');

    const fs = require('fs');
    const { spawn } = require('child_process');
    const axios = require('axios');

    // Dica de tipo de ambiente para a resolução de URL (CF vs XS)
    const __isCF = (function(){ 
      try { 
        const t = String(env && env.env_type || '').toUpperCase();
        if (t.includes('CLOUD FOUNDRY') || t === 'CF') return true;
        if (typeof CLI_BIN === 'string' && CLI_BIN.toLowerCase() === 'cf') return true;
        if (String(env && env.org_url || '').toLowerCase().includes('api.cf.')) return true;
        return false;
      } catch(__e){ 
        return false; 
      } 
    })();
    try{ this.appsSvc.envTypeHint = (__isCF ? 'CF' : 'XS'); }catch(_e){}

    // Pastas de MTAR
    const mtarsDir    = path.join(__dirname, 'mtars');
    const mtarsOldDir = path.join(__dirname, 'mtars_old');
    if (!fs.existsSync(mtarsDir)) fs.mkdirSync(mtarsDir, { recursive: true });

    // Nome padrão do arquivo (mesmo padrão usado no rollback)
    const outFile    = path.join(mtarsDir, `${objectId}-${repoVersion}.mtar`);
    const oldOutFile = path.join(mtarsOldDir, `${objectId}-${repoVersion}.mtar`);

    // Se já existir localmente (mtars/ ou mtars_old/), não baixa novamente
    let mtarFileToDeploy = null;
    if (fs.existsSync(outFile)) {
      mtarFileToDeploy = outFile;
      send('MTAR já existe em cache (mtars). Não será baixado novamente.');
      send('Arquivo local: ' + mtarFileToDeploy);
    } else if (fs.existsSync(oldOutFile)) {
      mtarFileToDeploy = oldOutFile;
      send('MTAR já existe em cache (mtars_old). Não será baixado novamente.');
      send('Arquivo local: ' + mtarFileToDeploy);
    } else {
      const url = await this.appsSvc.resolveMtarUrl(objectId, repoVersion, { preferredFolder: (info && info.packageSource) ? info.packageSource : 'normal' }, (t)=>send(t));
      send('Baixando MTAR: ' + url);

      const response = await axios.get(url, { responseType: 'stream', timeout: 600000 });
      await new Promise((ok, bad)=>{
        const writer = fs.createWriteStream(outFile);
        response.data.pipe(writer);
        writer.on('finish', ok);
        writer.on('error', bad);
      });
      mtarFileToDeploy = outFile;
      send('Arquivo salvo em: ' + outFile);
    }

// 6) Deploy
send('Iniciando deploy...');

const __mta = withMtaUploadTweaks(
  mtarFileToDeploy,
  ['deploy', ensureCliArgQuoted(mtarFileToDeploy), '-f'],
  process.env
);

// Workaround for large MTAR uploads on XS:
// If we detect "Error occured during communication with HTTP server", retry the whole deploy a few times.
// (XS CLI itself sometimes retries, but a full restart of the operation can still help on flaky links/proxies.)
const __isCFDeploy = (String((process.env && (process.env.env_type || process.env.type)) || '').toLowerCase().includes('cf')
  || String((process.env && process.env.org_url) || '').includes('api.cf.')
  || String(CLI_BIN || '').toLowerCase() === 'cf');

const maxRetries = Number(process.env.XS_DEPLOY_HTTP_RETRIES || 3);
const retryDelaySec = Number(process.env.XS_DEPLOY_HTTP_RETRY_DELAY_SEC || 10);

const runDeploy = (attempt) => {
  let sawHttpCommError = false;

  const child = spawn(CLI_BIN, __mta.args, { shell:true, env: __mta.env });

  child.stdout.on('data', d => {
    const t = d.toString();
    send(t);
  });

  child.stderr.on('data', d => {
    const t = d.toString();
    if (!__isCFDeploy && /Error\s+occured\s+during\s+communication\s+with\s+HTTP\s+server/i.test(t)) {
      sawHttpCommError = true;
    }
    send(t);
  });

  child.on('close', async code => {
    // If this is XS, and we saw the HTTP communication error, retry a few times.
    if (!__isCFDeploy && sawHttpCommError && attempt < maxRetries) {
      send(`WARN    Comunicação HTTP instável durante o upload. Tentando novamente em ${retryDelaySec} segundos... (tentativa ${attempt + 1}/${maxRetries})`);
      setTimeout(() => runDeploy(attempt + 1), Math.max(1, retryDelaySec) * 1000);
      return;
    }

    const ok = (code === 0);
    const status = ok ? 'success' : 'error';
    try {
      const userName = user || (req.session && req.session.user && req.session.user.username) || null;

      // Derivar empresa e ambiente para auditoria
      let __empresa = (env && (env.name || env.company_name || env.org))
        ? String(env.name || env.company_name || env.org).trim()
        : '';
      let __ambiente = (env && (env.space || env.environment || env.env || env.ambiente))
        ? String(env.space || env.environment || env.env || env.ambiente).trim()
        : '';
      if (!__ambiente && __empresa) {
        const __m = __empresa.match(/\s+(DEV|QAS|PRD|HML|PROD|PRODUCAO|HOMOLOG|PPRD|QA|TEST|STG)$/i);
        if (__m) {
          __ambiente = __m[1].toUpperCase();
        }
      }

      // Descobrir versão anterior instalada (prev_version)
      let prevVersion = null;
      try {
        const compKey = String(objectId || '').trim().toLowerCase();
        const src = env && (env.name ? String(env.name) : (env.id != null ? String(env.id) : ''));
        if (compKey && src) {
          const rowPrev = await this.appsSvc.db.get(
            `SELECT version FROM installed_apps WHERE source=? AND component=? ORDER BY datetime(installed_at) DESC LIMIT 1`,
            [src, compKey]
          );
          if (rowPrev && rowPrev.version) {
            prevVersion = String(rowPrev.version).trim();
          }
        }
      } catch (_) {}

      // Gravar auditoria de deploy
      try {
        await this.__auditInsert(req, {
          env_id: (env && env.id) || envId || null,
          company_name: __empresa || (env && env.company_name) || null,
          org: (env && env.org) || null,
          space: (env && env.space) || null,
          object_id: objectId,
          prev_version: prevVersion,
          new_version: repoVersion,
          executor_user: userName,
          ticket: (ticket == null ? null : String(ticket)),
          status,
          log_text: __deployLogBuf
        });
      } catch (_) {}

      // Atualizar tabela installed_apps somente em caso de sucesso
      if (ok) {
        try {
          await this.appsSvc.upsertInstalled(env, objectId, repoVersion);
        } catch (_) {}
      }
    } catch (_) {}

    sendDone({ ok });
    return res.end();
  });
};

runDeploy(0);

  } catch (e) {
    const _msg = 'Erro no deploy: ' + (e && e.message ? e.message : String(e));
    send(_msg);
    sendDone({ ok:false, error: (e && e.message) ? e.message : String(e) });
    return res.end();
  }
}
async rollbackLive(req,res){

// --- Ticket obrigatório (inline) ---
{ 
  const _tBody = req && req.body && (req.body.ticket ?? req.body.chamado);
  const _tQuery = req && req.query && (req.query.ticket ?? req.query.chamado);
  const _tHead  = req && req.headers && (req.headers['x-ticket'] ?? req.headers['x-chamado']);
  const _tRaw = _tBody ?? _tQuery ?? _tHead;
  const _t = (_tRaw !== undefined && _tRaw !== null) ? String(_tRaw).trim() : '';
  if (!_t) return res.status(400).json({ ok:false, error: 'Informe o número do chamado (ticket) para continuar.' });
  if (req && req.body && !req.body.ticket) req.body.ticket = _t;
}
// --- fim ticket obrigatório (inline) ---

    try{
      const envId = Number((req.method === 'GET' ? req.query.env_id : req.body.env_id) || 0);
      const objectId = String((req.method === 'GET' ? req.query.component_id : req.body.component_id) || '').trim();
      const password = String((req.method === 'GET' ? (req.query.password||'') : (req.body.password||''))).trim();

      if(!envId || !objectId){
        return res.status(400).type('text/plain').send('Parâmetros inválidos. Informe env_id e component_id.');
      }

      if(!password){
        res.type('html').send(`<!DOCTYPE html><html lang="pt-br"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Rollback - ${objectId}</title>
<style>body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;padding:20px}input,button{font-size:14px;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px}button{cursor:pointer}form{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.login-wrap{display:flex;flex-direction:column;align-items:center;justify-content:center}
.login-wrap .after-card-note{margin-top:8px}
</style>

</head><body>
<h3>Rollback do componente: <code>${objectId}</code></h3>
<form method="POST" action="/api/rollback/live">
  <input type="hidden" name="env_id" value="${envId}"/>
  <input type="hidden" name="component_id" value="${objectId}"/>
  <label>Senha do usuário do ambiente:</label>
  <input name="password" type="password" autocomplete="current-password" required/>
  <button type="submit">Iniciar rollback</button>
</form>
<p style="color:#4b5563">Será utilizada a última <em>prev_version</em> registrada em <code>deploy_audit</code> para este componente e ambiente.</p>
<!-- BEGIN Utilities (customAlert, toast, theme) -->
<div class="toast-container" id="toastContainer"></div>
<dialog id="customAlert" style="border:1px solid #9ca3af;border-radius:8px;padding:18px;max-width:520px;box-shadow:0 2px 10px rgba(0,0,0,.12)">
  <h3 style="margin:0 0 8px;font-size:16px">TAXONE FOR SAP Solutions diz:</h3>
  <div id="customAlertMsg" style="font-size:14px;line-height:1.4"></div>
  <div style="text-align:right;margin-top:14px">
    <button id="customAlertOk" class="btn">OK</button>
  </div>
</dialog>
<script>
(function(){
  
  /** 
   * Função ensureAlert
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem ensureAlert.
   * - Retorno: Valor compatível com o uso corrente.

   */
  function ensureAlert(){
    var dlg=document.getElementById('customAlert');
    if(!dlg){
      dlg=document.createElement('dialog'); dlg.id='customAlert';
      dlg.innerHTML='<h3>TAXONE FOR SAP Solutions diz:</h3><div id="customAlertMsg"></div><div style="text-align:right;margin-top:12px"><button id="customAlertOk" class="btn">OK</button></div>';
      document.body.appendChild(dlg);
    }
    var ok=document.getElementById('customAlertOk');
    if(ok){ ok.onclick=function(){ if(dlg.close) dlg.close(); else dlg.style.display='none'; }; }
    return dlg;
  }
  window.customAlert = function(msg){
    var dlg=ensureAlert();
    var box=document.getElementById('customAlertMsg'); if(box) box.textContent=(msg==null?'':String(msg));
    if(dlg.showModal) dlg.showModal(); else dlg.style.display='block';
  };
  window.toast = function(msg, type){
    var wrap=document.getElementById('toastContainer'); if(!wrap){ wrap=document.createElement('div'); wrap.id='toastContainer'; wrap.className='toast-container'; document.body.appendChild(wrap); }
    var t=document.createElement('div'); t.className='toast ' + (type||'info'); t.textContent=String(msg||''); wrap.appendChild(t);
    setTimeout(function(){ t.style.opacity='0'; setTimeout(function(){ t.remove(); }, 320); }, 3200);
  };
  
})();
</script>
<!-- END Utilities -->
<!-- BEGIN: Password Prompt -->
<dialog id="customPwdDialog" style="border:1px solid #9ca3af;border-radius:8px;padding:18px;max-width:520px;box-shadow:0 2px 10px rgba(0,0,0,.12)">
  <h3 style="margin:0 0 8px;font-size:16px">TAXONE FOR SAP Solutions diz:</h3>
  <div class="muted" id="customPwdMsg" style="margin-bottom:8px;font-size:14px;line-height:1.4"></div>
  <input id="customPwdInput" type="password" style="width:100%;-webkit-text-security:disc;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px">
  <div style="text-align:right;margin-top:12px;display:flex;gap:8px;justify-content:flex-end">
    <button id="customPwdCancel" class="btn">Cancelar</button>
    <button id="customPwdOk" class="btn">OK</button>
  </div>
</dialog>
<script>
(function(){
  window.customPasswordPrompt = function(message){
    return new Promise(function(resolve){
      var dlg = document.getElementById('customPwdDialog');
      if(!dlg){
        dlg = document.createElement('dialog');
        dlg.id = 'customPwdDialog';
        dlg.innerHTML = '<h3>TAXONE FOR SAP Solutions diz:</h3>' +
                        '<div id="customPwdMsg" class="muted" style="margin-bottom:8px"></div>' +
                        '<input id="customPwdInput" type="password" style="-webkit-text-security:disc;width:100%;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px">' +
                        '<div style="text-align:right;margin-top:12px"><button id="customPwdCancel" class="btn">Cancelar</button> <button id="customPwdOk" class="btn">OK</button></div>';
        document.body.appendChild(dlg);
      }
      var msg = document.getElementById('customPwdMsg');
      if(msg){ msg.textContent = message || 'Informe a senha:'; }
      var input = document.getElementById('customPwdInput');
      if(input){ input.value=''; input.setAttribute('type','password'); input.style.webkitTextSecurity='disc'; }
      /** 
       * Função onCancel
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onCancel.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onCancel(){ try{ dlg.close(); }catch(_){} cleanup(); resolve(null); }
      /** 
       * Função onOk
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onOk.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onOk(){ var v=input?input.value:''; try{ dlg.close(); }catch(_){} cleanup(); resolve(v); }
      /** 
       * Função onKey
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onKey.
       * - Retorno: Valor compatível com o uso corrente.
       * @param {{any}} e 
       */
      function onKey(e){ if(e.key==='Enter'){ e.preventDefault(); onOk(); } }
      /** 
       * Função cleanup
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem cleanup.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function cleanup(){
        try {
          document.getElementById('customPwdOk')?.removeEventListener('click', onOk);
          document.getElementById('customPwdCancel')?.removeEventListener('click', onCancel);
          input?.removeEventListener('keydown', onKey);
        } catch(_){}
      }
      document.getElementById('customPwdOk')?.addEventListener('click', onOk);
      document.getElementById('customPwdCancel')?.addEventListener('click', onCancel);
      input?.addEventListener('keydown', onKey);
      try{ input?.focus(); }catch(_){}
      if(dlg.showModal){ dlg.showModal(); } else { dlg.style.display='block'; }
    });
  };
})();
</script>
<!-- END: Password Prompt -->
<!-- BEGIN: Ticket Prompt -->
<dialog id="customTicketDialog" style="border:1px solid #9ca3af;border-radius:8px;padding:18px;max-width:520px;box-shadow:0 2px 10px rgba(0,0,0,.12)">
  <h3 style="margin:0 0 8px;font-size:16px">TAXONE FOR SAP Solutions diz:</h3>
  <div class="muted" id="customTicketMsg" style="margin-bottom:8px;font-size:14px;line-height:1.4"></div>
  <input id="customTicketInput" type="text" style="width:100%;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px" placeholder="Número do chamado (ticket)">
  <div style="text-align:right;margin-top:12px;display:flex;gap:8px;justify-content:flex-end">
    <button id="customTicketCancel" class="btn">Cancelar</button>
    <button id="customTicketOk" class="btn">OK</button>
  </div>
</dialog>
<script>
(function(){
  window.customTicketPrompt = function(message){
    return new Promise(function(resolve){
      var dlg = document.getElementById('customTicketDialog');
      if(!dlg){
        dlg = document.createElement('dialog');
        dlg.id = 'customTicketDialog';
        dlg.innerHTML = '<h3>TAXONE FOR SAP Solutions diz:</h3>' +
                        '<div id="customTicketMsg" class="muted" style="margin-bottom:8px"></div>' +
                        '<input id="customTicketInput" type="text" style="width:100%;padding:8px 10px;border:1px solid #9ca3af;border-radius:10px" placeholder="Número do chamado (ticket)">' +
                        '<div style="text-align:right;margin-top:12px"><button id="customTicketCancel" class="btn">Cancelar</button> <button id="customTicketOk" class="btn">OK</button></div>';
        document.body.appendChild(dlg);
      }
      var msg = document.getElementById('customTicketMsg');
      if(msg){ msg.textContent = message || 'Informe o número do chamado (ticket):'; }
      var input = document.getElementById('customTicketInput');
      if(input){ input.value=''; }
      /** 
       * Função onCancel
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onCancel.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onCancel(){ try{ dlg.close(); }catch(_){} cleanup(); resolve(null); }
      /** 
       * Função onOk
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onOk.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function onOk(){ var v=input?String(input.value||'').trim():''; try{ dlg.close(); }catch(_){} cleanup(); resolve(v); }
      /** 
       * Função onKey
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem onKey.
       * - Retorno: Valor compatível com o uso corrente.
       * @param {{any}} e 
       */
      function onKey(e){ if(e.key==='Enter'){ e.preventDefault(); onOk(); } }
      /** 
       * Função cleanup
       * - O que faz: Encapsula uma operação específica do domínio.
       * - Quando chamada: Em fluxos que exigem cleanup.
       * - Retorno: Valor compatível com o uso corrente.

       */
      function cleanup(){
        try {
          document.getElementById('customTicketOk')?.removeEventListener('click', onOk);
          document.getElementById('customTicketCancel')?.removeEventListener('click', onCancel);
          input?.removeEventListener('keydown', onKey);
        } catch(_){}
      }
      document.getElementById('customTicketOk')?.addEventListener('click', onOk);
      document.getElementById('customTicketCancel')?.addEventListener('click', onCancel);
      input?.addEventListener('keydown', onKey);
      try{ input?.focus(); }catch(_){}
      if(dlg.showModal){ dlg.showModal(); } else { dlg.style.display='block'; }
    });
  };
})();
</script>
<!-- END: Ticket Prompt -->

<footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b></b>
<footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b></b>
</footer>
<footer style="position:fixed; bottom:0; left:0; right:0; background:#f1f1f1; border-top:1px solid #ccc; text-align:center; padding:8px; font-size:13px; color:#555; font-family: Calibri, 'Segoe UI', Roboto, Arial, sans-serif;">
  <b>Desenvolvido por AMS Sustentação - Alliance Consultoria V3.0</b>
</footer>
</body></html>`);
        return;
      }

      res.writeHead(200, {'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-cache','Connection':'keep-alive'});
      /** 
       * Função (arrow) write
       * - O que faz: Procedimento/serviço utilizado no fluxo atual.
       * - Retorno: Conforme uso do chamador.
       * @param {{any}} t 
       */
      const write = (t)=>{ try{ res.write(String(t).replace(/\\x1b\\[[0-9;]*m/g,'') + "\\n"); }catch(_){}};

      const env = await this.envSvc.getById(envId);
      if(!env){ write('Ambiente não encontrado.'); return res.end(); }
      if(!env.org_url || !env.username){ write('Ambiente sem URL/usuário configurado.'); return res.end(); }

      const row = await this.appsSvc.db.get(
        `SELECT id, prev_version, new_version, ts FROM deploy_audit
           WHERE env_id = ? AND object_id = ?
         ORDER BY id DESC LIMIT 1`, [envId, objectId]
      );
      if(!row || !row.prev_version){
        write('Não há prev_version registrada em deploy_audit para este componente/ambiente.');
        return res.end();
      }
      const targetVersion = row.prev_version;
      write('Versão alvo (prev_version): ' + targetVersion);

      
      const nodemailer = require('nodemailer');
      /** 
       * Função (arrow) runSpawn
       * - O que faz: Procedimento/serviço utilizado no fluxo atual.
       * - Retorno: Conforme uso do chamador.
       * @param {{any}} cmd 
       * @param {{any}} args=[] 
       * @param {{any}} opts={} 
       */
      const runSpawn = (cmd, args=[], opts={})=> new Promise((resolve)=>{
        const child = spawn(cmd, args, { shell:true, env: (opts && opts.env) ? opts.env : process.env, ...opts });
        child.stdout.on('data', d=> write(String(d).trimEnd()));
        child.stderr.on('data', d=> write(String(d).trimEnd()));
        child.on('close', code => resolve(code));
      });

    
      // Ensure CLI_NAME/CLI_BIN are defined (outside of any early-return blocks)
      if (typeof CLI_BIN === 'undefined') {
        const rawType2 = ((env && typeof env.env_type === 'string') ? env.env_type : '').trim().toUpperCase();
        const normType2 = (rawType2 === 'CLOUD FOUNDRY') ? 'CF' : ((rawType2 === 'XSA') ? 'XS' : rawType2);
        var CLI_NAME = (normType2 === 'XS') ? 'xs' : 'cf';
        var CLI_BIN  = (CLI_NAME === 'xs'
          ? ((process.env.XS_BIN && process.env.XS_BIN.trim()) || 'xs')
          : ((process.env.CF_BIN && process.env.CF_BIN.trim()) || 'cf'));
      }

  const loginArgs = ['login','-a',env.org_url,'--skip-ssl-validation','-u',env.username,'-p',String(password)];
      if(env.org) loginArgs.push('-o', ensureCliArgQuoted(env.org));
      if(env.space) loginArgs.push('-s', ensureCliArgQuoted(env.space));
      write('> xs ' + loginArgs.join(' '));
      const loginCode = await runSpawn(CLI_BIN, loginArgs);
      if(loginCode !== 0){ write('Falha no login do ambiente.'); return res.end(); }

      let mtarUrl;
      try{
      try{ this.appsSvc.envTypeHint = (__isCF ? 'CF' : 'XS'); }catch(_e){}
        mtarUrl = await this.appsSvc.resolveMtarUrl(objectId, targetVersion, { preferredFolder: (info && info.packageSource) ? info.packageSource : 'normal' }, (t)=>write(String(t)));
      }catch(e){
        write('Erro ao resolver URL do MTAR: ' + (e && e.message || e));
        return res.end();
      }
      write('MTAR: ' + mtarUrl);

      const path = require('path');
// Banco de dados: use caminho absoluto no diretório do projeto para não “perder” cadastros ao iniciar de outra pasta
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'apps.db');
  const axios = require('axios');
      /** 
       * Função (arrow) ensureDirSync
       * - O que faz: Procedimento/serviço utilizado no fluxo atual.
       * - Retorno: Conforme uso do chamador.
       * @param {{any}} p 
       */
      const ensureDirSync = (p)=>{ if(!fs.existsSync(p)) fs.mkdirSync(p,{recursive:true}); };
      const outDir = path.join(__dirname, 'mtars_old');
ensureDirSync(outDir);
const outFile = path.join(outDir, `${objectId}-${targetVersion}.mtar`);

// Cache local: se já existir em mtars_old/ ou mtars/, não baixar novamente
const mtarsDir = path.join(__dirname, 'mtars');
const cachedInMtars = path.join(mtarsDir, `${objectId}-${targetVersion}.mtar`);
let mtarFileToDeploy = null;

if (fs.existsSync(outFile)) {
  mtarFileToDeploy = outFile;
  write('MTAR já existe em cache (mtars_old). Não será baixado novamente.');
  write('Arquivo local: ' + mtarFileToDeploy);
} else if (fs.existsSync(cachedInMtars)) {
  mtarFileToDeploy = cachedInMtars;
  write('MTAR já existe em cache (mtars). Não será baixado novamente.');
  write('Arquivo local: ' + mtarFileToDeploy);
} else {
  write('Baixando: ' + outFile);
  try{
    const response = await axios.get(mtarUrl, { responseType:'stream', timeout: 600000 });
    await new Promise((ok,bad)=>{ const w=fs.createWriteStream(outFile); response.data.pipe(w); w.on('finish', ok); w.on('error', bad); });
    write('Download concluído.');
    mtarFileToDeploy = outFile;
  }catch(e){
    write('Falha no download: ' + (e && e.message || e));
    return res.end();
  }
}

      write('Executando rollback: xs deploy <mtar> -version-rule ALL -f');
      const __mta = withMtaUploadTweaks(mtarFileToDeploy, ['deploy', ensureCliArgQuoted(mtarFileToDeploy), '-version-rule', 'ALL', '-f'], process.env);
      const code = await runSpawn(CLI_BIN, __mta.args, { env: __mta.env });
      write('Código de saída: ' + code);

      try{
        const user = (req.session && req.session.user && req.session.user.username) ? req.session.user.username : null;
        const status = code===0 ? 'success' : 'error';
      // ==== derive empresa/ambiente for deploy_audit ====
      const __empresa = (env && (env.name || env.company_name || env.org)) ? String(env.name || env.company_name || env.org).trim() : '';
      let __ambiente = (env && (env.space || env.environment || env.env || env.ambiente)) ? String(env.space || env.environment || env.env || env.ambiente).trim() : '';
      if(!__ambiente && __empresa){
        const __m = __empresa.match(/\s+(DEV|QAS|PRD|HML|PROD|PRODUCAO|HOMOLOG|PPRD|QA|TEST|STG)$/i);
        if(__m){
          __ambiente = __m[1].toUpperCase();
          // keep original empresa as-is for audit; do not strip suffix here
        }
      }
        await this.__auditInsert(req, { env_id: (env && env.id) || envId || null, company_name: (__empresa || (env && env.company_name) || null), org: (env && env.org) || null, space: (env && env.space) || null, object_id: objectId, prev_version: (typeof prevVersion!=='undefined'?prevVersion:null), new_version: (typeof newVersion!=='undefined'?newVersion:null), executor_user: user || (req.session && req.session.user && req.session.user.username) || null, action_type: 'Rollback', ticket, status, action_type: 'Rollback', log_text: (typeof log!=='undefined'?log:'') });
try{ console.log('[audit] inserted', {env_id: env && env.id, empresa: (typeof __empresa!=='undefined'?__empresa: (env && (env.name||env.company_name))), ambiente: (typeof __ambiente!=='undefined'?__ambiente: (env && env.space)), objectId}); }catch(_){ }
try{ console.log('[audit] row inserted for', {empresa: env && (env.name||env.company_name), ambiente: env && env.space, objectId}); }catch(_){ }
// Persistir instalação após rollback bem-sucedido
      if (code===0){ try{ await this.appsSvc.upsertInstalled(env, objectId, targetVersion); console.log('[installed_apps] persisted (rollbackStream)', {objectId, env: env && (env.name||env.id), version: targetVersion}); }catch(_e){} }

      }catch(_){}

      return res.end();
    }catch(e){
      const _errMsg = (e && e.message) ? e.message : String(e);
      try { return res.status(500).type('text/plain').send('Erro no rollback: ' + _errMsg); }
      catch(_) { return; }
    }
  }

  async rollbackStart(req,res){

// --- Ticket obrigatório (inline) ---
{ 
  const _tBody = req && req.body && (req.body.ticket ?? req.body.chamado);
  const _tQuery = req && req.query && (req.query.ticket ?? req.query.chamado);
  const _tHead  = req && req.headers && (req.headers['x-ticket'] ?? req.headers['x-chamado']);
  const _tRaw = _tBody ?? _tQuery ?? _tHead;
  const _t = (_tRaw !== undefined && _tRaw !== null) ? String(_tRaw).trim() : '';
  if (!_t) return res.status(400).json({ ok:false, error: 'Informe o número do chamado (ticket) para continuar.' });
  if (req && req.body && !req.body.ticket) req.body.ticket = _t;
}
// --- fim ticket obrigatório (inline) ---
 try{ const { envId, objectId, password, ticket, packageSource } = req.body || {};
      if(!envId || !objectId || !password) return res.status(400).json({ok:false,error:'Parâmetros insuficientes'});
      if(!req.session?.user) return res.status(401).json({ok:false,error:'Unauthorized'});
      const t = uuidv4();
      this.rollbackTokens.set(t, { envId:Number(envId), objectId:String(objectId), password:String(password), user:req.session.user.username, ticket: (typeof ticket==='string'||typeof ticket==='number') ? String(ticket) : (ticket==null? null : String(ticket)), packageSource: (String(packageSource||'normal').toLowerCase()==='unshipped' ? 'unshipped' : 'normal'), created: Date.now() });
      for(const [k,v] of this.rollbackTokens.entries()){
        if(Date.now() - (v.created||0) > 10*60*1000) this.rollbackTokens.delete(k);
      }
      return res.json({ok:true, token:t});
    }catch(e){
      return res.status(500).json({ok:false,error:e.message||String(e)});
    }
  }

  async rollbackStream(req,res){
    const token = String(req.query.token||'');
    const info = this.rollbackTokens.get(token);
    if(!info){ res.status(400).send('token inválido'); return; }
    this.rollbackTokens.delete(token);

    res.writeHead(200, {
      'Content-Type':'text/event-stream',
      'Cache-Control':'no-cache',
      'Connection':'keep-alive',
      'X-Accel-Buffering':'no'
    });

    /** 
     * Função (arrow) send
     * - O que faz: Procedimento/serviço utilizado no fluxo atual.
     * - Retorno: Conforme uso do chamador.
     * @param {{any}} line 
     */
    const send = (line) => { try{ res.write('data: ' + String(line).replace(/\n/g,'\\n') + '\n\n'); }catch(_){}};
    /** 
     * Função (arrow) sendDone
     * - O que faz: Procedimento/serviço utilizado no fluxo atual.
     * - Retorno: Conforme uso do chamador.
     * @param {{any}} payload 
     */
    const sendDone = (payload) => { try{ res.write('event: done\n'); res.write('data: ' + JSON.stringify(payload) + '\n\n'); }catch(_){} };

    const { envId, objectId, password, user, ticket } = info;
    let log = '';
    /** 
     * Função (arrow) appendLog
     * - O que faz: Procedimento/serviço utilizado no fluxo atual.
     * - Retorno: Conforme uso do chamador.
     * @param {{any}} t 
     */
    const appendLog = (t) => { log += t; if (log.length > 300000) log = log.slice(-300000); };

    try{
      const env = await this.envSvc.getById(envId);
      
      const __isCF = (function(){ try { return (String(env?.env_type||'').toUpperCase().includes('CF') || String(env?.org_url||'').includes('api.cf.')); } catch(__e){ return false; } })();
if(!env){ send('Ambiente não encontrado.');
      const rawType = ((env && typeof env.env_type === 'string') ? env.env_type : '').trim().toUpperCase();
const normType = (rawType === 'CLOUD FOUNDRY') ? 'CF' : ((rawType === 'XSA') ? 'XS' : rawType);
CLI_NAME =  (normType === 'XS') ? 'xs' : 'cf';
CLI_BIN =  (CLI_NAME === 'xs'
  ? ((process.env.XS_BIN && process.env.XS_BIN.trim()) || 'xs')
  : ((process.env.CF_BIN && process.env.CF_BIN.trim()) || 'cf'));
CLI_NAME =  (CLI_BIN === 'cf') ? 'CF' : 'XS';
 sendDone({ok:false}); return res.end(); }
      if(!env.org_url){ send('Ambiente sem org_url.'); sendDone({ok:false}); return res.end(); }
      if(!env.username){ send('Ambiente sem usuário.'); sendDone({ok:false}); return res.end(); }

      
      const nodemailer = require('nodemailer');

/**
 * Returns LOCAL datetime as 'YYYY-MM-DD HH:mm:ss' (host timezone).
 */
/** 
 * Função toLocalSql
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem toLocalSql.
 * - Retorno: Valor compatível com o uso corrente.
 * @param {{any}} d = new Date( 
 */
function toLocalSql(d = new Date()) {
  /** 
   * Função (arrow) pad
   * - O que faz: Procedimento/serviço utilizado no fluxo atual.
   * - Retorno: Conforme uso do chamador.
   * @param {{any}} n 
   */
  const pad = (n) => String(n).padStart(2, '0');
  const y = d.getFullYear();
  const m = pad(d.getMonth() + 1);
  const day = pad(d.getDate());
  const h = pad(d.getHours());
  const mi = pad(d.getMinutes());
  const s = pad(d.getSeconds());
  return `${y}-${m}-${day} ${h}:${mi}:${s}`;
}

      const path = require('path');
// Banco de dados: use caminho absoluto no diretório do projeto para não “perder” cadastros ao iniciar de outra pasta
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'apps.db');
  const axios = require('axios');
      /** 
       * Função (arrow) ensureDirSync
       * - O que faz: Procedimento/serviço utilizado no fluxo atual.
       * - Retorno: Conforme uso do chamador.
       * @param {{any}} p 
       */
      const ensureDirSync = (p)=>{ if(!fs.existsSync(p)) fs.mkdirSync(p,{recursive:true}); };

      send('> ' + CLI_NAME + ' login ...');

  const loginArgs = ['login','-a',env.org_url,'--skip-ssl-validation','-u',env.username,'-p',String(password)];
      if(env.org) loginArgs.push('-o', ensureCliArgQuoted(env.org));
      if(env.space) loginArgs.push('-s', ensureCliArgQuoted(env.space));
      /** 
       * Função (arrow) runSpawn
       * - O que faz: Procedimento/serviço utilizado no fluxo atual.
       * - Retorno: Conforme uso do chamador.
       * @param {{any}} cmd 
       * @param {{any}} args=[] 
       */
      const runSpawn = (cmd, args=[]) => new Promise((resolve)=>{
        const child = spawn(cmd, args, { shell:true });
        child.stdout.on('data', d=>{ const s=d.toString(); appendLog(s); send(s.trimEnd()); });
        child.stderr.on('data', d=>{ const s=d.toString(); appendLog(s); send(s.trimEnd()); });
        child.on('close', code => resolve(code));
      });
      const loginCode = await runSpawn(CLI_BIN, loginArgs);
      if(loginCode !== 0){ send('Falha no login do ambiente.'); sendDone({ok:false}); return res.end(); }

      send('Consultando deploy_audit...');
      /* strict rollback: version must come from deploy_audit.prev_version */
      let targetVersion = null;
      if (targetVersion) {
        // (não usado) - ignorado em modo estrito
      } else {
        const row = await this.appsSvc.db.get(
          `SELECT id, prev_version, new_version, ts FROM deploy_audit WHERE env_id = ? AND object_id = ? ORDER BY id DESC LIMIT 1`,
          [envId, objectId]
        );
        if (row && row.prev_version){
          targetVersion = row.prev_version;
        } else {
          send('Não há prev_version registrada. Tentando versão anterior a partir de históricos...');
          try{
            const rows = await this.appsSvc.db.all(
              `SELECT new_version FROM deploy_audit WHERE env_id = ? AND object_id = ? AND new_version IS NOT NULL ORDER BY id DESC LIMIT 2`,
              [envId, objectId]
            );
            if (rows && rows.length >= 2 && rows[1] && rows[1].new_version){
              targetVersion = rows[1].new_version;
              send('Encontrada versão anterior via new_version histórico: ' + targetVersion);
            }
          }catch(_){ /* .all pode não existir, 'Atualização', (req.headers && (req.headers['x-forwarded-for']||'')).split(',')[0] || (req.socket && req.socket.remoteAddress) || null, (req.get && req.get('user-agent')) || (req.headers && req.headers['user-agent']) || null, (req.get && req.get('host')) || (req.hostname) || null, 'Atualização', (req.headers && (req.headers['x-forwarded-for']||'')).split(',')[0] || (req.socket && req.socket.remoteAddress) || null, (req.get && req.get('user-agent')) || (req.headers && req.headers['user-agent']) || null, (req.get && req.get('host')) || (req.hostname) || null, ignorar */ }
        }
      }
      if(!targetVersion){ send('Não foi possível determinar a versão anterior. Informe manualmente.'); sendDone({ok:false, code:'no_prev'}); return res.end(); }
      const targetVersionMsg = 'Versão alvo (rollback): ' + targetVersion; send(targetVersionMsg);
      send('Versão alvo (prev_version): ' + targetVersion);

      send('Resolvendo URL do MTAR...' );
      send('Componente: ' + objectId + ' | Versão: ' + targetVersion);
      let mtarUrl;
      try{
        mtarUrl = await this.appsSvc.resolveMtarUrl(objectId, targetVersion, { preferredFolder: (info && info.packageSource) ? info.packageSource : 'normal' }, (t)=>send(String(t)));
      }catch(e){
        send('Erro ao resolver URL do MTAR: ' + (e && e.message || e)); sendDone({ok:false}); return res.end();
      }
      send('MTAR: ' + mtarUrl);

      ensureDirSync(path.join(__dirname,'mtars_old'));
const outFile = path.join(__dirname,'mtars_old', `${objectId}-${targetVersion}.mtar`);

// Cache local: se já existir em mtars_old/ ou mtars/, não baixar novamente
const mtarsDir = path.join(__dirname, 'mtars');
const cachedInMtars = path.join(mtarsDir, `${objectId}-${targetVersion}.mtar`);
let mtarFileToDeploy = null;

if (fs.existsSync(outFile)) {
  mtarFileToDeploy = outFile;
  send('MTAR já existe em cache (mtars_old). Não será baixado novamente.');
  send('Arquivo local: ' + mtarFileToDeploy);
} else if (fs.existsSync(cachedInMtars)) {
  mtarFileToDeploy = cachedInMtars;
  send('MTAR já existe em cache (mtars). Não será baixado novamente.');
  send('Arquivo local: ' + mtarFileToDeploy);
} else {
  send('Baixando MTAR...');
  try{
    const response = await axios.get(mtarUrl, { responseType:'stream', timeout: 600000 });
    await new Promise((ok,bad)=>{ const w=fs.createWriteStream(outFile); response.data.pipe(w); w.on('finish', ok); w.on('error', bad); });
    send('Download concluído: ' + outFile);
    mtarFileToDeploy = outFile;
  }catch(e){
    send('Falha no download: ' + (e && e.message || e)); sendDone({ok:false}); return res.end();
  }
}

      if (!fs.existsSync(mtarFileToDeploy)) { send('Arquivo não encontrado: ' + mtarFileToDeploy); sendDone({ok:false}); return res.end(); }
      send('> ' + CLI_NAME + ' deploy ' + mtarFileToDeploy + ' -version-rule ALL -f');
      const __mta = withMtaUploadTweaks(mtarFileToDeploy, ['deploy', ensureCliArgQuoted(mtarFileToDeploy), '-version-rule', 'ALL', '-f'], process.env);
      const code = await runSpawn(CLI_BIN, __mta.args, { env: __mta.env });
      send('Código de saída: ' + code);

      try{
        const status = code===0 ? 'success' : 'error';
      // ==== derive empresa/ambiente for deploy_audit ====
      const __empresa = (env && (env.name || env.company_name || env.org)) ? String(env.name || env.company_name || env.org).trim() : '';
      let __ambiente = (env && (env.space || env.environment || env.env || env.ambiente)) ? String(env.space || env.environment || env.env || env.ambiente).trim() : '';
      if(!__ambiente && __empresa){
        const __m = __empresa.match(/\s+(DEV|QAS|PRD|HML|PROD|PRODUCAO|HOMOLOG|PPRD|QA|TEST|STG)$/i);
        if(__m){
          __ambiente = __m[1].toUpperCase();
          // keep original empresa as-is for audit; do not strip suffix here
        }
      }
        await this.__auditInsert(req, { env_id: (env && env.id) || envId || null, company_name: (__empresa || (env && env.company_name) || null), org: (env && env.org) || null, space: (env && env.space) || null, object_id: objectId, prev_version: (typeof prevVersion!=='undefined'?prevVersion:null), new_version: (typeof newVersion!=='undefined'?newVersion:null), executor_user: user || (req.session && req.session.user && req.session.user.username) || null, ticket, status, action_type: 'Rollback', log_text: (typeof log!=='undefined'?log:'') });
try{ console.log('[audit] inserted', {env_id: env && env.id, empresa: (typeof __empresa!=='undefined'?__empresa: (env && (env.name||env.company_name))), ambiente: (typeof __ambiente!=='undefined'?__ambiente: (env && env.space)), objectId}); }catch(_){ }
try{ console.log('[audit] row inserted for', {empresa: env && (env.name||env.company_name), ambiente: env && env.space, objectId}); }catch(_){ }
}catch(_){}

      sendDone({ ok: code===0, objectId, version: targetVersion });
      return res.end();
    }catch(e){
      send('Erro no rollback: ' + (e && e.message || String(e)));
      sendDone({ ok:false, error: e && e.message || String(e) });
      try{ return res.end(); }catch(_){}
    }
  }
async renderHome(req,res){
    try{
      const envs = await this.envSvc.list();
      res.type('html').send(HomeView.html(envs));
    }catch(e){
      console.error('renderHome env list error:', e);
      res.type('html').send(HomeView.html([]));
    }
  }

  // === Dependencies endpoint ===
  async validateInstall(req,res){
    try{
      const target = req.params.target;
      const items = Array.isArray(req.body) ? req.body : (Array.isArray(req.body && req.body.itens) ? req.body.itens : []);
      const apps = (items||[]).map(a => ({ app_name: a.app_name, version: a.version }));
      const missings = await this.appsSvc.validateInstallSet(target, apps);
      res.json(missings);
    }catch(e){
      console.error('validateInstall error:', e);
      res.status(500).json({ ok:false, error: e && e.message ? e.message : String(e) });
    }
  }

}

// =============== App bootstrap ===============
/** 
 * Classe ServerApp
 * - O que faz: Representa uma entidade/serviço com estado e comportamentos.
 * - Observação: Métodos internos seguem as regras originais do código.
 */
class ServerApp {
  constructor(){
    this.app=express();

    this.db=new Database(DB_FILE);
    this.schema=new SchemaManager(this.db);
    this.userSvc=new UserService(this.db);
    this.resetSvc=new PasswordResetService(this.db);
    this.appsSvc=new AppsService(this.db);
    this.envSvc=new EnvironmentsService(this.db);

    this.auth=new AuthController(this.userSvc,this.resetSvc);
    this.apps=new AppsController(this.appsSvc, this.envSvc);
    this.envs=new EnvironmentsController(this.envSvc);
  }
  async init(){
    await this.schema.ensure();
    await this.userSvc.seedAdmin();

    this.app.use(express.json());

// === Middleware: ticket (chamado) obrigatório para Deploy/Rollback ===
try {
  const __ticketGuard = function(req, res, next){
    try {
      const fromBody = req && req.body && (req.body.ticket ?? req.body.chamado);
      const fromQuery = req && req.query && (req.query.ticket ?? req.query.chamado);
      const fromHeader = req && req.headers && (req.headers['x-ticket'] ?? req.headers['x-chamado']);
      const tRaw = fromBody ?? fromQuery ?? fromHeader;
      const t = (tRaw !== undefined && tRaw !== null) ? String(tRaw).trim() : '';
      if (!t) {
        return res.status(400).json({ ok:false, error: 'Informe o número do chamado (ticket) para continuar.' });
      }
      req.ticket = t;
      if (req.body && !req.body.ticket) req.body.ticket = t;
      return next();
    } catch(__e) {
      return res.status(400).json({ ok:false, error: 'Informe o número do chamado (ticket) para continuar.' });
    }
  };
  this.app.use(['/api/deploy-start','/api/rollback-start','/api/rollback/live','/api/deploy','/api/rollback'], function(req,res,next){
    if (['POST','PUT','PATCH','DELETE'].includes(String(req.method||'').toUpperCase())) {
      return __ticketGuard(req,res,next);
    }
    return next();
  });
} catch(__e) {
  console.error('Falha ao ativar guarda de ticket obrigatório:', (__e && __e.message) || __e);
}
// === fim middleware ticket obrigatório ===

    this.app.use(express.urlencoded({extended:true}));

    this.app.use('/static', express.static(path.join(__dirname, 'static')));

    const SESSION_SECRET=process.env.SESSION_SECRET||'dev-secret-change-me';
    this.app.use(session({ name:'sid', secret:SESSION_SECRET, resave:false, saveUninitialized:false,
      cookie:{ httpOnly:true, sameSite:'lax', secure:false} }));

    // Rotas públicas
    
    // === Pre-router soft-block for non-admin user creation ===
    // Garante que o POST /api/users retorne 200 com mensagem amigável quando não-admin,
    // antes dos middlewares de requireAdmin do router.
    this.app.use((req, res, next) => {
      try {
        if (req.path === '/api/users' && String(req.method || '').toUpperCase() === 'POST') {
          if (!req.session || !req.session.user) {
            return res.status(401).json({ ok:false, error:'Unauthorized' });
          }
          const role = String(req.session.user.role || '').toLowerCase();
          if (role !== 'admin') {
            return res.status(200).json({ ok:false, error:'Somente administradores podem executar esta ação.' });
          }
        }
        return next();
      } catch (e) {
        return res.status(500).json({ ok:false, error:'Auth error' });
      }
    });
    // === end pre-router soft-block ===

this.app.use(this.auth.router);

    // Proteção das próximas rotas
    this.app.use((req,res,next)=>{
      const open=['/login','/api/login','/api/forgot','/api/reset'];
      const isReset=req.path.startsWith('/reset/');
      if(open.includes(req.path)||isReset) return next();
      if(req.session?.user) return next();
      if(req.path.startsWith('/api/')) return res.status(401).json({error:'Unauthorized'});
      return res.redirect('/login');
    });
    // === RBAC guard: apenas Administradores podem Deploy/Rollback e criar/alterar Ambientes/Usuários ===
    this.app.use((req, res, next) => {
      try {
        const pth = String(req.path || '');
        const m = String(req.method || '').toUpperCase();

        const isWrite = (m === 'POST' || m === 'PUT' || m === 'PATCH' || m === 'DELETE');

        const isDeployOrRollback =
          (['/api/deploy-start','/api/deploy','/api/rollback-start','/api/rollback','/api/rollback/live'].includes(pth) && isWrite);

        const isEnvWrite =
          (pth.startsWith('/api/environments') && (m === 'POST' || m === 'DELETE'));

        const isUserCreate =
          (pth === '/api/users' && m === 'POST');

        const needsAdmin = isDeployOrRollback || isEnvWrite || isUserCreate;

        if (!needsAdmin) return next();
        if (!req.session || !req.session.user) return res.status(401).json({ ok:false, error:'Unauthorized' });
        const role = String(req.session.user.role || '').toLowerCase();
        if (role !== 'admin') {
          const payload = { ok:false, error:'Somente administradores podem executar esta ação.' };
          if (pth === '/api/users' && m === 'POST') { return res.status(200).json(payload); }
          return res.status(403).json(payload);
        }
        return next();
      } catch (e) {
        return res.status(500).json({ ok:false, error:'Auth error' });
      }
    });
    // === fim RBAC guard ===

    // Rotas app
    this.app.use(this.apps.router);
    this.app.use(this.envs.router);

    this.app.get('/reset/:token', this.auth.renderReset.bind(this.auth));

    this.app.use((req,res)=>res.status(404).send('Não encontrado'));
  }
  listen(){
    const PORT=process.env.PORT||8080;
    ensureDirSync(path.join(__dirname,'mtars'));
    ensureDirSync(path.join(__dirname,'mtars_old'));
    console.log('> Pasta de MTARs:', path.join(__dirname,'mtars'));
    console.log('> XS_BIN:', process.env.XS_BIN || '(PATH: xs)');
    console.log('> XS_ARGS:', process.env.XS_ARGS || '(vazio)');
    console.log('> MTAR_URL_TEMPLATE:', process.env.MTAR_URL_TEMPLATE || '(padrão mtar_18/{repoName}/{id}_{version}.mtar; tenta variações automaticamente)');
    this.app.listen(PORT, ()=>console.log(`> Servidor em http://localhost:${PORT}`));
  }
}

(async()=>{
  const srv=new ServerApp();
  await srv.init();
  srv.listen();
})();

/* === Auto-marcação de dependências no overview (browser-only guard) === */
if (typeof window !== 'undefined' && typeof document !== 'undefined') {
(function(){
  async function markDepsStatusAuto(){
    try{
      var envSel = document.getElementById('envSelectHeader');
      if(!envSel || !envSel.value) return;
      var envId = envSel.value;
      var rows = document.querySelectorAll('#overviewTable tbody tr');
      for (var i=0;i<rows.length;i++){
        try{
          var tr = rows[i];
          var deployBtn = tr.querySelector('.btnDeployRow');
          if(!deployBtn) continue;
          var compId = deployBtn.getAttribute('data-id');
          if(!compId) continue;
          var resp = await fetch('/api/validate/install-apps/' + encodeURIComponent(envId), {
            method:'POST',
            headers:{'Content-Type':'application/json', 'X-Edit-Id': String((typeof document!=='undefined' && document.getElementById('env_id') && document.getElementById('env_id').value) ? document.getElementById('env_id').value : ((typeof window!=='undefined' && window.currentEditId) ? window.currentEditId : ''))},
            body: JSON.stringify([{ app_name: compId }])
          });
          if(!resp.ok) continue;
          var miss = await resp.json();
          var hasDeps = Array.isArray(miss) && miss.length > 0;
          // localizar botão Dependências
          var depsBtn = tr.querySelector('.btnDepsRow');
          if(!depsBtn){
            var cand = Array.prototype.slice.call(tr.querySelectorAll('button.btn'));
            depsBtn = cand.find(function(b){ return /depend/i.test((b.textContent||'')); });
          }
          if(depsBtn){
            if(hasDeps){
              depsBtn.classList.add('warn');
              depsBtn.title = 'Há dependências pendentes para este objeto.';
            }else{
              depsBtn.classList.remove('warn');
              depsBtn.title = 'Sem dependências pendentes.';
            }
          }
        }catch(_e){}
      }
    }catch(_e){}
  }
  /** 
   * Função setupObserver
   * - O que faz: Encapsula uma operação específica do domínio.
   * - Quando chamada: Em fluxos que exigem setupObserver.
   * - Retorno: Valor compatível com o uso corrente.

   */
  function setupObserver(){
    try{
      var tbody = document.querySelector('#overviewTable tbody');
      if(!tbody) return;
      var obs = new MutationObserver(function(){ markDepsStatusAuto(); });
      obs.observe(tbody, { childList: true });
      // primeira rodada se já houver linhas
      markDepsStatusAuto();
    }catch(_e){}
  }
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', setupObserver);
  }else{
    setupObserver();
  }
})();
}
/* === fim auto-marcação === */
// --- Debug endpoint to inspect env.env_type and CLI decision ---
try {
  if (typeof app !== 'undefined' && app && app.get) {
    /** 
     * Rota GET "/debug/env"
     * - O que faz: Manipula requisições GET para o caminho "/debug/env".
     * - Entrada: req (parâmetros/headers/body), res (resposta), next (middleware).
     * - Saída: Resposta HTTP apropriada.
     */
    app.get('/debug/env', async (req, res) => {
      try {
        let env = null;
        if (req && req.query) {
          if (req.query.env) {
            try { env = JSON.parse(req.query.env); } catch(e) {}
          }
          if (!env && req.query.env_type) {
            env = { env_type: String(req.query.env_type) };
          }
          if (!env && req.query.companyId && typeof loadEnvironmentByCompanyId === 'function') {
            env = await loadEnvironmentByCompanyId(req.query.companyId);
          }
        }
        if (!env) return res.status(400).json({ ok:false, error: 'Env não fornecido. Use ?env_type=CF ou ?env={...}.' });
        const cli = resolveCli(env);
        return res.json({ ok:true, env_type: env && env.env_type, resolved: cli });
      } catch (err) {
        return res.status(500).json({ ok:false, error: String(err) });
      }
    });
  }
} catch (_){}

// === Sync Report button style with Create User button ===
(function(){
  if (typeof document === 'undefined') return;
  var sync = function(){
    try{
      var rep = document.getElementById('btnReport');
      var usr = document.getElementById('btnOpenCreateUser');
      if (!rep || !usr) return;
      // same classes
      rep.className = usr.className || rep.className;
      // copy inline styles if any
      var s = usr.getAttribute('style');
      if (s) rep.setAttribute('style', s);
    }catch(_){}
  };
  if (document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', sync);
  } else {
    sync();
  }
  // also resync when header is (re)rendered
  document.addEventListener('click', function(ev){
    var t = ev.target;
    if (!t) return;
    if (t.id === 'btnReport' || t.id === 'btnOpenCreateUser') {
      setTimeout(sync, 0);
    }
  }, true);
})();

/** 
 * Função __normalizeOverviewColumnLayout
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem __normalizeOverviewColumnLayout.
 * - Retorno: Valor compatível com o uso corrente.

 */
function __normalizeOverviewColumnLayout(){
  try{
    var tbl = document.getElementById('overviewTable');
    if(!tbl) return;
    // inject a single style tag to enforce widths & alignment
    if(!document.getElementById('overviewColStyle')){
      var css = `
#overviewTable{table-layout:fixed;}
#overviewTable th, #overviewTable td{vertical-align:middle;}
#overviewTable th:nth-child(1), #overviewTable td:nth-child(1){text-align:left; width:38%;}
#overviewTable th:nth-child(2), #overviewTable td:nth-child(2){text-align:center; width:20%;}
#overviewTable th:nth-child(3), #overviewTable td:nth-child(3){text-align:center; width:20%;}
#overviewTable th:nth-child(4), #overviewTable td:nth-child(4){text-align:right; width:22%;}
      `.trim();
      var st = document.createElement('style');
      st.id = 'overviewColStyle';
      st.type = 'text/css';
      st.appendChild(document.createTextNode(css));
      document.head.appendChild(st);
    }
  }catch(_){}
}

// === Ocultar botões (Rollback/Dependências) quando empresa de Produção (PRD) ===

/** 
 * Função __isProdStage
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem __isProdStage.
 * - Retorno: Valor compatível com o uso corrente.
 * @param {{any}} val 
 */
function __isProdStage(val){
  try{
    var s = String(val||'')
      .toUpperCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g,''); // remove acentos
    return s === 'PRD' || s === 'PROD' || s === 'PRODUCAO' || s === 'PRODUCTION';
  }catch(_){ return false; }
}

/** 
 * Função __toggleProdOnlyButtons
 * - O que faz: Encapsula uma operação específica do domínio.
 * - Quando chamada: Em fluxos que exigem __toggleProdOnlyButtons.
 * - Retorno: Valor compatível com o uso corrente.
 * @param {{any}} stage 
 */
function __toggleProdOnlyButtons(stage){
  try{
    var isPRD = (typeof __isProdStage === 'function') ? __isProdStage(stage) : (String(stage||'').toUpperCase()==='PRD');

    // Botões de dependências (linha e header)
    var depBtns = document.querySelectorAll('[data-action="check-deps"], .btnCheckDepsRow');

    // Botões de Rollback (linha, botão principal e qualquer data-action="rollback")
    var rbBtns  = document.querySelectorAll('.btnRollbackRow, #btnRollback, [data-action="rollback"]');

    function applyState(el){
      try{
        if(isPRD){
          el.setAttribute('data-disabled','1');
          el.setAttribute('aria-disabled','true');
          el.setAttribute('tabindex','-1');
          try{ el.disabled = true; }catch(_){}
          try{ el.classList.add('disabled'); }catch(_){}
          el.style.opacity = '0.5';
          el.style.pointerEvents = 'none';
          el.style.filter = 'grayscale(1)';
          el.style.cursor = 'not-allowed';
          if(!el.getAttribute('title')) el.setAttribute('title','Indisponível em Produção');
        } else {
          el.removeAttribute('data-disabled');
          el.removeAttribute('aria-disabled');
          el.removeAttribute('tabindex');
          try{ el.disabled = false; }catch(_){}
          try{ el.classList.remove('disabled'); }catch(_){}
          el.style.opacity = '';
          el.style.pointerEvents = '';
          el.style.filter = '';
          el.style.cursor = '';
          if(el.getAttribute('title') === 'Indisponível em Produção') el.removeAttribute('title');
        }
      }catch(_){}
    }

    depBtns.forEach(applyState);
    rbBtns.forEach(applyState);
  }catch(_){}
}